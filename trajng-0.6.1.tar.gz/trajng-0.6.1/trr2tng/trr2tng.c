/* trajng (Trajectory next generation) a library for (de)compression
 * of molecular dynamics trajectories. 
 * Copyright (c) Daniel Spangberg 2010
 *
 * This is trr2tng - Program to convert tng files from and to gromacs
 * trr files.
 *
 * This program is very heavily based on trr2xtc.c
 * Copyright (c) Erik Lindahl, David van der Spoel 2003,2004.
 * Coordinate compression (c) by Frans van Hoesel. 
 *
 * The changes done from trr2xtc is mostly replacing the xtc
 * routines with trajng routines!
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 */

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <xdrfile/xdrfile.h>
#include <xdrfile/xdrfile_trr.h>
#include <xdrfile/xdrfile_xtc.h>
#include <trajng.h>

#ifdef TRAJNG_USE_MPI
#include <mpi.h>
#include <trajngmpi.h>
#endif

static void x_die(char *msg, int line, char *file) {
	fprintf(stderr, "Fatal error: %s\n", msg);
	fprintf(stderr, "Death occurred at %s, line %d\n", file, line);
#ifdef TRAJNG_USE_MPI
	MPI_Abort(MPI_COMM_WORLD,1);
#endif
	exit(1);
}
#define die(msg) x_die(msg,__LINE__,__FILE__)

static void x_die_r(char *msg, int result, int line, char *file) {
	fprintf(stderr, "Fatal error: %s\n", msg);
	fprintf(stderr,"result = %d\n", result);
	fprintf(stderr, "Death occurred at %s, line %d\n", file, line);
#ifdef TRAJNG_USE_MPI
	MPI_Abort(MPI_COMM_WORLD,1);
#endif
	exit(1);
}
#define die_r(msg,res) x_die_r(msg,res,__LINE__,__FILE__)


void ReadWrite(char *rfile, char *wfile, int in_tngBool, int out_tngBool, int in_trrBool, int out_trrBool, int in_xtcBool, int skip, int novel, int maxframes, int nov, int speed, float prec_tng, float prec_tngvel)
{
  XDRFILE *xd_read=NULL, *xd_write;
  void *tng_file=NULL;
  int result_tng, result_trr;
  int natoms_tng, natoms_trr;
  int step_tng, step_trr;
  float time_tng, time_trr;
  matrix box_tng, box_trr;
  rvec *x_trr, *v_trr, *f_trr;
  rvec *x_tng, *v_tng;
  float lambda_trr = 0.0;
  float lambda_tng = 0.0;
#ifndef TRAJNG_USE_MPI
  int compatibility_mode=0; /* Do not prefer indices in a separate file. */
#endif
  int rank=0;
#ifdef TRAJNG_USE_MPI
  int *map=NULL;
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
#endif
      
  /* .tng -> .trr */
  if(in_tngBool && out_trrBool)
    {
      if (rank==0)
	{
	  int nframes=0;
      
	  tng_file=TrajngOpenRead(rfile);
	  if (NULL == tng_file)
	    die("Opening tngfile for reading");
    
	  /* Test whether output file exists */
	  if ((xd_write = xdrfile_open(wfile,"r")) != NULL) {
	    xdrfile_close(xd_write);
	    die("Output file exists.");
	  }
  
	  /* Output file does not exist. Now we can open it for writing */
	  xd_write = xdrfile_open(wfile, "w");
	  if (NULL == xd_write)
	    die("Opening xdrfile for writing");

	  natoms_tng=TrajngNatoms(tng_file);
      
	  x_tng = calloc(natoms_tng, sizeof(x_tng[0]));
	  if (TrajngHasVel(tng_file))
	    v_tng = calloc(natoms_tng, sizeof(v_tng[0]));
	  else
	    v_tng = NULL;
      
	  while(1)
	    {
	      if (TrajngReadTry(tng_file))
		break; /* EOF */
	      result_tng=TrajngReadf(tng_file,(float*)box_tng,(float*)x_tng,(float*)v_tng,3,&step_tng,&time_tng,&lambda_tng);
	      if (result_tng != 0)
		{
		  if (TrajngGetCompatibilityMode(tng_file))
		    break;
		  else
		    die_r("Reading tng file.", result_tng);
		}
	  
	      if ((nframes%skip)==0)
		{
		  if (novel)
		    result_trr = write_trr(xd_write, natoms_tng, step_tng, time_tng, lambda_tng,
					   box_tng, x_tng, NULL, NULL);
		  else
		    result_trr = write_trr(xd_write, natoms_tng, step_tng, time_tng, lambda_tng,
					   box_tng, x_tng, v_tng, NULL);
		}
	      nframes++;
	  
	      if (0 != result_trr)
		die_r("Writing trr file",result_trr);
	    }
  
	  xdrfile_close(xd_write);
	  TrajngClose(tng_file);
	}
    }  
  /* .trr/.xtc -> .tng */
  else if((in_trrBool||in_xtcBool) && out_tngBool)
    {
      int action;
      int verify_ok=1;
      int action_end=2;
      if (nov)
	action_end=1;
      if (in_xtcBool)
	if (rank==0) 
	  fprintf(stderr,"Warning: Reading XTC file. This might result in precision loss. A report about\n"
		  "precision loss will be given at the end of verification.\n");
      for (action=0; action<action_end; action++)
	{
	  int nframes=0;
	  int first=1;
	  FILE *otest;
	  float max_coord_error=0.f, max_velocity_error=0.f, max_box_error=0.f;
	  float max_box=0.f;
	  if (rank==0)
	    {
	      xd_read = xdrfile_open(rfile, "r");
	      if (NULL == xd_read)
		die("Opening xdrfile for reading");
	      if (!action)
		{
		  /* Test whether output file exists */
		  if ((otest = fopen(wfile,"r")) != NULL) {
		    fclose(otest);
		    die("Output file exists.");
		  }

		  /* Output file does not exist. We can open it for writing (later, when we know if velocities are present. */
		}
	  
	      if (in_xtcBool)
		result_trr = read_xtc_natoms(rfile, &natoms_trr);
	      else
		result_trr = read_trr_natoms(rfile, &natoms_trr);
	      
	      if (exdrOK != result_trr)
		die_r("read_trr_natoms",result_trr);
	    }
	  
#ifdef TRAJNG_USE_MPI
	  MPI_Bcast(&natoms_trr,1,MPI_INT,0,MPI_COMM_WORLD);
	  if ((rank==0) && (!action))
	    {
	      int imap;
	      map=malloc(natoms_trr*sizeof *map);
	      for (imap=0; imap<natoms_trr; imap++)
		map[imap]=imap;
	    }
#endif      

	  x_trr = calloc(natoms_trr, sizeof(x_trr[0]));
	  v_trr = calloc(natoms_trr, sizeof(v_trr[0]));
	  f_trr = calloc(natoms_trr, sizeof(f_trr[0]));
	  if (!action)
	    {
	      x_tng=NULL;
	      v_tng=NULL;
	    }
	  else
	    {
	      x_tng = calloc(natoms_trr, sizeof(x_tng[0]));
	      v_tng = calloc(natoms_trr, sizeof(v_tng[0]));
	    }
      
	  if (action)
	    if (rank==0)
	      fprintf(stderr,"\n");
	  while(1)
	    {
	      if (in_xtcBool)
		{
		  float prec_xtc;
		  if (rank==0)
		    {
		      result_trr = read_xtc(xd_read, natoms_trr, &step_trr, &time_trr,
					    box_trr, x_trr, &prec_xtc);
		      prec_tng=prec_xtc;
		    }
		  lambda_trr=0.f;
#ifdef TRAJNG_USE_MPI
		  MPI_Bcast(&prec_tng,1,MPI_FLOAT,0,MPI_COMM_WORLD);
#endif      
		}
	      else
		{
		  if (rank==0)
		    result_trr = read_trr(xd_read, natoms_trr, &step_trr, &time_trr, &lambda_trr,
					  box_trr, x_trr, v_trr, f_trr);
		}

#ifdef TRAJNG_USE_MPI
	      MPI_Bcast(&result_trr,1,MPI_INT,0,MPI_COMM_WORLD);
#endif      		  

	      if (result_trr == 0) // if not reach the end of file, write it to the output.trr file
		{
#ifdef TRAJNG_USE_MPI
		  /* The box, step, time and lambda needs to be broadcast. The coordinates (and velocities), 
		     will be automatically distributed by the parallel trajng code. */
		  MPI_Bcast((float*)box_trr,9,MPI_FLOAT,0,MPI_COMM_WORLD);
		  MPI_Bcast(&step_trr,1,MPI_INT,0,MPI_COMM_WORLD);
		  MPI_Bcast(&time_trr,1,MPI_FLOAT,0,MPI_COMM_WORLD);
		  MPI_Bcast(&lambda_trr,1,MPI_FLOAT,0,MPI_COMM_WORLD);
#endif
		  if (first)
		    {
		      int have_vel=0;
		      /* We must check whether the trr file has
			 velocities. Then we can open the tng file. */

		      int ii_trr, jj_trr, x_ck=0, v_ck=0, f_ck=0;
		      int x_ck_bool=0, v_ck_bool=0, f_ck_bool=0;
	  
		      for (ii_trr = 0; ii_trr < natoms_trr; ii_trr++)
			{
			  for(jj_trr = 0; jj_trr < DIM; jj_trr++)
			    {
			      if (x_trr[ii_trr][jj_trr] == 0)
				x_ck++;
			      if (v_trr[ii_trr][jj_trr] == 0)
				v_ck++;
			      if (f_trr[ii_trr][jj_trr] == 0)
				f_ck++;
			    }
			}

		      if (x_ck == natoms_trr*3)
			x_ck_bool = 1;
		      if (v_ck == natoms_trr*3)
			v_ck_bool = 1;
		      if (f_ck == natoms_trr*3)
			f_ck_bool = 1;

		      if ((!v_ck_bool) && (!novel))
			have_vel=1;

#ifdef TRAJNG_USE_MPI
		      MPI_Bcast(&have_vel,1,MPI_INT,0,MPI_COMM_WORLD);
#endif
		      if (!action)
			{
			  int chunky=100;
			  if(rank==0)
			    fprintf(stderr,"Opening tng file with %d atoms, precision %g\n",
				    natoms_trr,1./prec_tng);
			  if (have_vel)
			    if (rank==0)
			      fprintf(stderr,"I will compress velocities too. velocity precision %g\n",
				      1./prec_tngvel);
			  if (skip!=1)
			    if (rank==0)
			      fprintf(stderr,"I will write every %d frame.\n",skip);
#ifdef TRAJNG_USE_MPI
			  tng_file=TrajngMPIOpenWrite(wfile,natoms_trr,chunky,1./prec_tng,1,have_vel,1./prec_tngvel,speed,MPI_COMM_WORLD);
#else
			  tng_file=TrajngOpenWrite(wfile,natoms_trr,chunky,1./prec_tng,1,have_vel,1./prec_tngvel,compatibility_mode,speed);
#endif
			  if (!tng_file)
			    die("Opening tngfile for writing");
			}
		      else
			{
			  if (rank==0)
			    {
			      tng_file=TrajngOpenRead(wfile);
			      if (!tng_file)
				die("Opening tngfile for writing");
			    }
			}

		      /* Set program info here */
		      if (!action)
			{
#ifdef TRAJNG_USE_MPI		      
			  TrajngMPISetProgramInfo(tng_file,"trr2tng conversion program (MPI version)");
#else
			  TrajngSetProgramInfo(tng_file,"trr2tng conversion program");
#endif
			}
		      first=0;
		    }

		  if (exdrOK != result_trr)
		    die_r("Reading trr file", result_trr);
	      
		  if ((nframes%skip)==0)
		    {
		      if (!action)
			{
			  if (rank==0)
			    fprintf(stderr,"Compressing frame: %d\r",nframes+1);
			}
		      else
			{
			  if (rank==0)
			    fprintf(stderr,"Verifying frame: %d\r",nframes+1);
			}
		      if (rank==0)
			fflush(stdout);
		      if (!action)
			{
#ifdef TRAJNG_USE_MPI		      
			  int natoms_local=natoms_trr;
			  if (rank!=0)
			    natoms_local=0;
			  result_tng = TrajngMPIWritef(tng_file,(float*)box_trr,(float*)x_trr,(float*)v_trr,3,step_trr,time_trr,lambda_trr,
						       natoms_local,map);
#else
			  result_tng = TrajngWritef(tng_file,(float*)box_trr,(float*)x_trr,(float*)v_trr,3,step_trr,time_trr,lambda_trr);
#endif
			  if (result_tng != 0)
			    die_r("Writing tng file", result_tng);
			}
		      else
			{
			  if (rank==0)
			    {
			      int i,j;
			      /* Verify data here. */
			      if (TrajngReadf(tng_file,(float*)box_tng,(float*)x_tng,(float*)v_tng,3,&step_tng,&time_tng,&lambda_tng))
				{
				  fprintf(stderr,"\nCould not read frame.\n");
				  verify_ok=0;
				}
			      /* Verify coordinates. */
			      for (i=0; i<natoms_trr; i++)
				for (j=0; j<3; j++)
				  if (fabs(x_tng[i][j]-x_trr[i][j])>max_coord_error)
				    max_coord_error=fabs(x_tng[i][j]-x_trr[i][j]);
			      if (TrajngHasVel(tng_file))
				{
				  /* Verify velocities. */
				  for (i=0; i<natoms_trr; i++)
				    for (j=0; j<3; j++)
				      if (fabs(v_tng[i][j]-v_trr[i][j])>max_velocity_error)
					max_velocity_error=fabs(v_tng[i][j]-v_trr[i][j]);
				}
			      /* Verify box. */
			      for (i=0; i<3; i++)
				for (j=0; j<3; j++)
				  {
				    if (fabs(box_tng[i][j]-box_trr[i][j])>max_box_error)
				      max_box_error=fabs(box_tng[i][j]-box_trr[i][j]);
				    if (fabs(box_trr[i][j])>max_box)
				      max_box=fabs(box_trr[i][j]);
				  }
			      if (max_coord_error>0.525/prec_tng) /* 5% error is ok for test. */
				{
				  fprintf(stderr,"\nVerify failed for coordinates. Error is %g.\n",max_coord_error);
				  verify_ok=0;
				}
			      
			      if (max_velocity_error>0.525/prec_tngvel) /* 5% error is ok for test. */
				{
				  fprintf(stderr,"\nVerify failed for velocities. Error is %g.\n",max_velocity_error);
				  verify_ok=0;
				}
			      if (max_box_error>1e-6*max_box)
				{
				  fprintf(stderr,"\nVerify failed for box. Error is %g.\n",max_box_error);
				  verify_ok=0;
				}
			    }
			}
		    }
		  nframes++;
		  if ((maxframes>0) && (nframes>=maxframes))
		    break;
		}
	      else
		break;
	    }
  
	  xdrfile_close(xd_read);
	  if (!action)
	    {
#ifdef TRAJNG_USE_MPI		      
	      TrajngMPIClose(tng_file);
#else
	      TrajngClose(tng_file);
#endif	      
	    }
	  else if (rank==0)
	    TrajngClose(tng_file);
	  free(f_trr);
	  free(v_trr);
	  free(x_trr);
	  free(x_tng);
	  free(v_tng);
	  if ((in_xtcBool) && (action))
	    {
	      if (rank==0)
		{
		  fprintf(stderr,"\nThe largest error in the coordinates is %g\n",max_coord_error);
		  if (max_coord_error>0.225/prec_tng)
		    {
		      fprintf(stderr,"WARNING: Large precision errors have occured when compressing an XTC file.\n"
			      "WARNING: Multiple loss in precision has occured. It is up to you if this is acceptable.\n"
			      "WARNING: Compress the original trr file instead, if you still have it.\n");
		    }
		  else
		    {
		      fprintf(stderr,"The largest error seems ok, considering the precision chosen: %g\n",1./prec_tng);
		    }
		}
	    }
	}
      if (rank==0)
	fprintf(stderr,"\n");
      if (rank==0)
	{
	  if (verify_ok)
	    fprintf(stderr,"File data verifies ok.\n");
	  else
	    fprintf(stderr,"FILE DATA DOES NOT VERIFY OK.\n");
	}
    }
  else
    die("This program only converts from trr/xtc files to tng files or from tng files to trr files.");
#ifdef TRAJNG_USE_MPI
  free(map);
#endif
}



int main(int argc, char *argv[])
{
  int inFileBool = 0;
  int outFileBool = 0;
  int in_tngBool = 0;
  int out_tngBool = 0;
  int in_xtcBool = 0;
  int in_trrBool = 0;
  int out_trrBool = 0;
  int skip=1;
  int novel=0;
  int maxframes=-1;
  char *rfile=NULL, *wfile=NULL;
  int nov=0;
  int speed=0;
  float prec_tng = 1000.; /* Use trr2xtc precision convention. In tng files the inverse of this is used. */
  float prec_tngvel = 100.; /* Use trr2xtc precision convention. In tng files the inverse of this is used. */

  int ii = 1;

#ifdef TRAJNG_USE_MPI
  MPI_Init(&argc,&argv);
#endif

  while(ii < argc)
    {
      if(strcmp(argv[ii], "-i") == 0)         // if (argv[ii] == "-i")
	{
	  ii++;
	  inFileBool = 1;
	 
	  if(strstr(argv[ii], ".tng") != NULL)
	    {
	      in_tngBool = 1;
	      in_trrBool = 0;
	    }
	  if(strstr(argv[ii], ".xtc") != NULL)
	    {
	      in_xtcBool = 1;
	      in_tngBool = 0;
	    }
	  if(strstr(argv[ii], ".trr") != NULL)
	    {
	      in_trrBool = 1;
	      in_tngBool = 0;
	    }

	  rfile = argv[ii];
	}

      if(strcmp(argv[ii], "-o") == 0)
	{
	  ii++;
	  outFileBool = 1;
	 
	  if(strstr(argv[ii], ".tng") != NULL)
	    {		
	      out_tngBool = 1;
	      out_trrBool = 0;
	    }
	  if(strstr(argv[ii], ".trr") != NULL)
	    {
	      out_trrBool = 1;
	      out_tngBool = 0;
	    }

	  wfile = argv[ii];
	}

      if(strcmp(argv[ii], "-skip") == 0)         // if (argv[ii] == "-skip")
	{
	  ii++;
	  skip=atoi(argv[ii]);
	}

      if(strcmp(argv[ii], "-m") == 0)         // if (argv[ii] == "-m")
	{
	  ii++;
	  maxframes=atoi(argv[ii]);
	}

      if(strcmp(argv[ii], "-ndec") == 0)         // if (argv[ii] == "-ndec")
	{
	  ii++;
	  prec_tng=pow(10.,(double)atoi(argv[ii]));
	}

      if(strcmp(argv[ii], "-ndecvel") == 0)         // if (argv[ii] == "-ndecvel")
	{
	  ii++;
	  prec_tngvel=pow(10.,(double)atoi(argv[ii]));
	}

      if(strcmp(argv[ii], "-s") == 0)         // if (argv[ii] == "-s")
	{
	  ii++;
	  speed=atoi(argv[ii]);
	}

      if(strcmp(argv[ii], "-n") == 0)         // if (argv[ii] == "-n")
	{
	  novel=1;
	}
      if(strcmp(argv[ii], "-nov") == 0)         // if (argv[ii] == "-nov")
	{
	  nov=1;
	}

      ii++;
    }

  if(!inFileBool || !outFileBool)
    {
      fprintf(stderr,
	      "Usage : ./trr2tng [-ndec n] [-ndecvel n] [-m maxframes] [-skip skip] [-s speed] [-nov] [-n] -i inFile -o outFile\n"
	      "-skip skip : Only write every skip frame.\n"
	      "-m maxframes : Maximum number of frames to write.\n"
	      "-ndec n : Precision in number of decimal places for coordinates.\n"
	      "-ndecvel n : Precision in number of decimal places for velocities.\n"
	      "-s : Set compression speed (level) to speed.\n"
	      "-nov : Skip verification.\n"
	      "-n : Do not write velocities, even if they are in the trr file.\n");
      exit(1);
    }
#ifdef TRAJNG_USE_MPI
  {
    int size,rank;
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    if (rank==0)
      fprintf(stderr,"trr2tng (MPI version running with %d processes)\n",size);
  }
#else
  fprintf(stderr,"trr2tng\n");
#endif
  ReadWrite(rfile, wfile, in_tngBool, out_tngBool, in_trrBool, out_trrBool, in_xtcBool, skip, novel, maxframes, nov, speed, prec_tng, prec_tngvel);
  
#ifdef TRAJNG_USE_MPI
  MPI_Finalize();
#endif
  return 0;
}
