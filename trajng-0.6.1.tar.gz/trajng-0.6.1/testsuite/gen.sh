#!/bin/sh
for testnum in $(seq 1 108); do
    ./gen$testnum
done

echo "Now run ./run.sh to ensure that the generated trajectory files are readable and do not contain errors."
