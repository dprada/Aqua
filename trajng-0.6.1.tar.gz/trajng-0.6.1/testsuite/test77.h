/* This is using really stupid arguments to the algorithms to make sure we get a really big file so we can try 64 bit seeks. */
#define TESTNAME "64-bit seek. Single precision."
#define FILENAME "test77.tng"
#ifdef GEN
#define ALGOTEST
#else
#define SEEKTEST
#define SEEKTO 999999
#define READNFRAMES 1
#endif
#define NATOMS 1000
#define CHUNKY 100
#define SCALE 0.1
#define PRECISION 0.01
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING 5
#define INITIALCODINGPARAMETER 0
#define CODING 1
#define CODINGPARAMETER 27
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 1000000
#define REAL float
#define ISDOUBLE 0
#define EXPECTED_FILESIZE 10517051704.
