#define TESTNAME "Position coding. Intra frame BWLZH algorithm. Large system. Cubic cell. Double precision."
#define FILENAME "test47.tng"
#define ALGOTEST
#define NATOMS 5000000
#define CHUNKY 2
#define SCALE 1.
#define PRECISION 1.
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING 5
#define INITIALCODINGPARAMETER 0
#define CODING 9
#define CODINGPARAMETER 0
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 -536870911
#define INTMIN2 -536870911
#define INTMIN3 -536870911
#define INTMAX1 536870911
#define INTMAX2 536870911
#define INTMAX3 536870911
#define NFRAMES 4
#define REAL double
#define ISDOUBLE 1
#define EXPECTED_FILESIZE 67631845.
