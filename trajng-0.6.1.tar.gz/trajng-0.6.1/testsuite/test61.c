/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* Only modify testsuite.c
 *Then* run testsuitefiles.sh to generate the test*.c files
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <trajng.h>
#include <warnmalloc.h>
#include "test61.h"

#define FUDGE 1.1 /* 10% off target precision is acceptable */

static void keepinbox(int *val)
{
  while (val[0]>INTMAX1)
    val[0]-=(INTMAX1-INTMIN1+1);
  while (val[0]<INTMIN1)
    val[0]+=(INTMAX1-INTMIN1+1);
  while (val[1]>INTMAX2)
    val[1]-=(INTMAX2-INTMIN2+1);
  while (val[1]<INTMIN2)
    val[1]+=(INTMAX2-INTMIN2+1);
  while (val[2]>INTMAX3)
    val[2]-=(INTMAX3-INTMIN3+1);
  while (val[2]<INTMIN3)
    val[2]+=(INTMAX3-INTMIN3+1);
}

static int intsintable[128]={
0 , 3215 , 6423 , 9615 , 12785 , 15923 , 19023 , 22078 , 
25079 , 28019 , 30892 , 33691 , 36409 , 39039 , 41574 , 44010 , 
46340 , 48558 , 50659 , 52638 , 54490 , 56211 , 57796 , 59242 , 
60546 , 61704 , 62713 , 63570 , 64275 , 64825 , 65219 , 65456 , 
65535 , 65456 , 65219 , 64825 , 64275 , 63570 , 62713 , 61704 , 
60546 , 59242 , 57796 , 56211 , 54490 , 52638 , 50659 , 48558 , 
46340 , 44010 , 41574 , 39039 , 36409 , 33691 , 30892 , 28019 , 
25079 , 22078 , 19023 , 15923 , 12785 , 9615 , 6423 , 3215 , 
0 , -3215 , -6423 , -9615 , -12785 , -15923 , -19023 , -22078 , 
-25079 , -28019 , -30892 , -33691 , -36409 , -39039 , -41574 , -44010 , 
-46340 , -48558 , -50659 , -52638 , -54490 , -56211 , -57796 , -59242 , 
-60546 , -61704 , -62713 , -63570 , -64275 , -64825 , -65219 , -65456 , 
-65535 , -65456 , -65219 , -64825 , -64275 , -63570 , -62713 , -61704 , 
-60546 , -59242 , -57796 , -56211 , -54490 , -52638 , -50659 , -48558 , 
-46340 , -44010 , -41574 , -39039 , -36409 , -33691 , -30892 , -28019 , 
-25079 , -22078 , -19023 , -15923 , -12785 , -9615 , -6423 , -3215 , 
};

static int intsin(int i)
{
  int sign=1;
  if (i<0)
    {
      i=0;
      sign=-1;
    }
  return sign*intsintable[i%128];
}

static int intcos(int i)
{
  if (i<0)
    i=0;
  return intsin(i+32);
}

static void molecule(int *target, 
		     int *base,
		     int length,
		     int scale, int *direction,
		     int flip,
		     int iframe)
{
  int i;
  for (i=0; i<length; i++)
    {
      int ifl=i;
      if ((i==0) && (flip) && (length>1))
	ifl=1;
      else if ((i==1) && (flip) && (length>1))
	ifl=0;
      target[ifl*3]=base[0]+(intsin((i+iframe)*direction[0])*scale)/256;
      target[ifl*3+1]=base[1]+(intcos((i+iframe)*direction[1])*scale)/256;
      target[ifl*3+2]=base[2]+(intcos((i+iframe)*direction[2])*scale)/256;
      keepinbox(target+ifl*3);
    }
}

#ifndef FRAMESCALE
#define FRAMESCALE 1
#endif

static void genibox(int *intbox, int iframe)
{
  int molecule_length=1;
  int molpos[3];
  int direction[3]={1,1,1};
  int scale=1;
  int flip=0;
  int i=0;
  molpos[0]=intsin(iframe*FRAMESCALE)/32;
  molpos[1]=1+intcos(iframe*FRAMESCALE)/32;
  molpos[2]=2+intsin(iframe*FRAMESCALE)/16;
  keepinbox(molpos);
  while (i<NATOMS)
    {
      int this_mol_length=molecule_length;
      int dir;
#ifdef REGULAR
      this_mol_length=4;
      flip=0;
      scale=1;
#endif
      if (i+this_mol_length>NATOMS)
	this_mol_length=NATOMS-i;
      /* We must test the large rle as well. This requires special
	 sequencies to get triggered. So insert these from time to
	 time */
#ifndef REGULAR
      if ((i%10)==0)
	{
	  int j;
	  intbox[i*3]=molpos[0];
	  intbox[i*3+1]=molpos[1];
	  intbox[i*3+2]=molpos[2];
	  for (j=1; j<this_mol_length; j++)
	    {
	      intbox[(i+j)*3]=intbox[(i+j-1)*3]+(INTMAX1-INTMIN1+1)/5;
	      intbox[(i+j)*3+1]=intbox[(i+j-1)*3+1]+(INTMAX2-INTMIN2+1)/5;
	      intbox[(i+j)*3+2]=intbox[(i+j-1)*3+2]+(INTMAX3-INTMIN3+1)/5;
	      keepinbox(intbox+(i+j)*3);
	    }
	}
      else
#endif
	molecule(intbox+i*3,molpos,this_mol_length,scale,direction,flip,iframe*FRAMESCALE);
      i+=this_mol_length;
      dir=1;
      if (intsin(i*3)<0)
	dir=-1;
      molpos[0]+=dir*(INTMAX1-INTMIN1+1)/20;
      dir=1;
      if (intsin(i*5)<0)
	dir=-1;
      molpos[1]+=dir*(INTMAX2-INTMIN2+1)/20;
      dir=1;
      if (intsin(i*7)<0)
	dir=-1;
      molpos[2]+=dir*(INTMAX3-INTMIN3+1)/20;
      keepinbox(molpos);
      
      direction[0]=((direction[0]+1)%7)+1;
      direction[1]=((direction[1]+1)%3)+1;
      direction[2]=((direction[2]+1)%6)+1;

      scale++;
      if (scale>5)
	scale=1;

      molecule_length++;
      if (molecule_length>30)
	molecule_length=1;
      if (i%9)
	flip=1-flip;
    }
}

static void genivelbox(int *intvelbox, int iframe)
{
  int i;
  for (i=0; i<NATOMS; i++)
    {
#ifdef VELINTMUL
      intvelbox[i*3]=((intsin((i+iframe*FRAMESCALE)*3))/10)*VELINTMUL+i;
      intvelbox[i*3+1]=1+((intcos((i+iframe*FRAMESCALE)*5))/10)*VELINTMUL+i;
      intvelbox[i*3+2]=2+((intsin((i+iframe*FRAMESCALE)*7)+intcos((i+iframe*FRAMESCALE)*9))/20)*VELINTMUL+i;
#else
      intvelbox[i*3]=((intsin((i+iframe*FRAMESCALE)*3))/10);
      intvelbox[i*3+1]=1+((intcos((i+iframe*FRAMESCALE)*5))/10);
      intvelbox[i*3+2]=2+((intsin((i+iframe*FRAMESCALE)*7)+intcos((i+iframe*FRAMESCALE)*9))/20);
#endif
    }
}

#ifndef STRIDE1
#define STRIDE1 3
#endif

#ifndef STRIDE2
#define STRIDE2 3
#endif

#ifndef GENPRECISION
#define GENPRECISION PRECISION
#endif

#ifndef GENVELPRECISION
#define GENVELPRECISION VELPRECISION
#endif

static void realbox(int *intbox, REAL *realbox, int stride)
{
  int i,j;
  for (i=0; i<NATOMS; i++)
    {
      for (j=0; j<3; j++)
	realbox[i*stride+j]=(REAL)(intbox[i*3+j]*GENPRECISION*SCALE);
      for (j=3; j<stride; j++)
	realbox[i*stride+j]=0.;
    }
}

static void realvelbox(int *intbox, REAL *realbox, int stride)
{
  int i,j;
  for (i=0; i<NATOMS; i++)
    {
      for (j=0; j<3; j++)
	realbox[i*stride+j]=(REAL)(intbox[i*3+j]*GENVELPRECISION*SCALE);
      for (j=3; j<stride; j++)
	realbox[i*stride+j]=0.;
    }
}

static int equalarr(REAL *arr1, REAL *arr2, REAL prec, int len, int itemlen, int stride1, int stride2)
{
  REAL maxdiff=0.;
  int i,j;
  for (i=0; i<len; i++)
    {
      for (j=0; j<itemlen; j++)
	if (fabs(arr1[i*stride1+j]-arr2[i*stride2+j])>maxdiff)
	  maxdiff=(REAL)fabs(arr1[i*stride1+j]-arr2[i*stride2+j]);
    }
  if (maxdiff>prec*0.5*FUDGE)
    {
#if 0
      fprintf(stderr,"Error is %g. Acceptable error is %g.\n",maxdiff,prec*0.5*FUDGE);
#endif
      return 0;
    }
  else
    return 1;
}

#ifndef WRITEBOX
#define WRITEBOX 1
#endif

#ifdef PROGSPECTEST
#define PROGINFO "Trajng testsuite"
#ifndef ALGOTEST
#define ALGOTEST
#endif
#endif

#ifdef ATOMLABELTEST
#ifndef ALGOTEST
#define ALGOTEST
#endif
#endif

#ifdef SEEKTEST
#ifndef ALGOTEST
#define ALGOTEST
#endif
#endif

#ifndef EXPECTED_FILESIZE
#define EXPECTED_FILESIZE 1
#endif

#ifndef COMPATIBILITY_MODE
#define COMPATIBILITY_MODE 0
#endif

/* Version 1.0 did not do inter-frame compression of velocities, so a
   large part of the testsuite has not been setup for this
   explicitly. So add them here. */
#ifndef INITIALVELCODING
#define INITIALVELCODING -1
#endif
#ifndef INITIALVELCODINGPARAMETER
#define INITIALVELCODINGPARAMETER -1
#endif

#ifdef ALGOTEST
/* Return value 1 means file error.
   Return value 2 means read crc failure
   Return value 3 means frame out of sync error
   Return value 4 means coding error in coordinates.
   Return value 5 means coding error in velocities.
   Return value 6 means coding error in H matrix.
   Return value 7 means coding error in time.
   Return value 8 means coding error in lambda.
   Return value 9 means filesize seems too off.

   Return value 100+ means test specific error.
 */
static int algotest()
{
  int i;
  int *intbox=warnmalloc(NATOMS*3*sizeof *intbox);
  int *intvelbox=warnmalloc(NATOMS*3*sizeof *intvelbox);
  REAL *box1=warnmalloc(NATOMS*STRIDE1*sizeof *box1);
  REAL *velbox1=warnmalloc(NATOMS*STRIDE1*sizeof *velbox1);
  REAL time1, lambda1;
  REAL H1[9];
  int startframe=0;
  int endframe=NFRAMES;
#ifdef GEN
  FILE *file;
  double filesize;
#else
  int i2;
  int readreturn;
  REAL H2[9];
  REAL time2, lambda2;
  REAL *box2=warnmalloc(NATOMS*STRIDE2*sizeof *box2);
  REAL *velbox2=warnmalloc(NATOMS*STRIDE2*sizeof *velbox2);
#endif
#ifdef PROGSPECTEST
  char *proginfo;
#endif
#ifdef ATOMLABELTEST
  char **atomlabels;
  char **atomlabels2;
#endif
#ifdef GEN
  void *dumpfile=TrajngOpenWriteSpecify(FILENAME,NATOMS,CHUNKY,PRECISION,
					WRITEBOX,
					WRITEVEL,VELPRECISION,
					COMPATIBILITY_MODE,
					INITIALCODING,
					INITIALCODINGPARAMETER,CODING,CODINGPARAMETER,
					INITIALVELCODING,INITIALVELCODINGPARAMETER,
					VELCODING,VELCODINGPARAMETER,5,0);
#else
  void *dumpfile=TrajngOpenReadSpecify(FILENAME,COMPATIBILITY_MODE);
#endif
  if (!dumpfile)
    return 1;
#ifdef SHOW_COMPATIBILITY_WARNING
  if (TrajngGetCompatibilityMode(dumpfile))
    fprintf(stderr,"WARNING: This system is not default mode capable. All tests are run in compatibility mode!\n");
#endif
#ifdef PROGSPECTEST
#ifdef GEN
  TrajngSetProgramInfo(dumpfile,PROGINFO);
#else
  proginfo=TrajngGetProgramInfo(dumpfile);
  if (!proginfo)
    return 100;
  if (strcmp(proginfo,PROGINFO))
    return 101;
#endif
#endif

#ifdef ATOMLABELTEST
  atomlabels=warnmalloc(NATOMS*sizeof *atomlabels);
  for (i=0; i<NATOMS; i++)
    {
      atomlabels[i]=warnmalloc(13);
      sprintf(atomlabels[i],"A%d",i);
    }
#ifdef GEN
  TrajngSetAtomLabels(dumpfile,atomlabels);
#else
  atomlabels2=TrajngGetAtomLabels(dumpfile);
  if (!atomlabels2)
    return 100;
  for (i=0; i<NATOMS; i++)
    {
      if (strcmp(atomlabels2[i],atomlabels[i]))
	return 101;
    }
#endif  
#endif

  for (i=0; i<9; i++)
    H1[i]=0.;
  H1[0]=INTMAX1*PRECISION*SCALE;
  H1[4]=INTMAX2*PRECISION*SCALE;
  H1[8]=INTMAX3*PRECISION*SCALE;
#ifndef GEN
#ifdef SEEKTEST
  startframe=SEEKTO;
  endframe=SEEKTO+READNFRAMES;
  printf("Seeking to frame %d...",SEEKTO);
  fflush(stdout);
  if (TrajngSeek(dumpfile,startframe))
    return 100;
  printf("done\n");
  fflush(stdout);
#endif
#endif
  for (i=startframe; i<endframe; i++)
    {
      genibox(intbox,i);
      realbox(intbox,box1,STRIDE1);
#if WRITEVEL
      genivelbox(intvelbox,i);
      realvelbox(intvelbox,velbox1,STRIDE1);
#endif
  time1=(REAL)i;
  lambda1=(REAL)(i+100);
#ifdef GEN
#if ISDOUBLE
  TrajngWrite(dumpfile,H1,box1,velbox1,STRIDE1,i,time1,lambda1);
#else
  TrajngWritef(dumpfile,H1,box1,velbox1,STRIDE1,i,time1,lambda1);
#endif
#else
  if (TrajngReadTry(dumpfile))
    return 1;
#if ISDOUBLE
  readreturn=TrajngRead(dumpfile,H2,box2,velbox2,STRIDE2,&i2,&time2,&lambda2);
#else
  readreturn=TrajngReadf(dumpfile,H2,box2,velbox2,STRIDE2,&i2,&time2,&lambda2);
#endif
  if (readreturn==1) /* general read error  */
    return 1;
  else if (readreturn==2) /* CRC failure */
    return 2;
  else if (readreturn==3) /* frame out of sync error   */
    return 3;
#endif
#ifndef GEN
#if 0
  {
    int j;
    for (j=0; j<NATOMS; j++)
      printf("%d: %g %g %g --- %g %g %g\n",j,box1[j*3],box1[j*3+1],box1[j*3+2],box2[j*3],box2[j*3+1],box2[j*3+2]);
    exit(1);
  }
#endif
  /* Check for equality of boxes. */
  if (!equalarr(box1,box2,(REAL)PRECISION,NATOMS,3,STRIDE1,STRIDE2))
    return 4;
#if WRITEVEL
  if (!equalarr(velbox1,velbox2,(REAL)VELPRECISION,NATOMS,3,STRIDE1,STRIDE2))
    return 5;
#endif
#if WRITEBOX
  if (!equalarr(H1,H2,(REAL)PRECISION,9,1,1,1))
    return 6;
#endif
  if (!equalarr(&time1,&time2,(REAL)PRECISION,1,1,1,1))
    return 7;
  if (!equalarr(&lambda1,&lambda2,(REAL)PRECISION,1,1,1,1))
    return 8;
#endif
    }
  TrajngClose(dumpfile);
#ifdef GEN
  /* Check against expected filesize for this test. */
  if (!(file=fopen(FILENAME,"rb")))
    {
      fprintf(stderr,"ERROR: Cannot open file "FILENAME"\n");
      exit(EXIT_FAILURE);
    }
  filesize=Trajngfsize(file);
  fclose(file);
  if (filesize>0)
    {
      if ((fabs(filesize-EXPECTED_FILESIZE)/EXPECTED_FILESIZE)>0.05)
	return 9;
    }
#endif
  return 0;
}
#endif

int main()
{
  int testval;
  if (sizeof(int)<4)
    {
      fprintf(stderr,"ERROR: sizeof(int) is too small: %d<4\n",(int)sizeof(int));
      exit(EXIT_FAILURE);
    }
#ifdef GEN
  printf("Trajng testsuite generating test: %s\n",TESTNAME);
#else
  printf("Trajng testsuite running test: %s\n",TESTNAME);
#endif
#ifdef ALGOTEST
  testval=algotest();
#ifdef DIFFPRECISION
  if (testval==0)
    {
      printf("ERROR: Testsuite failed.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==1)
    {
      printf("ERROR: File error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==2)
    {
      printf("ERROR: Read CRC error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==3)
    {
      printf("ERROR: Read frame out of sync error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==4)
    printf("Passed.\n");
  else if (testval==5)
    printf("Passed.\n");
  else if (testval==6)
    printf("Passed.\n");
  else if (testval==7)
    printf("Passed.\n");
  else if (testval==8)
    printf("Passed.\n");
  else if (testval==9)
    {
      printf("ERROR: Generated filesize differs too much.\n");
      exit(EXIT_FAILURE);
    }
  else
    {
      printf("ERROR: Unknown error.\n");
      exit(EXIT_FAILURE);
    }
#else
  if (testval==0)
    printf("Passed.\n");
  else if (testval==1)
    {
      printf("ERROR: File error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==2)
    {
      printf("ERROR: Read CRC error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==3)
    {
      printf("ERROR: Read frame out of sync error.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==4)
    {
      printf("ERROR: Read coding error in coordinates.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==5)
    {
      printf("ERROR: Read coding error in velocities.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==6)
    {
      printf("ERROR: Read coding error in H-matrix.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==7)
    {
      printf("ERROR: Read coding error in time.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==8)
    {
      printf("ERROR: Read coding error in lambda.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==9)
    {
      printf("ERROR: Generated filesize differs too much.\n");
      exit(EXIT_FAILURE);
    }
#ifdef PROGSPECTEST
  else if (testval==100)
    {
      printf("ERROR: File does not contain program specific information.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==101)
    {
      printf("ERROR: File contains wrong program specific information.\n");
      exit(EXIT_FAILURE);
    }
#endif
#ifdef ATOMLABELTEST
  else if (testval==100)
    {
      printf("ERROR: File does not contain atom labels.\n");
      exit(EXIT_FAILURE);
    }
  else if (testval==101)
    {
      printf("ERROR: File contains wrong atom labels.\n");
      exit(EXIT_FAILURE);
    }
#endif
#ifdef SEEKTEST
  else if (testval==100)
    {
      printf("ERROR: Seek reported error.\n");
      exit(EXIT_FAILURE);
    }
#endif
  else
    {
      printf("ERROR: Unknown error.\n");
      exit(EXIT_FAILURE);
    }
#endif
#endif
  return 0;
}
