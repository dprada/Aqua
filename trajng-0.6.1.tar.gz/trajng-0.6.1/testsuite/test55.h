#define TESTNAME "Stride 4/3."
#define FILENAME "test55.tng"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 10
#define SCALE 0.1
#define PRECISION 0.01
#define WRITEVEL 1
#define VELPRECISION 0.1
#define INITIALCODING -1
#define INITIALCODINGPARAMETER -1
#define CODING -1
#define CODINGPARAMETER -1
#define VELCODING -1
#define VELCODINGPARAMETER -1
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 100
#define REAL double
#define ISDOUBLE 1
#define STRIDE1 4
#define STRIDE2 3

#define EXPECTED_FILESIZE 186300.
