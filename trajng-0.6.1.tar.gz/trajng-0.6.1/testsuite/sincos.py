from math import *

print "static int intsin[128]={"
for i in range(128):
    print int(65535*sin(i*2*pi/128)),",",
    if (i+1)%8==0:
        print ""
print "};"
