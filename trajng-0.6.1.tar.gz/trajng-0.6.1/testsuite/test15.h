#define TESTNAME "Initial velocity coding. Triple algorithm. Cubic cell. Double precision."
#define FILENAME "test15.tng"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 1
#define SCALE 0.1
#define PRECISION 0.01
#define WRITEVEL 1
#define VELPRECISION 0.1
#define INITIALCODING 3
#define INITIALCODINGPARAMETER -1
#define CODING 3
#define CODINGPARAMETER -1
#define INITIALVELCODING 3
#define INITIALVELCODINGPARAMETER -1
#define VELCODING 3
#define VELCODINGPARAMETER -1
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 1000
#define REAL double
#define ISDOUBLE 1
#define EXPECTED_FILESIZE 7129840.
