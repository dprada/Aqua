#define TESTNAME "Velocity coding. Compatibility mode."
#define FILENAME "test91.tng"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 100
#define SCALE 0.1
#define PRECISION 0.01
#define WRITEVEL 1
#define VELPRECISION 0.1
#define INITIALCODING 3
#define INITIALCODINGPARAMETER -1
#define CODING 3
#define CODINGPARAMETER -1
#define VELCODING 3
#define VELCODINGPARAMETER -1
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 1000
#define REAL double
#define ISDOUBLE 1
#define COMPATIBILITY_MODE 1
#define EXPECTED_FILESIZE 7042740.
