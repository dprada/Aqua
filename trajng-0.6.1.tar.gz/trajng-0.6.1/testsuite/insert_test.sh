#!/bin/sh

if [ -z "$1" ]; then
    exit 1
fi

max=200

for x in $(seq 200 -1 $1); do
    let y=$x+1
    if [ -r test$x.h ]; then
	sed "s/test$x/test$y/" <test$x.h >test$y.h
    fi
done