check_PROGRAMS=""
for x in range(1,109):
    check_PROGRAMS+=" gen"+`x`+" run"+`x`
    print "gen"+`x`+"_SOURCES = test"+`x`+".c test"+`x`+".h"
    print "gen"+`x`+"_CFLAGS = -DGEN"
    print "run"+`x`+"_SOURCES = test"+`x`+".c test"+`x`+".h"
print "check_PROGRAMS = "+check_PROGRAMS

    
