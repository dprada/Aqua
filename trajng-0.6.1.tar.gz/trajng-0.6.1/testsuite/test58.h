#define TESTNAME "Initial coding. XTC3 algorithm. High accuracy. Cubic cell. Double precision."
#define FILENAME "test58.tng"
#define ALGOTEST
#define NATOMS 100000
#define CHUNKY 1
#define SCALE 0.5
#define PRECISION 1e-8
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING 10
#define INITIALCODINGPARAMETER 0
#define CODING 1
#define CODINGPARAMETER -1
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 1610612736
#define INTMAX2 1610612736
#define INTMAX3 1610612736
#define NFRAMES 10
#define REAL double
#define ISDOUBLE 1
#define EXPECTED_FILESIZE 3784838.
