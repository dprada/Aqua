/* NOTE: Inter frame XTC2 does differences of differences, so 
   it can do one bit less than the other algorithms! */
#define TESTNAME "Position coding. Inter frame XTC2 algorithm. Large system. Cubic cell. Double precision."
#define FILENAME "test44.tng"
#define ALGOTEST
#define NATOMS 5000000
#define CHUNKY 2
#define SCALE 1.
#define PRECISION 1.
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING 5
#define INITIALCODINGPARAMETER 0
#define CODING 4
#define CODINGPARAMETER 0
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 -268435455
#define INTMIN2 -268435455
#define INTMIN3 -268435455
#define INTMAX1 268435455
#define INTMAX2 268435455
#define INTMAX3 268435455
#define NFRAMES 10
#define REAL double
#define ISDOUBLE 1
#define EXPECTED_FILESIZE 226013513.
