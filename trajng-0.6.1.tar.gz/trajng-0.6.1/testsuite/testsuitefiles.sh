#!/bin/sh
for testnum in $(seq 1 108); do
    echo Generating test$testnum
    sed "s/TESTPARAM/\"test$testnum.h\"/" <testsuite.c >test$testnum.c
done
