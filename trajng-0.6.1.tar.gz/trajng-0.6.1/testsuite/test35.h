#define TESTNAME "Initial coding. Autoselect algorithm. Repetitive molecule. Cubic cell. Double precision."
#define FILENAME "test35.tng"
#define ALGOTEST
#define NATOMS 1000
#define CHUNKY 1
#define SCALE 0.1
#define REGULAR
#define PRECISION 0.01
#define WRITEVEL 0
#define VELPRECISION 0.1
#define INITIALCODING -1
#define INITIALCODINGPARAMETER -1
#define CODING 1
#define CODINGPARAMETER 0
#define VELCODING 4
#define VELCODINGPARAMETER 0
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 10000
#define INTMAX2 10000
#define INTMAX3 10000
#define NFRAMES 1000
#define REAL double
#define ISDOUBLE 1
#define EXPECTED_FILESIZE 1765705.
