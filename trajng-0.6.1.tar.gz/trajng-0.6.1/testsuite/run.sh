#!/bin/sh
for testnum in $(seq 1 108); do
    ./run$testnum
done
