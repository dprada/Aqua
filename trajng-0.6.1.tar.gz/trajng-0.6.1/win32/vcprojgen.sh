#!/bin/sh
# I prepared the gen1.vcproj and run1.vcproj files to be good, then this generates the rest automatically. Only thing left to do to add them all to the solution and add dependencies.
for testnum in $(seq 102 108); do
    sed "s/gen1/gen$testnum/g" <gen1.vcproj |sed "s/test1\.c/test$testnum.c/" >gen$testnum.vcproj
    sed "s/run1/run$testnum/g" <run1.vcproj |sed "s/test1\.c/test$testnum.c/">run$testnum.vcproj
done


