/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* This file is included into other source files to support
   double/float easily (via simple macros). */

/* NOTE: The number of
   local atoms should be sent in the natoms argument and a map array
   of length natoms should contain the global number of each atom. If
   replicated data is used (all ranks have the same data and in the
   same order), give the total number of atoms as the natoms argument
   and give map as NULL. */

#if 0
#define SHOWIT
#endif

int TRAJNGMPIWRITE(void *handle,REAL *H,
		   REAL *coords,REAL *vels,
		   int stride,
		   int framenumber,
		   REAL time,
		   REAL lambda,
		   int natoms, int *map)
{
  struct trajngmpi *trajngmpi=(struct trajngmpi *)handle;
  
  int rval=0;

  int i, j;
  double *target_base; /* For copying. */
  REAL *source_ptr; /* For copying. */
  int total_natoms=trajngmpi->total_natoms; /* Less pointer dereferencing by moving this closer. */
  int *map_global=trajngmpi->map; /* Also for preventing pointer dereferencing */
  int replicated_data;

  /* Which rank should receive this data? */
  int root=trajngmpi->nframes/trajngmpi->chunky;

  /* Type for getting the data */
  MPI_Datatype my_strided_vector;
  
  if ((natoms==total_natoms) && (!map)) /* Replicated data so no map needed (or allowed) */
    replicated_data=1;
  else
    replicated_data=0;

#if 0
  printf("REPL: %d\n",replicated_data);
  fflush(stdout);
#endif

  if ((!map) && (natoms!=total_natoms) && (natoms!=0))
    return 1; /* Can't write domain. decomp data without the map (unless there are no atoms to write) */

  if (!replicated_data)
    {
      /* We use domain decomposition. Gather the data from the nodes. */

      /* Begin by finding the number of local atoms. */
      MPI_Gather(&natoms, 1, MPI_INT, trajngmpi->natoms, 1,
		 MPI_INT, root, trajngmpi->comm);

      if (trajngmpi->rank==root)
	{
	  /* Calculate displacements for map. */
	  trajngmpi->displs[0]=0;
	  for (i=1; i<trajngmpi->size; i++)
	    trajngmpi->displs[i]=trajngmpi->displs[i-1]+trajngmpi->natoms[i-1];
	}

#ifdef SHOWIT
      fprintf(stderr,"Rank %d: Global number of frames: %d. Stored frames: %d. Local frames: %d. Current root is %d.\n",trajngmpi->rank,
	      trajngmpi->global_frame_counter, trajngmpi->nframes, trajngmpi->local_frames,root);
      fflush(stderr);
#endif
  
#ifdef SHOWIT
      fprintf(stderr,"Rank %d before map MPI_Gatherv\n",trajngmpi->rank);
      fflush(stderr);
#endif

#ifdef SHOWIT
      fprintf(stderr,"Rank %d will send %d atoms\n",trajngmpi->rank,natoms);
      fflush(stderr);
#endif

#ifdef SHOWIT
      if (trajngmpi->rank==root)
	{
	  for (i=0; i<trajngmpi->size; i++)
	    {
	      fprintf(stderr,"Rank %d expects %d atoms from rank %d.\n",trajngmpi->rank,trajngmpi->natoms[i],i);
	      fflush(stderr);
	    }
	}
#endif

      /* Then we get the map. */
      MPI_Gatherv(map, natoms, MPI_INT, map_global, trajngmpi->natoms,
		  trajngmpi->displs,MPI_INT,root,trajngmpi->comm);

#ifdef SHOWIT
      fprintf(stderr,"Rank %d after map MPI_Gatherv\n",trajngmpi->rank);
      fflush(stderr);
#endif

      if (trajngmpi->rank==root)
	{
	  /* Calculate displacements for coordinates (and velocities). */
	  trajngmpi->displs[0]=0;
	  for (i=1; i<trajngmpi->size; i++)
	    trajngmpi->displs[i]=trajngmpi->displs[i-1]+trajngmpi->natoms[i-1]*3;

	  /* Calculate receive counts for coordinates (and velocities). */
	  for (i=0; i<trajngmpi->size; i++)
	    trajngmpi->recvcounts[i]=trajngmpi->natoms[i]*3;
	}

#ifdef SHOWIT
      fprintf(stderr,"Rank %d before coordinates MPI_Gatherv\n",trajngmpi->rank);
      fflush(stderr);
#endif

      /* Create the vector for sending the data */
      MPI_Type_vector(natoms,3,stride,MY_COMM_TYPE,&my_strided_vector);
      MPI_Type_commit(&my_strided_vector);

      /* Then we get the coordinates. */
      MPI_Gatherv(coords, 1, my_strided_vector,
		  (REAL*)trajngmpi->recvtmp,
		  trajngmpi->recvcounts,
		  trajngmpi->displs,MY_COMM_TYPE,root,trajngmpi->comm);

#ifdef SHOWIT
      fprintf(stderr,"Rank %d after coordinates MPI_Gatherv\n",trajngmpi->rank);
      fflush(stderr);
#endif

      if (trajngmpi->rank==root)
	{
	  /* Rearrange coordinates according to the map */
	  target_base=trajngmpi->coords+trajngmpi->local_frames*total_natoms*3;
	  source_ptr=(REAL*)trajngmpi->recvtmp;
	  for (i=0; i<total_natoms; i++)
	    {
	      int remap=map_global[i];
	      for (j=0; j<3; j++)
		target_base[remap*3+j]=(double)(*source_ptr++);
	    }
	}

      /* Should we receive velocities? */
      if (trajngmpi->vels)
	{
	  MPI_Gatherv(vels, 1, my_strided_vector,
		      (REAL*)trajngmpi->recvtmp,
		      trajngmpi->recvcounts,
		      trajngmpi->displs,MY_COMM_TYPE,root,trajngmpi->comm);

	  if (trajngmpi->rank==root)
	    {
	      /* Rearrange velocities according to the map */
	      target_base=trajngmpi->vels+trajngmpi->local_frames*total_natoms*3;
	      source_ptr=(REAL*)trajngmpi->recvtmp;
	      for (i=0; i<total_natoms; i++)
		{
		  int remap=map_global[i];
		  for (j=0; j<3; j++)
		    target_base[remap*3+j]=(double)(*source_ptr++);
		}
	    }
	}

    }
  else
    {
      /* We use replicated data. We just need to copy the data. We
	 should only do this if we are the root rank.  We cannot use memcpy
	 since target and source may have different types. */
      if (trajngmpi->rank==root)
	{
	  /* Copy coordinates. */
	  target_base=trajngmpi->coords+trajngmpi->local_frames*total_natoms*3;
	  for (i=0; i<total_natoms; i++)
	    for (j=0; j<3; j++)
	      target_base[i*3+j]=(double)coords[i*stride+j];
	  /* If we have velocities, copy them */
	  if (trajngmpi->vels)
	    {
	      target_base=trajngmpi->vels+trajngmpi->local_frames*total_natoms*3;
	      for (i=0; i<total_natoms; i++)
		for (j=0; j<3; j++)
		  target_base[i*3+j]=(double)vels[i*stride+j];
	    }
	}
#if 0
      if (trajngmpi->rank==root)
	for (i=0; i<total_natoms; i++)
	  for (j=0; j<3; j++)
	    printf("%d %d %d %g\n",trajngmpi->local_frames,i,j,coords[i*stride+j]);
#endif
    }
  
  /* And perhaps store the box. This should be the same everywhere, so
     no need for communication! Only store it if my rank is the root! */
  if (trajngmpi->H)
    if (trajngmpi->rank==root)
      for (i=0; i<9; i++)
	trajngmpi->H[trajngmpi->local_frames*9+i]=H[i];
  
  /* And framenumber, time, and lambda. This should also be the same
     everywhere. Store if my rank is the root. */
  if (trajngmpi->rank==root)
    {
      trajngmpi->framenumber[trajngmpi->local_frames]=framenumber;
      trajngmpi->time[trajngmpi->local_frames]=time;
      trajngmpi->lambda[trajngmpi->local_frames]=lambda;
    }

  /* If that was at my rank increase local counter */
  if (trajngmpi->rank==root)
    {
      /* If this is the first frame, I need to know the global id of
	 this first frame. */
      if (trajngmpi->local_frames==0)
	trajngmpi->glocal_id=trajngmpi->global_frame_counter;
      trajngmpi->local_frames++;
    }

  /* We have stored one more frame. */
  trajngmpi->nframes++;
  trajngmpi->global_frame_counter++;

  /* Time for compression? We do not close the buffer. */
  if (trajngmpi->nframes==trajngmpi->maxframes)
    rval=compress_and_flush(trajngmpi,0);

  if (!replicated_data)
    {
      /* Finally free the MPI type */
      MPI_Type_free(&my_strided_vector);
    }

  return rval;
}
