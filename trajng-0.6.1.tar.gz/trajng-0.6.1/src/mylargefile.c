/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/
/* Some operations to handle large files using 64 bit operations */
/* Also contains some semi-portable code. Currently this works on UNIX
   and WINDOWS. */

#if HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdio.h>
#include <stdlib.h>

#include "trajng.h"

#include "my64bit.h"

#ifndef TRAJNG_FORCE_COMPATIBLE
#ifndef HAVE64BIT
#error A 64 BIT INTEGER TYPE IS REQUIRED TO BE ABLE TO HANDLE SEEKS. PLEASE SEE my64bit.h. IF YOU PREFER TO RUN WITHOUT SEEKS AND 64 BIT INTEGERS DEFINE TRAJNG_FORCE_COMPATIBLE
#endif /* HAVE64BIT */
#endif /* TRAJNG_FORCE_COMPATIBLE */

#ifndef TRAJNG_FORCE_COMPATIBLE

#ifdef USE_WINDOWS
#include <windows.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#else /* USE_WINDOWS */
/* UNIX */
#if HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#if HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#endif /* USE_WINDOWS */

#include "mylargefile.h"

int my_ftruncate(FILE *file,my_int64_t length)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
#ifdef USE_WINDOWS
  int fd=_fileno(file);
  return _chsize_s(fd,length);
#else /* USE_WINDOWS */
  /* UNIX */
  int fd=fileno(file);
  return ftruncate(fd,(off_t) length);
#endif /* USE_WINDOWS */
#else
  return 1;
#endif
}

int my_off_t_is_too_small()
{
#ifndef USE_WINDOWS
  /* UNIX */
#if HAVE_FSEEKO
  if (sizeof(off_t)<8)
    return 1;
#else
  return 1;
#endif
#endif
  return 0;
}

int my_fseek(FILE *file, my_int64_t offset, int whence)
{
#ifdef USE_WINDOWS
  return _fseeki64(file,offset,whence);
#else /* USE_WINDOWS */
  /* UNIX */
#if HAVE_FSEEKO
  return fseeko(file,(off_t) offset,whence);
#endif
#endif
}

my_int64_t my_ftell(FILE *file)
{
#ifdef USE_WINDOWS
  return _ftelli64(file);
#else /* USE_WINDOWS */
  /* UNIX */
#if HAVE_FSEEKO
  return (my_int64_t) ftello(file);
#endif
#endif
}
#endif /* TRAJNG_FORCE_COMPATIBLE */

/* Returns a double(!) to not to have to "pollute" the
   programs using this library with 64 bit int dependencies.
   If file sizes cannot be determined a negative value is returned.
 */
double DECLSPECDLLEXPORT Trajngfsize(FILE *file)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
#ifdef USE_WINDOWS
  struct __stat64 buf;
  my_uint64_t s64;
  if (_fstat64(_fileno(file),&buf))
    {
      fprintf(stderr,"TRAJNG: Failed to stat file.\n");
      exit(EXIT_FAILURE);
    }
  s64=(my_uint64_t) buf.st_size;
  return (double)s64;  
#else /* USE_WINDOWS */
  struct stat buf;
  my_uint64_t s64;
  if (fstat(fileno(file),&buf))
    {
      fprintf(stderr,"TRAJNG: Failed to stat file.\n");
      exit(EXIT_FAILURE);
    }
  s64=(my_uint64_t) buf.st_size;
  return (double)s64;
#endif /* USE_WINDOWS */
#else /* TRAJNG_FORCE_COMPATIBLE */
  return -1.;
#endif /* TRAJNG_FORCE_COMPATIBLE */
}
