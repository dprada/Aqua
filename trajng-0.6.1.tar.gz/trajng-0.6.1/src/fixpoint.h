/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/
#ifndef FIXPOINT_H
#define FIXPOINT_H

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include "my64bit.h"

/* There are at least 32 bits available in a long. */
typedef unsigned long fix_t;

/* Positive double to 32 bit fixed point value */
fix_t ud_to_fix_t(double d,double max);

/* double to signed 32 bit fixed point value */
fix_t d_to_fix_t(double d,double max);

/* 32 bit fixed point value to positive double */
double fix_t_to_ud(fix_t f, double max);

/* signed 32 bit fixed point value to double */
double fix_t_to_d(fix_t f, double max);

/* Write 16 bits */
size_t writefix16(FILE *file, fix_t f);

/* Write 32 bits */
size_t writefix32(FILE *file, fix_t f);

/* Read 16 bits */
size_t readfix16(FILE *file, fix_t *f);

/* Read 32 bits */
size_t readfix32(FILE *file, fix_t *f);

/* Write positive double as 32 bit fixed point value */
size_t write_ud_to_fix32(FILE *file, double d, double max);

/* Write double as signed 32 bit fixed point value */
size_t write_d_to_fix32(FILE *file, double d, double max);

/* Read positive double as 32 bit fixed point value */
size_t read_fix32_to_ud(FILE *file, double max, double *d);

/* Read double as signed 32 bit fixed point value */
size_t read_fix32_to_d(FILE *file, double max, double *d);

#ifndef TRAJNG_FORCE_COMPATIBLE
/* Write 64 bit unsigned value */
size_t writeuint64(FILE *file, my_uint64_t ui64);

/* Read 64 bit unsigned value */
size_t readuint64(FILE *file, my_uint64_t *ui64);
#endif

/* Convert a floating point variable to two 32 bit integers with range
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
void d_to_i32x2(double d, fix_t *hi, fix_t *lo);

/* Convert two 32 bit integers to a floating point variable
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
double i32x2_to_d(fix_t hi, fix_t lo);

/* Write a floating point variable as two 32 bit integers with range
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
size_t write_d32x2(FILE *file, double d);

/* Read two 32 bit integers and convert them to a floating point variable
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
size_t read_d32x2(FILE *file, double *d);



#endif
