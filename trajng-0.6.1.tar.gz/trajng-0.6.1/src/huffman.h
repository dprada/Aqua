/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef HUFFMAN_H
#define HUFFMAN_H

void comp_conv_to_huffman(unsigned int *vals, int nvals,
			  unsigned int *dict, int ndict,
			  unsigned int *prob,
			  unsigned char *huffman,
			  int *huffman_len,
			  unsigned char *huffman_dict,
			  int *huffman_dictlen,
			  unsigned int *huffman_dict_unpacked,
			  int *huffman_dict_unpackedlen);

void comp_conv_from_huffman(unsigned char *huffman,
			    unsigned int *vals, int nvals,
			    int ndict,
			    unsigned char *huffman_dict,
			    int huffman_dictlen,
			    unsigned int *huffman_dict_unpacked,
			    int huffman_dict_unpackedlen);

#endif
