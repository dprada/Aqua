/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef TRAJNG_H
#define TRAJNG_H

/* Needed because of FILE* */
#include <stdio.h>

#ifndef USE_WINDOWS
#if defined(WIN32) || defined(_WIN32) || defined(WIN64) || defined(_WIN64)
#define USE_WINDOWS
#endif /* win32... */
#endif /* not defined USE_WINDOWS */

#ifdef USE_WINDOWS
#define DECLSPECDLLEXPORT __declspec(dllexport)
#else
#define DECLSPECDLLEXPORT
#endif

#ifdef __cplusplus
 extern "C" {
#endif


/* Call this routine before any other trajng routine if you want to
   change the approximately largest amount of memory used by trajng.  The
   value can be changed by calling TrajngSetMaxMem(int MaxMB) where MaxMB
   is the approximate maximum number of megabytes of memory to use. 
   The default is 1000 (1 GB per process/thread). 
NOTE: This only affects the *creation* of trajectory files. */
void DECLSPECDLLEXPORT TrajngSetMaxMem(int MaxMB);

/* Open a trajectory file for writing with automatic optimization algorithm selection. */
void DECLSPECDLLEXPORT *TrajngOpenWrite(char *name, int natoms, int chunky, double precision,
					int writebox,
					int writevel, double velprecision,
					int compatibility_mode,
					int speed);

/* Set program info string. Do this before writing any frames! */
int DECLSPECDLLEXPORT TrajngSetProgramInfo(void *handle,
			 char *program_info);

/* Set atomic labels. Do this before writing any frames! */
int DECLSPECDLLEXPORT TrajngSetAtomLabels(void *handle,
			char **atom_labels);

/* Write a frame using double precision data */
int DECLSPECDLLEXPORT TrajngWrite(void *handle,double *H,
		double *coords,double *vels,
		int stride,
		int framenumber,
		double time,
		double lambda);

/* Write a frame using single precision data */
int DECLSPECDLLEXPORT TrajngWritef(void *handle,float *H,
		 float *coords,float *vels,
		 int stride,
		 int framenumber,
		 float time,
		 float lambda);

/* Open a trajectory file for reading */
void DECLSPECDLLEXPORT *TrajngOpenRead(char *name);

/* Query a open trajectory file for program info. 
   If none is available NULL is returned. */
char DECLSPECDLLEXPORT *TrajngGetProgramInfo(void *handle);

/* Query a open trajectory file for atom labels.
   If none are available NULL is returned. */
char DECLSPECDLLEXPORT **TrajngGetAtomLabels(void *handle);

/* Query a open trajectory file for the number of atoms */
int DECLSPECDLLEXPORT TrajngNatoms(void *handle);

/* Query a open trajectory file if it has velocities */
int DECLSPECDLLEXPORT TrajngHasVel(void *handle);

/* Query a open trajectory file if it has a box */
int DECLSPECDLLEXPORT TrajngHasBox(void *handle);

/* Try to read a frame from a trajectory file.
   If there are more frames left it returns 0.
   If EOF has been reached it returns 1. */
int DECLSPECDLLEXPORT TrajngReadTry(void *handle);

/* Read a frame from a trajectory file using double precision data */
int DECLSPECDLLEXPORT TrajngRead(void *handle,double *H,
	       double *coords,
	       double *vels,
	       int stride,
	       int *framenumber,
	       double *time,
	       double *lambda);

/* Read a frame from a trajectory file using single precision data */
int DECLSPECDLLEXPORT TrajngReadf(void *handle,float *H,
		float *coords,
		float *vels,
		int stride,
		int *framenumber,
		float *time,
		float *lambda);

/* Go to a specific frame in a trajectory file. */
int DECLSPECDLLEXPORT TrajngSeek(void *handle,int frame);

/* Close a trajectory file (either open for read or write) */
void DECLSPECDLLEXPORT TrajngClose(void *handle);

/* Open a trajectory file for writing with optimization algorithm specification. */
void DECLSPECDLLEXPORT *TrajngOpenWriteSpecify(char *name, int natoms, int chunky, double precision,
					       int writebox,
					       int writevel, double velprecision,
					       int compatibility_mode,
					       int initial_coding, int initial_coding_parameter,
					       int coding, int coding_parameter,
					       int initial_vel_coding, int initial_vel_coding_parameter,
					       int vel_coding, int vel_coding_parameter,
					       int speed, int compute_chunky);

void DECLSPECDLLEXPORT TrajngInfo(void *handle,int *chunky, int *natoms, int *version,
		int *initial_coding, int *initial_coding_parameter,
		int *coding, int *coding_parameter,
		int *vel_coding, int *vel_coding_parameter,
		int *initial_vel_coding, int *initial_vel_coding_parameter,
		double *chosen_precision,
		double *chosen_velprecision);

/* The functions below are mostly useful for trajtool, trajngmpi, or the testsuite. */
int DECLSPECDLLEXPORT TrajngReadNoDecompress(void *handle,double *H,
					     double *coords, double *vels,
					     int stride,
					     int *framenumber,
					     double *time,
					     double *lambda);

void DECLSPECDLLEXPORT *TrajngOpenWriteBuffer(unsigned char *buffer, int natoms, int chunky, double precision,
					      int writebox,
					      int writevel, double velprecision,
					      int compatibility_mode,
					      int initial_coding, int initial_coding_parameter,
					      int coding, int coding_parameter,
					      int initial_vel_coding, int initial_vel_coding_parameter,
					      int vel_coding, int vel_coding_parameter,
					      int speed, int compute_chunky);
char DECLSPECDLLEXPORT *TrajngGetIndexFilename(char *name);
int DECLSPECDLLEXPORT TrajngGetBufferLength(void *handle);
int DECLSPECDLLEXPORT TrajngComputeChunky(int chunky, int natoms, int writevel);
void DECLSPECDLLEXPORT TrajngFlush(void *handle);
void DECLSPECDLLEXPORT TrajngDeinit(void *handle);
void DECLSPECDLLEXPORT TrajngSetFrame(void *handle,int nframe);
void DECLSPECDLLEXPORT TrajngResetBuffer(void *handle);
void DECLSPECDLLEXPORT TrajngIndexAdd(unsigned int blocksize, unsigned int *lo, unsigned int *hi);
int DECLSPECDLLEXPORT TrajngGetHeaderSize(void *handle);
void DECLSPECDLLEXPORT TrajngWrite32(FILE *f, unsigned int v);
void DECLSPECDLLEXPORT *TrajngOpenReadSpecify(char *name, int compatibility_mode);
int DECLSPECDLLEXPORT TrajngGetCompatibilityMode(void *handle);
int DECLSPECDLLEXPORT TrajngGetExternalIndex(void *handle);
void DECLSPECDLLEXPORT *TrajngOpenRepair(char *name);
void DECLSPECDLLEXPORT TrajngGetUnpackInfo(void *handle,int *largest_pattern, int *largest_output,
			 int *max_output);
int DECLSPECDLLEXPORT TrajngGotoFirstChunk(void *handle);
int DECLSPECDLLEXPORT TrajngGotoNextChunk(void *handle);
int DECLSPECDLLEXPORT TrajngGotoNextLargeChunk(void *handle);
int DECLSPECDLLEXPORT TrajngGetLargeChunk(void *handle);
int DECLSPECDLLEXPORT TrajngTruncate(void *handle);
void DECLSPECDLLEXPORT TrajngGetChunkInfo(void *handle,int *at_end,
			unsigned long *sizebig, unsigned long *sizesmall,
			int *ndumps, int *frame_number);

/* Returns a double(!) to not to have to "pollute" the
   programs using this library with 64 bit int dependencies. */
double DECLSPECDLLEXPORT Trajngfsize(FILE *file);

#ifdef __cplusplus
 }
#endif


#endif
