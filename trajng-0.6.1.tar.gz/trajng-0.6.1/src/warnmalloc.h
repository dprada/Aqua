/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef WARNMALLOC_H
#define WARNMALLOC_H

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include "trajng.h"

void DECLSPECDLLEXPORT *Trajng_warnmalloc_x(size_t size, char *file, int line);

#define warnmalloc(size) Trajng_warnmalloc_x(size,__FILE__,__LINE__)

void DECLSPECDLLEXPORT *Trajng_warnrealloc_x(void *old, size_t size, char *file, int line);

#define warnrealloc(old,size) Trajng_warnrealloc_x(old,size,__FILE__,__LINE__)


#endif
