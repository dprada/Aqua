/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#include <string.h>
#include "dict.h"

void comp_canonical_dict(unsigned int *dict, int *ndict)
{
  int i;
  for (i=0; i<0x20004; i++)
    dict[i]=i;
  *ndict=0x20004;
}

void comp_make_dict_hist(unsigned int *vals, int nvals,
			 unsigned int *dict, int *ndict,
			 unsigned int *hist)
{
  int i;
  int j=0;
  for (i=0; i<0x20004; i++)
    hist[i]=0;
  for (i=0; i<0x20004; i++)
    dict[i]=i;
  for (i=0; i<nvals; i++)
    hist[vals[i]]++;
  for (i=0; i<0x20004; i++)
    if (hist[i]!=0)
      {
	hist[j]=hist[i];
	dict[j]=dict[i];
	j++;
      }
  *ndict=j;
}
