/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef BWT_H
#define BWT_H

void comp_to_bwt(unsigned int *vals, int nvals,
		 unsigned int *output, int *index);

void comp_from_bwt(unsigned int *input, int nvals, int index,
		   unsigned int *vals);

void bwt_merge_sort_inner(int *indices, int nvals,unsigned int *vals,
			  int start, int end,
			  unsigned int *nrepeat,
			  int *workarray);

#endif
