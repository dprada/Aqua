/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#include "warnmalloc.h"

#include "textconv.h"

/* Allowed characters. Other characters will be replaced by question mark. */
static char native[]="?ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890='*+-/\"#!%&()[{},.;:<> ";
static char native_question='?';
static char ascii_question=63;
static char ascii[]={63,65,66,67,68,69,70,71,72,73,74,75,
		     76,77,78,79,80,81,82,83,84,85,
		     86,87,88,89,90,97,98,99,100,101,
		     102,103,104,105,106,107,108,109,110,111,
		     112,113,114,115,116,117,118,119,120,121,
		     122,49,50,51,52,53,54,55,56,57,
		     48,61,39,42,43,45,47,34,35,
		     33,37,38,40,41,91,123,125,44,46,
		     59,58,60,62,32};

struct convtable
{
  char native_to_ascii[256];
  char ascii_to_native[256];
};

void *textconv_init()
{
  int i;
  char *ptr=native;
  struct convtable *convtable=warnmalloc(sizeof *convtable);
  /* First do question marks */
  for (i=0; i<255; i++)
    convtable->native_to_ascii[i]=ascii_question;
  for (i=0; i<255; i++)
    convtable->ascii_to_native[i]=native_question;
  /* Then fill in conversions. */
  i=0;
  while (*ptr)
    {
      int native_char=*ptr;
      int ascii_char=ascii[i];
      /* Chars can have values less than 0. Convert to "unsigned char". */
      if (native_char<0)
	native_char+=256;
      convtable->ascii_to_native[ascii_char]=native_char;
      convtable->native_to_ascii[native_char]=ascii_char;
      ptr++;
      i++;
    }
  return (void*) convtable;
}

void textconv_native_to_ascii(void *textconv_handle,char *s)
{
  struct convtable *convtable=(struct convtable *)textconv_handle;
#if 0
  char *sbef=s;
  printf("Native to ascii before: %s\n",s);
#endif
  while (*s)
    {
      int ch=*s;
      if (ch<0) /* Chars can have values less than 0. Convert to "unsigned char". */
	ch+=256;
      *s=convtable->native_to_ascii[ch];
      s++;
    }
#if 0
  printf("Native to ascii after: %s\n",sbef);
#endif
}

void textconv_ascii_to_native(void *textconv_handle,char *s)
{
  struct convtable *convtable=(struct convtable *)textconv_handle;
#if 0
  char *sbef=s;
  printf("ASCII to native before: %s\n",s);
#endif
  while (*s)
    {
      int ch=*s;
      if (ch<0) /* Chars can have values less than 0. Convert to "unsigned char". */
	ch+=256;
      *s=convtable->ascii_to_native[ch];
      s++;
    }
#if 0
  printf("ASCII to native after: %s\n",sbef);
#endif
}

#if 0
/* Produce the ascii table from the native string. */
int main()
{
  char *ptr=native, x;
  int i=0;
  while ((x=*ptr++))
    {
      printf("%d,",(int)x);
      if (i==10)
	{
	  printf("\n");
	  i=0;
	}
      i++;
    }
  return 0;
}
#endif

#if 0
/* Produce the test table from the native string. */
int main()
{
  char *ptr=native, x;
  int cnt=33;
  int i=0;
  while ((x=*ptr++))
    {
      printf("%d,",cnt);
      cnt++;
      if (i==10)
	{
	  printf("\n");
	  i=0;
	}
      i++;
    }
  return 0;
}
#endif
