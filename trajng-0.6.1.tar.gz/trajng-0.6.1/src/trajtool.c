/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "trajng.h"
#include "warnmalloc.h"

static void show_help(char *pname)
{
    printf("%s [options] filename\n\n"
	   "-d : Verify data\n"
	   "-s : Verify seek\n"
	   "-S : Verify large seek\n"
	   "-v : Show info (verbose)\n"
	   "-l : List atom labels\n"
	   "-a : The same as -d -s -v -l\n"
	   "-e : Extract\n"
	   "-p : Pack (requires extra parameter: number of atoms unless -g has already been given.)\n"
	   "-k : Skip frame setting when packing. Requires one parameter: nskip. Every nskip frame will be packed.\n"
	   "-i : Set program info string\n"
	   "-L : Read atom labels from the file given as argument\n"
	   "-g : Read/write GROMACS-style gmxdump output.\n"
	   "-r : Attempt repair of incomplete trajectory file.\n"
	   "-f : Force.\n"
	   "-r -f : Force removal of last chunk.\n"
	   "-c : Coding parameter for pack (and coding parameter if required)\n"
	   "-u : Initial frame coding parameter for pack (and coding parameter if required)\n"
	   "-C : Chunky parameter for pack\n"
	   "-P : Precision parameter for pack\n"
	   "-B : Pack velocities\n"
	   "-b : Velocity coding parameter for pack (and coding parameter if required)\n"
	   "-j : Initial velocity coding parameter for pack (and coding parameter if required)\n"
	   "-V : Precision parameter for pack velocities\n"
	   "-m : Set compatibility mode\n"
	   ,pname);
    exit(0);
}

static void get_gmx_info_line(char *buf,int *ncoords, int *framenumber, double *time, double *lambda)
{
  char *s;
  if (!(s=strchr(buf,'=')))
    {
      fprintf(stderr,"Could not find number of atoms line\n");
      exit(EXIT_FAILURE);
    }
  if (sscanf(s+1,"%d",ncoords)!=1)
    {
      fprintf(stderr,"Could not find number of atoms\n");
      exit(EXIT_FAILURE);
    }
  if (!(s=strchr(s+1,'=')))
    {
      fprintf(stderr,"Could not find step=\n");
      exit(EXIT_FAILURE);
    }
  if (sscanf(s+1,"%d",framenumber)!=1)
    {
      fprintf(stderr,"Could not find framenumber\n");
      exit(EXIT_FAILURE);
    }
  if (!(s=strchr(s+1,'=')))
    {
      fprintf(stderr,"Could not find time=\n");
      exit(EXIT_FAILURE);
    }
  if (sscanf(s+1,"%lf",time)!=1)
    {
      fprintf(stderr,"Could not find time number\n");
      exit(EXIT_FAILURE);
    }
  if (!(s=strchr(s+1,'=')))
    {
      fprintf(stderr,"Could not find lambda=\n");
      exit(EXIT_FAILURE);
    }
  if (sscanf(s+1,"%lf",lambda)!=1)
    {
      fprintf(stderr,"Could not find lambda number\n");
      exit(EXIT_FAILURE);
    }
}

static int requires_coding_parameter[11]={0,1,1,1,0,0,1,1,0,0,0};

static void print_algo_info(void *dumpfile, int *ci, int *cip)
{
  int ic;
  char *ctext[4]={"Initial position coding",
		  "Position coding",
		  "Initial velocity coding",
		  "Velocity coding"};

  for (ic=0; ic<2+2*(TrajngHasVel(dumpfile)!=0); ic++)
    {
      if (ci[ic]==0)
	printf("%23s: Fibonacci\n",ctext[ic]);
      else if (ci[ic]==1)
	printf("%23s: Stop-bit every %d bit.\n",ctext[ic],cip[ic]);
      else if (ci[ic]==2)
	printf("%23s: Interframe triple with minimum base %d\n",ctext[ic],1<<cip[ic]);
      else if (ci[ic]==3)
	printf("%23s: Intraframe triple with minimum base %d\n",ctext[ic],1<<cip[ic]);
      else if (ci[ic]==4)
	printf("%23s: Interframe XTC2 coding\n",ctext[ic]);
      else if (ci[ic]==5)
	printf("%23s: Intraframe XTC2 coding\n",ctext[ic]);
      else if (ci[ic]==6)
	printf("%23s: Interframe stop-bit every %d bit.\n",ctext[ic],cip[ic]);
      else if (ci[ic]==7)
	printf("%23s: Raw coordinates triple with minimum base %d.\n",ctext[ic],1<<cip[ic]);
      else if (ci[ic]==8)
	printf("%23s: Interframe Burrows-Wheeler-Lempel-Ziv-Huffman\n",ctext[ic]);
      else if (ci[ic]==9)
	printf("%23s: Intraframe Burrows-Wheeler-Lempel-Ziv-Huffman\n",ctext[ic]);
      else if (ci[ic]==10)
	printf("%23s: XTC3 coding (XTC2+intra+inter+BWLZH)\n",ctext[ic]);
      else
	printf("%23s: Unknown\n",ctext[ic]);
    }
}

int main(int argc, char **argv)
{
    int version;
    int chunky,natoms;
    int initial_coding=-1;
    int initial_coding_parameter=-1;
    int coding=-1;
    int coding_parameter=-1;
    int vel_coding=-1;
    int vel_coding_parameter=-1;
    int initial_vel_coding=-1;
    int initial_vel_coding_parameter=-1;
    int gmxdump=0;
    int show_info=0;
    int list_atom_labels=0;
    char *atom_labels_filename=NULL;
    int extract=0;
    int verify_seek=0;
    int verify_large_seek=0;
    int verify_data=0;
    int pack=0;
    int pack_velocities=0;
    int repair=0;
    int force=0;
    int args;
    int nskip=1;
    int ncoords;
    char *program_info=NULL;
    double use_precision=0.01;
    double chosen_precision, chosen_velprecision;
    int use_chunky=100;
    double vel_precision=0.1;
    int compatibility_mode=0;
    void *dumpfile;
    if (argc<2)
    {
	printf("Need more arguments (try -h)\n");
	return 1;
    }
    if (argc==2)
    {
	show_info=1;
	if ((argv[1][0]=='-') && (argv[1][1]=='h') && (argv[1][2]==0))
	    show_help(argv[0]);
    }
    else
	for (args=1; args<(argc-1); args++)
	{
	    if (argv[args][0]=='-')
	    {
		switch(argv[args][1])
		{
		    case 'a':
			verify_data=1;
			verify_seek=1;
			show_info=1;
			list_atom_labels=1;
			break;
		    case 'd':
			verify_data=1;
			break;
		    case 's':
			verify_seek=1;
			break;
		    case 'S':
			verify_large_seek=1;
			break;
		    case 'v':
			show_info=1;
			break;
		    case 'l':
			list_atom_labels=1;
			break;
		    case 'e':
			extract=1;
			break;
		    case 'm':
		        compatibility_mode=1;
			break;
		    case 'g':
			gmxdump=1;
			/* Set up some other parameters to fit better defaults */
			use_precision=0.001; /* Since gmx uses nm not angstrom */
			vel_precision=0.01; /* Since gmx uses nm not angstrom */
			break;
		    case 'i':
		      if (argc<args+1)
			{
			  fprintf(stderr,"You must give a string to use as program info.\n");
			  exit(EXIT_FAILURE);
			}
		      args++;
		      program_info=argv[args];
 		        break;
		    case 'L':
		      if (argc<args+1)
			{
			  fprintf(stderr,"You must give a filename to use for reading atom labels.\n");
			  exit(EXIT_FAILURE);
			}
		      args++;
		      atom_labels_filename=argv[args];
 		        break;
		    case 'p':
			pack=1;
			if (!gmxdump)
			{
			  if (argc<args+1)
			    {
			      fprintf(stderr,"You must give the number of atoms to pack as an argument.\n");
			      exit(EXIT_FAILURE);
			    }
			  args++;
			  if (sscanf(argv[args],"%d",&ncoords)!=1)
			    {
			      fprintf(stderr,"You must give the number of atoms to pack.\n");
			      exit(EXIT_FAILURE);
			    }
			}
			break;
		    case 'k':
			  if (argc<args+1)
			    {
			      fprintf(stderr,"You must give the nskip parameter.\n");
			      exit(EXIT_FAILURE);
			    }
			  args++;
			  if (sscanf(argv[args],"%d",&nskip)!=1)
			    {
			      fprintf(stderr,"You must give the nskip parameter.\n");
			      exit(EXIT_FAILURE);
			    }
			break;
		    case 'r':
			repair=1;
			break;
		    case 'f':
			force=1;
			break;
		    case 'h':
			show_help(argv[0]);
			break;
		    case 'j':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of initial vel coding as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%d",&initial_vel_coding)!=1)
			{
			    fprintf(stderr,"You must give the number of initial vel coding.\n");
			    exit(EXIT_FAILURE);
			}
			if (requires_coding_parameter[initial_vel_coding])
			  {
			    if (argc<args+1)
			      {
				fprintf(stderr,"You must give the number of initial vel coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			    args++;
			    if (sscanf(argv[args],"%d",&initial_vel_coding_parameter)!=1)
			      {
				fprintf(stderr,"You must give the number of initial vel coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			  }
			else
			  initial_vel_coding_parameter=0;
			if (initial_vel_coding<0)
			  initial_vel_coding_parameter=-1;
			break;
		    case 'b':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of vel coding as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%d",&vel_coding)!=1)
			{
			    fprintf(stderr,"You must give the number of vel coding.\n");
			    exit(EXIT_FAILURE);
			}
			if (requires_coding_parameter[vel_coding])
			  {
			    if (argc<args+1)
			      {
				fprintf(stderr,"You must give the number of vel coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			    args++;
			    if (sscanf(argv[args],"%d",&vel_coding_parameter)!=1)
			      {
				fprintf(stderr,"You must give the number of vel coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			  }
			else
			  vel_coding_parameter=0;
			if (vel_coding<0)
			  vel_coding_parameter=-1;
			break;
		    case 'c':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of coding as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%d",&coding)!=1)
			{
			    fprintf(stderr,"You must give the number of coding.\n");
			    exit(EXIT_FAILURE);
			}
			if (coding==0)
			  {
			    fprintf(stderr,"Fibonacci coding of positions is no longer supported.\n");
			    exit(EXIT_FAILURE);
			  }
			if (requires_coding_parameter[coding])
			  {
			    if (argc<args+1)
			      {
				fprintf(stderr,"You must give the number of coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			    args++;
			    if (sscanf(argv[args],"%d",&coding_parameter)!=1)
			      {
				fprintf(stderr,"You must give the number of coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			  }
			else
			  coding_parameter=0;
			if (coding<0)
			  coding_parameter=-1;
			break;
		    case 'u':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of coding as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%d",&initial_coding)!=1)
			{
			    fprintf(stderr,"You must give the number of coding.\n");
			    exit(EXIT_FAILURE);
			}
			if (initial_coding==0)
			  {
			    fprintf(stderr,"Fibonacci coding of positions is no longer supported.\n");
			    exit(EXIT_FAILURE);
			  }
			if (requires_coding_parameter[initial_coding])
			  {
			    if (argc<args+1)
			      {
				fprintf(stderr,"You must give the number of coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			    args++;
			    if (sscanf(argv[args],"%d",&initial_coding_parameter)!=1)
			      {
				fprintf(stderr,"You must give the number of coding parameter as an argument.\n");
				exit(EXIT_FAILURE);
			      }
			  }
			else
			  initial_coding_parameter=0;
			if (initial_coding<0)
			  initial_coding_parameter=-1;
			break;
		    case 'C':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of chunky as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%d",&use_chunky)!=1)
			{
			    fprintf(stderr,"You must give the number of chunky.\n");
			    exit(EXIT_FAILURE);
			}
			break;
		    case 'B':
			pack_velocities=1;
			break;
		    case 'P':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of the precision as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%lf",&use_precision)!=1)
			{
			    fprintf(stderr,"You must give the number of the precision.\n");
			    exit(EXIT_FAILURE);
			}
			break;
		    case 'V':
			if (argc<args+1)
			{
			    fprintf(stderr,"You must give the number of the velocity precision as an argument.\n");
			    exit(EXIT_FAILURE);
			}
			args++;
			if (sscanf(argv[args],"%lf",&vel_precision)!=1)
			{
			    fprintf(stderr,"You must give the number of the velocity precision.\n");
			    exit(EXIT_FAILURE);
			}
			break;
		}
	    }
	    else
	      fprintf(stderr,"Ignoring argument \"%s\"\n",argv[args]);
	    
	}
    if (repair)
    {
	int ichunk=0;
	int reached_end=0;
	int bad_last_chunk=0;
	unsigned int error_mask=0;
	fprintf(stderr,"Attempting repair of <%s>\n",argv[argc-1]);
	if (!(dumpfile=TrajngOpenRead(argv[argc-1])))
	{
	    fprintf(stderr,"Cannot open dump file <%s> for reading.\n",argv[argc-1]);
	    return 1;
	}
	TrajngInfo(dumpfile,&chunky,&natoms,&version,
		   &initial_coding,&initial_coding_parameter,
		   &coding,&coding_parameter,
		   &vel_coding,&vel_coding_parameter,
		   &initial_vel_coding,&initial_vel_coding_parameter,
		   &chosen_precision,
		   &chosen_velprecision);
	if (!TrajngGotoFirstChunk(dumpfile))
	{
	    do {
		int at_end,ndumps,frame_number;
		unsigned long sizesmall, sizebig;
		ichunk++;
		TrajngGetChunkInfo(dumpfile,&at_end,&sizebig,&sizesmall,&ndumps,&frame_number);
		reached_end=at_end;
		if (ndumps<=0)
		{
		    bad_last_chunk=1;
		    error_mask|=1;
		    break;
		}
	    } while ((!reached_end) && (!TrajngGotoNextChunk(dumpfile)));
	}
	if (!reached_end)
	{
	    bad_last_chunk=1;
	    error_mask|=2;
	}
	TrajngClose(dumpfile);
	if (bad_last_chunk || force)
	{
	    int irep;
	    int at_end,ndumps,frame_number;
	    unsigned long sizesmall, sizebig;
	    if (error_mask)
		fprintf(stderr,"I found the last chunk (chunk %d) to be bad because of:\n",ichunk);
	    else
		fprintf(stderr,"I found no problems in the meta-data but will remove chunk %d anyway.\n",ichunk);
	    if (error_mask & 1)
		fprintf(stderr," * Bad number of dumps\n");
	    if (error_mask & 2)
		fprintf(stderr," * No zero termination found.\n");
	    
	    if (ichunk<=1)
	    {
		fprintf(stderr,"This file has a bad first chunk. It is beyond repair.\n");
		exit(EXIT_FAILURE);
	    }

	    fprintf(stderr,"Attempting repair of <%s>\n",argv[argc-1]);
	    if (!(dumpfile=TrajngOpenRepair(argv[argc-1])))
	    {
		fprintf(stderr,"Odd, the file disappeared...\n");
		exit(EXIT_FAILURE);
	    }
	    if (TrajngGotoFirstChunk(dumpfile))
	    {
		fprintf(stderr,"Odd, I can no longer get to the first chunk.\n");
		exit(EXIT_FAILURE);
	    }
	    for (irep=0; irep<ichunk-2; irep++)
	    {
		if (TrajngGotoNextChunk(dumpfile))
		{
		    fprintf(stderr,"Odd, I can no longer get to chunk %d.\n",irep+2);
		    exit(EXIT_FAILURE);
		}
	    }
	    TrajngGetChunkInfo(dumpfile,&at_end,&sizebig,&sizesmall,&ndumps,&frame_number);
#if 0
	    fprintf(stderr,
		    "Information about the current chunk:\n"
		    "at_end: %d\n"
		    "size: %d\n"
		    "ndumps: %d\n"
		    "frame_number: %d\n"
		    ,at_end,size,ndumps,frame_number);
#endif
	    fprintf(stderr,"Truncating...");
	    if (TrajngTruncate(dumpfile))
		fprintf(stderr,"failed!\n");
	    else
		fprintf(stderr,"succeded!\n");
	    TrajngClose(dumpfile);
	}
	else
	{
	    fprintf(stderr,"I cannot find any errors in the meta-data.\n");
	    return 0;
	}
    }
    else
    {
	if (pack)
	{
  	    int gmxvelwarn=0;
	    char buf[1000];
	    double *coords;
	    double *vels=NULL;
	    int nframes=0;
	    int wframes=0;
	    double lambda=0.;
	    double time=0.;
	    int framenumber=0;
	    if (gmxdump)
	      {
		/* Skip first line */
		fgets(buf,1000,stdin);
		/* How many atoms and other info? */
		fgets(buf,1000,stdin);
		get_gmx_info_line(buf,&ncoords,&framenumber,&time,&lambda);
	      }
	    if (!(dumpfile=TrajngOpenWriteSpecify(argv[argc-1],ncoords,use_chunky,use_precision,1,pack_velocities,
						  vel_precision,compatibility_mode,initial_coding,initial_coding_parameter,
						  coding,coding_parameter,initial_vel_coding,
						  initial_vel_coding_parameter,vel_coding,vel_coding_parameter,0,1)))
	    {
		fprintf(stderr,"Cannot open dump file <%s> for writing.\n",argv[argc-1]);
		return 1;
	    }
	    if (program_info)
	      TrajngSetProgramInfo(dumpfile,program_info);
	    if (atom_labels_filename)
	      {
		int iatom;
		FILE *labels=fopen(atom_labels_filename,"r");
		char **atom_labels=warnmalloc(ncoords*sizeof *atom_labels);
		if (!labels)
		  {
		    fprintf(stderr,"Cannot open file <%s> for reading atom labels.\n",atom_labels_filename);
		    exit(EXIT_FAILURE);
		  }
		for (iatom=0; iatom<ncoords; iatom++)
		  {
		    char atomlabel[1000];
		    int len;
		    if (!fgets(atomlabel,1000,labels))
		      {
			fprintf(stderr,"Could not read atom label %d from file <%s>.\n",iatom,atom_labels_filename);
			exit(EXIT_FAILURE);
		      }
		    len=strlen(atomlabel);
		    atom_labels[iatom]=warnmalloc(len);
		    memcpy(atom_labels[iatom],atomlabel,len-1);
		    atom_labels[iatom][len-1]=0;
		  }
		fclose(labels);
		TrajngSetAtomLabels(dumpfile,atom_labels);
		/* Free memory used by the labels. */
		for (iatom=0; iatom<ncoords; iatom++)
		  free(atom_labels[iatom]);
		free(atom_labels);
	      }
	    coords=warnmalloc(ncoords*3*sizeof *coords);
	    if (pack_velocities)
		vels=warnmalloc(ncoords*3*sizeof *vels);
	    while (fgets(buf,1000,stdin))
	    {
		int i;
		int nc=ncoords;
		double H[9];
		if (gmxdump)
		  {
		    if (!pack_velocities)
		      {
			/* Possibility to ignore a velocity block if we do not pack that. */
			char *sv, *sparen, *sparen2;
			/* Check if we have v here, before ( */
			sv=strchr(buf,'v');
			sparen=strchr(buf,'(');
			sparen2=strchr(buf,')');
			if ((sv) && (sparen) && (sparen2))
			  {
			    if ((sv<sparen) && (sparen<sparen2))
			      {
				if (!gmxvelwarn)
				  {
				    fprintf(stderr,"Found velocities in input. Ignored.");
				    if (nframes<=1)
				      fprintf(stderr," Specify -B to pack velocities as well.");
				    fprintf(stderr,"\n");
				    gmxvelwarn=1;
				  }
				/* Skip velocities. */
				for (i=0; i<nc; i++)
				  fgets(buf,1000,stdin);
				/* Skip the next filename/frame number line. This may terminate! */
				if (!fgets(buf,1000,stdin))
				  break;
			      }
			  }
		      }
		    if (nframes>0)
		      {
			int nc_ignore;
			/* How many atoms and other info line. */
			fgets(buf,1000,stdin);
			get_gmx_info_line(buf,&nc_ignore,&framenumber,&time,&lambda);
			/* Skip box line */
			fgets(buf,1000,stdin);
		      }
		    for (i=0; i<3; i++)
		      {
			char *s;
			/* Box line 1 */
			fgets(buf,1000,stdin);
			if (!(s=strchr(buf,'{')))
			  {
			    fprintf(stderr,"Could not find box line %d\n",i+1);
			    exit(EXIT_FAILURE);
			  }
			if (sscanf(s+1,"%lf,%lf,%lf",H+i*3,H+i*3+1,H+i*3+2)!=3)
			  {
			    fprintf(stderr,"Could not parse box line %d\n",i+1);
			    exit(EXIT_FAILURE);
			  }
		      }
		  }
		else if (sscanf(buf,"%d%lf%lf%lf%lf%lf%lf%lf%lf%lf",&framenumber,H+0,H+1,H+2,H+3,H+4,H+5,H+6,H+7,H+8)<10)
		{
		    H[4]=H[1];
		    H[8]=H[2];
		    H[1]=0.;
		    H[2]=0.;
		    H[3]=0.;
		    H[5]=0.;
		    H[6]=0.;
		    H[7]=0.;
		}
		if (gmxdump)
		  {
		    char *sx, *sparen;
		    fgets(buf,1000,stdin);
		    /* Check that we have x here, before ( */
		    sx=strchr(buf,'x');
		    sparen=strchr(buf,'(');
		    if ((!sx) || (!sparen))
		      {
			fprintf(stderr,"Could not parse x line\n");
			exit(EXIT_FAILURE);
		      }
		    if (sx>sparen)
		      {
			fprintf(stderr,"Invalid format of x line\n");
			exit(EXIT_FAILURE);
		      }
		  }
		for (i=0; i<nc; i++)
		{
		    double x,y,z,vx,vy,vz;
		    fgets(buf,1000,stdin);
		    if (gmxdump)
		      {
			char *s=strchr(buf,'{');
			if (!s)
			  {
			    fprintf(stderr,"Invalid format of x value line\n");
			    exit(EXIT_FAILURE);
			  }
			if (sscanf(s+1,"%lf,%lf,%lf",&x,&y,&z)!=3)
			  {
			    fprintf(stderr,"Cannot parse three coordinates on coordinate line %d.\n",i);
			    exit(EXIT_FAILURE);
			  }
		      }
		    else if (pack_velocities)
			sscanf(buf,"%lf%lf%lf%lf%lf%lf",&x,&y,&z,&vx,&vy,&vz);
		    else
			sscanf(buf,"%lf%lf%lf",&x,&y,&z);
		    coords[i*3+0]=x;
		    coords[i*3+1]=y;
		    coords[i*3+2]=z;
		    if (!gmxdump)
		      if (pack_velocities)
			{
			  vels[i*3+0]=vx;
			  vels[i*3+1]=vy;
			  vels[i*3+2]=vz;
			}
		}
		if ((gmxdump) && (pack_velocities))
		  {
		    char *sv, *sparen;
		    fgets(buf,1000,stdin);
		    /* Check that we have v here, before ( */
		    sv=strchr(buf,'v');
		    sparen=strchr(buf,'(');
		    if ((!sv) || (!sparen))
		      {
			fprintf(stderr,"Could not parse v line. If velocities are not present in input remove the -B option.\n");
			exit(EXIT_FAILURE);
		      }
		    if (sv>sparen)
		      {
			fprintf(stderr,"Invalid format of v line. If velocities are not present in input remove the -B option.\n");
			exit(EXIT_FAILURE);
		      }
		    for (i=0; i<nc; i++)
		      {
			double vx,vy,vz;
			char *s;
			fgets(buf,1000,stdin);
			s=strchr(buf,'{');
			if (!s)
			  {
			    fprintf(stderr,"Invalid format of v value line\n");
			    exit(EXIT_FAILURE);
			  }
			if (sscanf(s+1,"%lf,%lf,%lf",&vx,&vy,&vz)!=3)
			  {
			    fprintf(stderr,"Cannot parse three velocities on velocity line %d.\n",i);
			    exit(EXIT_FAILURE);
			  }
			vels[i*3+0]=vx;
			vels[i*3+1]=vy;
			vels[i*3+2]=vz;
		      }
		  }
		if ((nframes%nskip)==0)
		  {
		    TrajngWrite(dumpfile,H,coords,vels,3,framenumber,time,lambda);
		    wframes++;
		  }

		nframes++;
	    }
	    TrajngClose(dumpfile);
	    fprintf(stderr,"I have written %d frames to <%s>\n",wframes,argv[argc-1]);
	    free(vels);
	    free(coords);
	}
	else
	{
	    if (!(dumpfile=TrajngOpenRead(argv[argc-1])))
	    {
		fprintf(stderr,"Cannot open dump file <%s> for reading.\n",argv[argc-1]);
		return 1;
	    }
	    TrajngInfo(dumpfile,&chunky,&natoms,&version,
		       &initial_coding,&initial_coding_parameter,
		       &coding,&coding_parameter,
		       &vel_coding,&vel_coding_parameter,
		       &initial_vel_coding,&initial_vel_coding_parameter,
		       &chosen_precision,
		       &chosen_velprecision);
	    if (show_info)
	    {
	      program_info=TrajngGetProgramInfo(dumpfile);
	      printf("Trajectory NG version: %d.%d\n",version/10,version%10);
	      if (program_info)
		printf("Program specific info: %s\n",program_info);
	      else
		printf("No program specific info available\n");
		
	      if (TrajngGetCompatibilityMode(dumpfile))
		{
		  printf("This file was written in compatibility mode. Less info available from headers.\n");
		  if (TrajngGetExternalIndex(dumpfile))
		    printf("An external index file is available.\n");
		  else
		    printf("An external index file is not available.\n");
		}
	      else
		{
		  int ci[4],cip[4];
		  ci[0]=initial_coding;
		  ci[1]=coding;
		  ci[2]=initial_vel_coding;
		  ci[3]=vel_coding;
		  cip[0]=initial_coding_parameter;
		  cip[1]=coding_parameter;
		  cip[2]=initial_vel_coding_parameter;
		  cip[3]=vel_coding_parameter;
		  print_algo_info(dumpfile,ci,cip);
		}
	      printf("Chunky: %d\nAtoms/dump: %d\nValues/dump: %d\n",chunky,natoms,natoms*3*(TrajngHasVel(dumpfile)+1));
	      printf("Precision: %g\n",chosen_precision);
	      if (TrajngHasVel(dumpfile))
		{
		  printf("File contains velocities.\n");
		  printf("Velocity precision: %g\n",chosen_velprecision);
		}
	      else
		printf("File does not contain velocities.\n");
	      if (TrajngHasBox(dumpfile))
		printf("File contains box.\n");
	      else
		printf("File does not contain box.\n");
	    }
	    if (list_atom_labels)
	      {
		int iatom;
		char **atom_labels=TrajngGetAtomLabels(dumpfile);
		if (atom_labels)
		  {
		    printf("Atom labels:\n");
		    for (iatom=0; iatom<natoms; iatom++)
		      printf("%d: %s\n",iatom,atom_labels[iatom]);
		  }
		else
		  printf("No atom labels available\n");
	      }
	    if (extract || verify_data)
	    {
		double H[9];
		double *coords=NULL, *vels=NULL;
		double time,lambda;
		int framenumber;
		int ivframe=0;
		int framecount=0;
		int reason=0;
		if (extract)
		{
		    coords=warnmalloc(natoms*3*sizeof *coords);
		    vels=warnmalloc(natoms*3*sizeof *vels);
		}
		while (!TrajngReadTry(dumpfile))
		{
		  if ((reason=TrajngRead(dumpfile,H,coords,vels,3,&framenumber,&time,&lambda)))
		    {
		      if ((TrajngGetCompatibilityMode(dumpfile)) && (reason==1))
			{
			  if (!extract)
			    fprintf(stderr,"EOF\n");
			  break;
			}
		      else
			{
			  fprintf(stderr,"Unexpected read error when reading data:");
			  if (reason==1)
			    fprintf(stderr," General read error\n");
			  else if (reason==2)
			    fprintf(stderr," CRC failure unpacking data\n");
			  else if (reason==3)
			    fprintf(stderr," Frame out of sync error.\n");
			  else
			    fprintf(stderr," Unknown reason error\n");
			  exit(EXIT_FAILURE);
			}
		    }
		  if (!extract)
		    {
		      if ((ivframe%chunky)==0)
			printf("Chunk %d at frame %d: Read ok.\n",1+ivframe/chunky,ivframe);
		      ivframe++;
		    }
		  if (extract)
		    {
		      int i;
		      int na=natoms;
		      if (gmxdump)
			{
			  printf("%s frame %d:\n",argv[argc-1],framecount);
			  framecount++;
			  printf("   natoms=%10d  step=%10d time=%g  lambda=%g\n",na,framenumber,time,lambda);
			  if (TrajngHasBox(dumpfile))
			    {
			      printf("   box (3x3):\n");
			      printf("      box[    0]={%12.5e, %12.5e, %12.5e}\n",H[0],H[1],H[2]);
			      printf("      box[    1]={%12.5e, %12.5e, %12.5e}\n",H[3],H[4],H[5]);
			      printf("      box[    2]={%12.5e, %12.5e, %12.5e}\n",H[6],H[7],H[8]);
			    }
			  printf("   x (%dx3):\n",na);
			  for (i=0; i<na; i++)
			    printf("      x[%5d]={%12.5e, %12.5e, %12.5e}\n",i,coords[i*3],coords[i*3+1],coords[i*3+2]);
			  if (TrajngHasVel(dumpfile))
			    {
			      printf("   v (%dx3):\n",na);
			      for (i=0; i<na; i++)
				printf("      v[%5d]={%12.5e, %12.5e, %12.5e}\n",i,vels[i*3],vels[i*3+1],vels[i*3+2]);
			    }
			}
		      else
			{
			  if (TrajngHasBox(dumpfile))
			    printf("%d %g %g %g %g %g %g %g %g %g\n",framenumber,H[0],H[1],H[2],H[3],H[4],H[5],H[6],H[7],H[8]);
			  else
			    printf("%d\n",framenumber);
			  if (TrajngHasVel(dumpfile))
			    for (i=0; i<na; i++)
			      {
				printf("%g %g %g %g %g %g\n",coords[i*3],coords[i*3+1],coords[i*3+2],
				       vels[i*3+0],vels[i*3+1],vels[i*3+2]);
			      }
			  else
			    for (i=0; i<na; i++)
			      {
				printf("%g %g %g\n",coords[i*3],coords[i*3+1],coords[i*3+2]);
			      }
			}
		    }
		}
		free(vels);
		free(coords);
	    }
	    if (verify_seek)
	    {
	      if ((TrajngGetCompatibilityMode(dumpfile)) && (TrajngGetExternalIndex(dumpfile)==0))
		{
		  printf("FATAL: Cannot verify seek for a file written in compatibility mode without external index file.\n");
		}
	      else
		{
		  if (TrajngGetCompatibilityMode(dumpfile))
		    {
		      int ichunk=0;
		      while (!TrajngSeek(dumpfile,ichunk*chunky))
			{
			  double H[9];
			  int framenumber;
			  double time, lambda;
			  int err;
			  if (!(err=TrajngReadNoDecompress(dumpfile,H,NULL,NULL,3,&framenumber,&time,&lambda)))
			    {
			      int ci[4],cip[4];
			      printf("Seek to chunk %d, frame %d returns framenumber %d time %g and lambda %g.\n",
				     ichunk+1,ichunk*chunky,framenumber,time,lambda);
			      TrajngInfo(dumpfile,&chunky,&natoms,&version,
					 &initial_coding,&initial_coding_parameter,
					 &coding,&coding_parameter,
					 &vel_coding,&vel_coding_parameter,
					 &initial_vel_coding,&initial_vel_coding_parameter,
					 &chosen_precision,
					 &chosen_velprecision);			      
			      ci[0]=initial_coding;
			      ci[1]=coding;
			      ci[2]=initial_vel_coding;
			      ci[3]=vel_coding;
			      cip[0]=initial_coding_parameter;
			      cip[1]=coding_parameter;
			      cip[2]=initial_vel_coding_parameter;
			      cip[3]=vel_coding_parameter;
			      print_algo_info(dumpfile,ci,cip);
			    }
			  else
			    {
			      if (err==1)
				printf("EOF\n");
			      else
				printf("ERROR %d\n",err);
			      break;
			    }
			  ichunk++;
			}
		    }
		  else
		    {
		      int ichunk=0;
		      int reached_end=0;
		      double total_size=0.;
		      int total_dumps=0;
		      if (!TrajngGotoFirstChunk(dumpfile))
			{
			  do {
			    int at_end,ndumps,frame_number;
			    unsigned long sizesmall, sizebig;
			    double size;
			    TrajngGetChunkInfo(dumpfile,&at_end,&sizebig,&sizesmall,&ndumps,&frame_number);
			    size=(double)sizesmall+((double)sizebig)*4294967296.;
			    ichunk++;
			    if (show_info)
			      {
				printf("Chunk %d at frame %d has size %g bytes in %d dumps.\n",ichunk,frame_number,size,ndumps);
				if (ndumps>0)
				  printf("      Compression: %g bits per value.\n",8.*size/((double)natoms*3*ndumps*(TrajngHasVel(dumpfile)+1.)));
				if (at_end)
				  printf("      This is the terminating chunk.\n");
			      }
			    if (ndumps<=0)
			      printf("FATAL: Bad number of dumps in this chunk.\n");
			    reached_end=at_end;
			    total_size+=size;
			    total_dumps+=ndumps;
			  } while ((!reached_end) && (!TrajngGotoNextChunk(dumpfile)));
			}
		      if (!reached_end)
			printf("FATAL: Terminating chunk not found!\n");
		      else
			if (total_dumps>0.)
			  {
			    printf("Dumpfile contains %g values in %d dumps.\n",(double)natoms*3*(double)total_dumps*(TrajngHasVel(dumpfile)+1),total_dumps);
			    printf("Average compression: %g bits per value.\n",8*total_size/((double)natoms*3*(double)total_dumps*(TrajngHasVel(dumpfile)+1.)));
			    printf("Do not trust these numbers if any errors occured during scan.\n");
			  }
		    }
		}
	    }
	    if (verify_large_seek)
	    {
	      if (TrajngGetCompatibilityMode(dumpfile))
		{
		  printf("FATAL: Cannot verify large seek for a file written in compatibility mode.\n");
		}
	      else
		{
		  int ichunk=0;
		  int total_chunks=0;
		  int sizelarge=TrajngGetLargeChunk(dumpfile);
		  int ndumpsmax=0;
		  if (!TrajngGotoFirstChunk(dumpfile))
		    {
		      do {
			int at_end,ndumps,frame_number;
			unsigned long sizesmall, sizebig;
			double size;
			TrajngGetChunkInfo(dumpfile,&at_end,&sizebig,&sizesmall,&ndumps,&frame_number);
			size=(double)sizesmall+((double)sizebig)*4294967296.;
			ichunk++;
			if (show_info)
			  {
			    printf("Chunk %d at frame %d has size %g bytes in %d dumps.\n",1+(ichunk-1)*sizelarge,frame_number,size,ndumps);
			    if (ndumps>0)
			      printf("      Compression: %g bits per value.\n",8.*size/((double)natoms*3*ndumps*(TrajngHasVel(dumpfile)+1.)));
			    if (at_end)
			      printf("      This is the terminating chunk.\n");
			  }
			if (ndumps<=0)
			  printf("FATAL: Bad number of dumps in this chunk.\n");
			if (ndumps>ndumpsmax)
			  ndumpsmax=ndumps;
			total_chunks++;
		      } while (!TrajngGotoNextLargeChunk(dumpfile));
		    }
		  if (total_chunks>0)
		    {
		      printf("There are %d large chunks each containing up to %d normal chunks in this file.\n",total_chunks,sizelarge);
		      printf("There are up to %d dumps reachable by large seek.\n",total_chunks*sizelarge*ndumpsmax);
		    }
		}
	    }
	    TrajngClose(dumpfile);
	}
    }
    return 0;
}
