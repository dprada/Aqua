/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/
#ifndef CODER_H
#define CODER_H

/* For coding==0:
   This code is very similar to Fibonacci coding. Fibonacci coding
   ends with 11, my code ends with 00. The principle and efficiency is
   identical.
   For coding==1: 
   This initial number of bits between stop-bits is set in the coding_parameter.
   For coding==2 and coding==3:
   Triplet compression. For each triplet two bits set the base. The minimum base is 1<<coding_parameter
 */


struct code
{
    unsigned int nbits;
    unsigned int pattern;
};

struct coder
{
    struct code *code;
    int *inverse_code;
    unsigned int inverse_code_len;
    unsigned int pack_temporary;
    int pack_temporary_bits;
    unsigned int info_last_largest_pattern;
    unsigned int info_last_largest_output;
    int stat_overflow;
    int stat_numval;
};

struct coder *trajcoder_init(void);
void trajcoder_deinit(struct coder *coder);
unsigned char *trajcoder_pack_array(struct coder *coder,int *input, int *length, int coding, int coding_parameter, int natoms, int speed);
int trajcoder_unpack_array(struct coder *coder,unsigned char *packed,int *output, int length, int coding, int coding_parameter, int natoms);
void trajcoder_get_unpack_info(struct coder *coder,int *largest_pattern, int *largest_output, int *max_output);
unsigned char *trajcoder_pack_array_magic(struct coder *coder,int *input, int *length);
int trajcoder_unpack_array_magic(struct coder *coder,unsigned char *packed,int *output, int length);
unsigned char *trajcoder_pack_array_xtc3(int *input, int *length, int natoms, int speed);
int trajcoder_unpack_array_xtc3(unsigned char *packed,int *output, int length, int natoms);

void trajcoder_out8bits(struct coder *coder, unsigned char **output);
void trajcoder_pack_flush(struct coder *coder,unsigned char **output);
void trajcoder_write_pattern(struct coder *coder,unsigned int pattern, int nbits, unsigned char **output);

void trajcoder_writebits(struct coder *coder,unsigned int value,int nbits, unsigned char **output_ptr);
void trajcoder_write32bits(struct coder *coder,unsigned int value,int nbits, unsigned char **output_ptr);
void trajcoder_writemanybits(struct coder *coder,unsigned char *value,int nbits, unsigned char **output_ptr);

int trajcoder_magic(unsigned int i);
int trajcoder_find_magic_index(unsigned int maxval);


#endif
