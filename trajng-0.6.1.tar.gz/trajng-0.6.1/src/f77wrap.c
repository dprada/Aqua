/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* These are FORTRAN-77 wrappers to the trajng library.  Linkage
   method for strings.  Static (i.e. non-thread safe) handling of
   handles.  Allows one file open for writing and one file open for
   reading at a time.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdlib.h>
#include <string.h>
#include "trajng.h"
#include "warnmalloc.h"

static char *f77_to_c_string(char *s, int len);
static void *readfile=NULL;
static void *writefile=NULL;
static char **writelabels=NULL;
static int writelabels_set=0;

/* Open a file for writing:
   subroutine tngowr(name,natoms,chunky,prec,wb,wv,vprec,icompat)
   character*(*) name
   integer natoms,chunky,wb,wv,icompat
   double precision prec,vprec
*/
void tngowr(char *name, int *natoms, int *chunky, double *prec, int *wb, int *wv,
	    double *vprec,int *icompat, int *ispd,
	    int namelen)
{
  char *cname;
  if (writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: A file is already open for writing.\n");
      exit(EXIT_FAILURE);
    }
  cname=f77_to_c_string(name,namelen);
  writefile=TrajngOpenWrite(cname,*natoms,*chunky,*prec,*wb,*wv,*vprec,*icompat,*ispd);
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: Could not open file %s for writing.\n",cname);
      exit(EXIT_FAILURE);
    }
  free(cname);
}

void tngowr_(char *name, int *natoms, int *chunky, double *prec, int *wb, int *wv,
	    double *vprec,int *icompat, int *ispd,
	    int namelen)
{
  tngowr(name, natoms, chunky, prec, wb, wv,
	 vprec,icompat,ispd,namelen);
}

void TNGOWR(char *name, int *natoms, int *chunky, double *prec, int *wb, int *wv,
	    double *vprec,int *icompat, int *ispd,
	    int namelen)
{
  tngowr(name, natoms, chunky, prec, wb, wv,
	 vprec,icompat,ispd,namelen);
}

void TNGOWR_(char *name, int *natoms, int *chunky, double *prec, int *wb, int *wv,
	    double *vprec,int *icompat, int *ispd,
	    int namelen)
{
  tngowr(name, natoms, chunky, prec, wb, wv,
	 vprec,icompat,ispd,namelen);
}

/* Set program information:
   subroutine tngspi(text)
   character*(*) text
*/
void tngspi(char *text, int len)
{
  char *ctext;
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for writing in tngspi.\n");
      exit(EXIT_FAILURE);
    }
  ctext=f77_to_c_string(text,len);
  if (TrajngSetProgramInfo(writefile,ctext))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: Error occured in tngspi.\n");
      exit(EXIT_FAILURE);
    }
  free(ctext);
}

void tngspi_(char *text, int len)
{
  tngspi(text,len);
}

void TNGSPI(char *text, int len)
{
  tngspi(text,len);
}

void TNGSPI_(char *text, int len)
{
  tngspi(text,len);
}

/* Set atomic labels:
   subroutine tngsal(iatom,label)
   character(*) label
   integer iatom
*/
void tngsal(int *iatom,char *label, int len)
{
  char *clabel;
  int ciatom=(*iatom)-1;
  int n;
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for writing in tngsal.\n");
      exit(EXIT_FAILURE);
    }
  clabel=f77_to_c_string(label,len);
  n=TrajngNatoms(writefile);
  if (!writelabels)
    {
      int i;
      writelabels=warnmalloc(n*sizeof *writelabels);
      for (i=0; i<n; i++)
	writelabels[i]=NULL;
    }
  if (writelabels[ciatom])
    {
      fprintf(stderr,"TRAJNG F77 wrapper: A label has already been set for atom %d in tngsal.\n",ciatom);
      exit(EXIT_FAILURE);
    }
  writelabels[ciatom]=clabel;
  writelabels_set++;
  if (writelabels_set==n)
    TrajngSetAtomLabels(writefile,writelabels);
}

void tngsal_(int *iatom,char *label, int len)
{
  tngsal(iatom,label,len);
}

void TNGSAL(int *iatom,char *label, int len)
{
  tngsal(iatom,label,len);
}

void TNGSAL_(int *iatom,char *label, int len)
{
  tngsal(iatom,label,len);
}

/* Write a frame in double precision:
   subroutine tngwrd(H,coords,vels,stride,fn,time,lambda)
   double precision H(9),coords(*),vels(*),time,lambda
   integer stride,fn
*/
void tngwrd(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for writing in tngwrd.\n");
      exit(EXIT_FAILURE);
    }
  if (TrajngWrite(writefile,H,coords,vels,*stride,*fn,*time,*lambda))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: An error occured when writing in tngwrd.\n");
      exit(EXIT_FAILURE);
    }
}

void tngwrd_(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngwrd(H,coords,vels,stride,fn,time,lambda);
}

void TNGWRD(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngwrd(H,coords,vels,stride,fn,time,lambda);
}

void TNGWRD_(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngwrd(H,coords,vels,stride,fn,time,lambda);
}

/* Write a frame in single precision:
   subroutine tngwrs(H,coords,vels,stride,fn,time,lambda)
   real H(9),coords(*),vels(*),time,lambda
   integer stride,fn
*/
void tngwrs(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for writing in tngwrs.\n");
      exit(EXIT_FAILURE);
    }
  if (TrajngWritef(writefile,H,coords,vels,*stride,*fn,*time,*lambda))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: An error occured when writing in tngwrs.\n");
      exit(EXIT_FAILURE);
    }
}

void tngwrs_(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngwrs(H,coords,vels,stride,fn,time,lambda);
}

void TNGWRS(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngwrs(H,coords,vels,stride,fn,time,lambda);
}

void TNGWRS_(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngwrs(H,coords,vels,stride,fn,time,lambda);
}

/* Open a file for reading:
   subroutine tngord(name)
   character*(*) name
*/
void tngord(char *name, int namelen)
{
  char *cname;
  if (readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: A file is already open for reading.\n");
      exit(EXIT_FAILURE);
    }
  cname=f77_to_c_string(name,namelen);
  readfile=TrajngOpenRead(cname);
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: Could not open file %s for reading.\n",cname);
      exit(EXIT_FAILURE);
    }
  free(cname);
}

void tngord_(char *name, int namelen)
{
  tngord(name, namelen);
}

void TNGORD(char *name, int namelen)
{
  tngord(name, namelen);
}

void TNGORD_(char *name, int namelen)
{
  tngord(name, namelen);
}

/* Get program information. If none is found the fortran string is
   filled by blanks and no error is reported.
   subroutine tnggpi(text)
   character*(*) text
*/
void tnggpi(char *text, int len)
{
  char *ctext;
  int clen=0;
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tnggpi.\n");
      exit(EXIT_FAILURE);
    }
  ctext=TrajngGetProgramInfo(readfile);
  if (ctext)
    {
      clen=strlen(ctext);
      if (len<clen)
	clen=len;
      memcpy(text,ctext,clen);
    }
  while (clen<len)
    {
      text[clen]=' ';
      clen++;
    }
}

void tnggpi_(char *text, int len)
{
  tnggpi(text,len);
}

void TNGGPI(char *text, int len)
{
  tnggpi(text,len);
}

void TNGGPI_(char *text, int len)
{
  tnggpi(text,len);
}

/* Get atomic labels. If none is found the fortran string is
   filled by blanks and no error is reported.
   subroutine tnggal(iatom,label)
   character(*) label
   integer iatom
*/
void tnggal(int *iatom,char *label, int len)
{
  char **clabels;
  int clen=0;
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tnggal.\n");
      exit(EXIT_FAILURE);
    }
  clabels=TrajngGetAtomLabels(readfile);
  if (clabels)
    {
      clen=strlen(clabels[(*iatom)-1]);
      if (len<clen)
	clen=len;
      memcpy(label,clabels[(*iatom)-1],clen);
    }
  while (clen<len)
    {
      label[clen]=' ';
      clen++;
    }
}

void tnggal_(int *iatom,char *label, int len)
{
  tnggal(iatom,label,len);
}

void TNGGAL(int *iatom,char *label, int len)
{
  tnggal(iatom,label,len);
}

void TNGGAL_(int *iatom,char *label, int len)
{
  tnggal(iatom,label,len);
}

/* Get number of atoms from file open for reading.
   function itngat()
   integer itngat
*/
int itngat()
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in itngat.\n");
      exit(EXIT_FAILURE);
    }
  return TrajngNatoms(readfile);
}

int itngat_()
{
  return itngat();
}

int ITNGAT()
{
  return itngat();
}

int ITNGAT_()
{
  return itngat();
}

/* Get info if file has velocities.
   function itnghv()
   integer itnghv
*/
int itnghv()
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in itnghv.\n");
      exit(EXIT_FAILURE);
    }
  return TrajngHasVel(readfile);
}

int itnghv_()
{
  return itnghv();
}

int ITNGHV()
{
  return itnghv();
}

int ITNGHV_()
{
  return itnghv();
}

/* Get info if file has box.
   function itnghb()
   integer itnghb
*/
int itnghb()
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in itnghb.\n");
      exit(EXIT_FAILURE);
    }
  return TrajngHasBox(readfile);
}

int itnghb_()
{
  return itnghb();
}

int ITNGHB()
{
  return itnghb();
}

int ITNGHB_()
{
  return itnghb();
}

/* ReadTry: Query if a file has more frames. If it has it returns 0 otherwise 1
   (as in error or EOF).
   function itngrt()
   integer itngrt
*/
int itngrt()
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in itngrt.\n");
      exit(EXIT_FAILURE);
    }
  return TrajngReadTry(readfile);
}

int itngrt_()
{
  return itngrt();
}

int ITNGRT()
{
  return itngrt();
}

int ITNGRT_()
{
  return itngrt();
}

/* Read a frame in double precision:
   subroutine tngrdd(H,coords,vels,stride,fn,time,lambda)
   double precision H(9),coords(*),vels(*),time,lambda
   integer stride,fn
*/
void tngrdd(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tngrdd.\n");
      exit(EXIT_FAILURE);
    }
  if (TrajngRead(readfile,H,coords,vels,*stride,fn,time,lambda))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: An error occured when reading in tngrdd.\n");
      exit(EXIT_FAILURE);
    }
}

void tngrdd_(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngrdd(H,coords,vels,stride,fn,time,lambda);
}

void TNGRDD(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngrdd(H,coords,vels,stride,fn,time,lambda);
}

void TNGRDD_(double *H, double *coords,double *vels,int *stride,int *fn,double *time, double *lambda)
{
  tngrdd(H,coords,vels,stride,fn,time,lambda);
}

/* Read a frame in single precision:
   subroutine tngrds(H,coords,vels,stride,fn,time,lambda)
   real H(9),coords(*),vels(*),time,lambda
   integer stride,fn
*/
void tngrds(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tngrds.\n");
      exit(EXIT_FAILURE);
    }
  if (TrajngReadf(readfile,H,coords,vels,*stride,fn,time,lambda))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: An error occured when reading in tngrds.\n");
      exit(EXIT_FAILURE);
    }
}

void tngrrds_(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngrds(H,coords,vels,stride,fn,time,lambda);
}

void TNGRDS(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngrds(H,coords,vels,stride,fn,time,lambda);
}

void TNGRDS_(float *H, float *coords,float *vels,int *stride,int *fn,float *time, float *lambda)
{
  tngrds(H,coords,vels,stride,fn,time,lambda);
}

/* Seek to a frame
   subroutine tngsek(iframe)
   integer iframe
*/
void tngsek(int *iframe)
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tngsek.\n");
      exit(EXIT_FAILURE);
    }
  if (TrajngSeek(readfile,(*iframe)+1))
    {
      fprintf(stderr,"TRAJNG F77 wrapper: An error occured when seeking to frame %d in tngsek\n",(*iframe)+1);
      exit(EXIT_FAILURE);      
    }
}

void tngsek_(int *iframe)
{
  tngsek(iframe);
}

void TNGSEK(int *iframe)
{
  tngsek(iframe);
}

void TNGSEK_(int *iframe)
{
  tngsek(iframe);
}


/* Close a file open for writing
   subroutine tngclw()
*/
void tngclw()
{
  int n;
  if (!writefile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for writing in tngclw.\n");
      exit(EXIT_FAILURE);
    }
  n=TrajngNatoms(writefile);
  TrajngClose(writefile);
  /* No writefile open */
  writefile=NULL;
  /* Clear data */
  if (writelabels)
    {
      int i;
      for (i=0; i<n; i++)
	free(writelabels[i]);
      free(writelabels);
    }
  writelabels_set=0;
  writelabels=NULL;
}

void tngclw_()
{
  tngclw();
}

void TNGCLW()
{
  tngclw();
}

void TNGCLW_()
{
  tngclw();
}

/* Close a file open for reading
   subroutine tngclr()
*/
void tngclr()
{
  if (!readfile)
    {
      fprintf(stderr,"TRAJNG F77 wrapper: No file open for reading in tngclr.\n");
      exit(EXIT_FAILURE);
    }
  TrajngClose(readfile);
  /* No readfile open */
  readfile=NULL;
}

void tngclr_()
{
  tngclr();
}

void TNGCLR()
{
  tngclr();
}

void TNGCLR_()
{
  tngclr();
}

static char *f77_to_c_string(char *s, int len)
{
  char *cs=warnmalloc(len+1);
  memcpy(cs,s,len);
  cs[len]=0;
  return cs;
}
