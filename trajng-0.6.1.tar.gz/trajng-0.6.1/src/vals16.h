/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef VALS16_H
#define VALS16_H

void comp_conv_to_vals16(unsigned int *vals,int nvals,
			 unsigned int *vals16, int *nvals16);

void comp_conv_from_vals16(unsigned int *vals16,int nvals16,
			   unsigned int *vals, int *nvals);

#endif
