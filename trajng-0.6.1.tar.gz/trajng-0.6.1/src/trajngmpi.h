/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef TRAJNGMPI_H
#define TRAJNGMPI_H

#ifdef __cplusplus
 extern "C" {
#endif

#if HAVE_CONFIG_H
#include <config.h>
#endif

#if TRAJNG_USE_MPI
#ifndef USE_MPI
#define USE_MPI
#endif
#endif

#ifdef USE_MPI

#include <mpi.h>

/* Open a file for writing trajectories, for MPI codes using domain
   decomposition. Currently it only produces compatibility mode
   files. */
void *TrajngMPIOpenWrite(char *name, int total_natoms, int chunky,
			 double precision, int writebox, int writevel,
			 double velprecision, int speed, MPI_Comm comm);

void *TrajngMPIOpenWriteSpecify(char *name, int total_natoms, int chunky,
				double precision, int writebox, int writevel,
				double velprecision, 
				int initial_coding, int initial_coding_parameter,
				int coding, int coding_parameter,
				int initial_vel_coding, int initial_vel_coding_parameter,
				int vel_coding, int vel_coding_parameter,
				int speed, int compute_chunky, MPI_Comm comm);

/* This only have to be called from rank==0, if called at all, but
   does no harm if called elsewhere */
int TrajngMPISetProgramInfo(void *handle,
			    char *program_info);

/* This only have to be called from rank==0, if called at all, but
   does no harm if called elsewhere */
int TrajngMPISetAtomLabels(void *handle,
			   char **atom_labels);


/* NOTE: The number of local atoms should be sent in the natoms
   argument and a map array of length natoms should contain the global
   number of each atom. */
int TrajngMPIWrite(void *handle,double *H,
		   double *coords,double *vels,
		   int stride,
		   int framenumber,
		   double time,
		   double lambda,
		   int natoms, int *map);

/* Same as TrajngMPIWrite but takes float data. Note that all data
   inside the library is converted to double precision. The main
   advantage of single precision here is that the data amount sent
   between ranks is smaller. */
int TrajngMPIWritef(void *handle,float *H,
		    float *coords,float *vels,
		    int stride,
		    int framenumber,
		    float time,
		    float lambda,
		    int natoms, int *map);

/* Obtain information. */
void TrajngMPIInfo(void *handle,
		   int *chunky, int *natoms, int *version,
		   int *initial_coding, int *initial_coding_parameter,
		   int *coding, int *coding_parameter,
		   int *vel_coding, int *vel_coding_parameter,
		   int *initial_vel_coding, int *initial_vel_coding_parameter,
		   double *chosen_precision,
		   double *chosen_velprecision);

/* Close trajectory file. */
void TrajngMPIClose(void *handle);

#endif /* USE_MPI */

#ifdef __cplusplus
 }
#endif



#endif

