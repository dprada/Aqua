/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef MERGE_SORT_H
#define MERGE_SORT_H

void merge_sort(void *base, size_t nmemb, size_t size,
		int (*compar)(const void *v1,const void *v2,const void *private),
		void *private);


#endif
