/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef DICT_H
#define DICT_H

void comp_canonical_dict(unsigned int *dict, int *ndict);

void comp_make_dict_hist(unsigned int *vals, int nvals,
			 unsigned int *dict, int *ndict,
			 unsigned int *hist);

#endif
