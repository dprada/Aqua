/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef RLE_H
#define RLE_H

void comp_conv_to_rle(unsigned int *vals, int nvals,
		      unsigned int *rle, int *nrle,
		      int min_rle);

void comp_conv_from_rle(unsigned int *rle, 
			unsigned int *vals, int nvals);

#endif
