/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#include "delta.h"

/* Acceptable inputs are 16 bit (0-0xFFFF). Outputs will be 17 bit
   (0-0x1FFFF) */
void comp_conv_to_delta(unsigned int *vals, int nvals,
			unsigned int *valsdelta)
{
  if (nvals>0)
    {
      int i;
      valsdelta[0]=vals[0];
      for (i=1; i<nvals; i++)
	valsdelta[i]=vals[i]-vals[i-1]+0x10000U;
    }
}

void comp_conv_from_delta(unsigned int *valsdelta, int nvals,
			  unsigned int *vals)
{
  if (nvals>0)
    {
      int i;
      vals[0]=valsdelta[0];
      for (i=1; i<nvals; i++)
	vals[i]=vals[i-1]+valsdelta[i]-0x10000U;
    }
}
