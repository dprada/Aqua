/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include "trajng.h"
#include "bwlzh.h"
#include "coder.h"
#include "warnmalloc.h"

#define MAXSYMBOLSHALF 32768 /* Should be a sufficiently large power of two. */
#define MAXSYMBOLS (2*MAXSYMBOLSHALF)

struct coder *trajcoder_init(void)
{
    struct coder *coder=warnmalloc(sizeof *coder);
    coder->code=NULL;
    coder->inverse_code=NULL;
    coder->inverse_code_len=0;
    coder->pack_temporary_bits=0;
    coder->info_last_largest_pattern=0;
    coder->info_last_largest_output=0;
    return coder;
}

void trajcoder_deinit(struct coder *coder)
{
    free(coder->code);
    free(coder->inverse_code);
    free(coder);
}

static int numbits(unsigned int x)
{
    int maxb=32;
    int li=0;
    int i;
    for (i=0; i<maxb; i++)
    {
	unsigned int p=1<<i;
	if (p & x)
	    li=i;
    }
    return li+1;
}

/* This table will be pretty large, but only the parts that are really used will end up 
   in cache, so it should not really affect performance if I prepare more than I use. */
static void prepare_code(struct coder *coder)
{
    unsigned int i=0;
    unsigned int nsymbols=0;
    struct code *code;
    coder->code=warnmalloc(MAXSYMBOLS*sizeof *coder->code);
    code=coder->code;
    while (nsymbols<MAXSYMBOLS)
    {
	int nbits=numbits(i);
	int j;
	int hasdoublezero=0;
	int waszero=0;
	unsigned int mask=1;
	for (j=0; j<nbits; j++)
	{
	    if ((!(i & mask)) && (waszero))
	    {
		hasdoublezero=1;
		break;
	    }
	    waszero=!(i & mask);
	    mask<<=1;
	}
	if (!hasdoublezero)
	{
	    code[nsymbols].nbits=nbits;
	    code[nsymbols].pattern=i;
	    nsymbols++;
#if 0
	    printf("%d: %d (nbits=%d) Inefficiency: %g\n",nsymbols,i,nbits,(double)(nbits+2)/numbits(nsymbols));
#endif
	}
	i++;
    }
    code[0].nbits=0; /* Special case. */
}

static void prepare_inverse_code(struct coder *coder)
{
    int largest_code;
    int i;
    if (!coder->code)
	prepare_code(coder);
    largest_code=coder->code[MAXSYMBOLS-1].pattern;
    coder->inverse_code_len=largest_code+1;
    coder->inverse_code=warnmalloc(coder->inverse_code_len*sizeof *coder->inverse_code);
    for (i=0; i<MAXSYMBOLS; i++)
    {
	int s;
	s=(i+1)/2;
	if ((i%2)==0)
	    s=-s;
	coder->inverse_code[coder->code[i].pattern]=s;
#if 0
	if (i<100)
	    printf("IC: 0x%x : %d\n",code[i].pattern,s);
#endif
    }
}

void trajcoder_out8bits(struct coder *coder, unsigned char **output)
{
  while (coder->pack_temporary_bits>=8)
    {
      unsigned int mask=~(0xFFU<<(coder->pack_temporary_bits-8));
      unsigned char out=(unsigned char)(coder->pack_temporary>>(coder->pack_temporary_bits-8));
      **output=out;
      (*output)++;
      coder->pack_temporary_bits-=8;
      coder->pack_temporary&=mask;
    }  
}

void trajcoder_write_pattern(struct coder *coder,unsigned int pattern, int nbits, unsigned char **output)
{
    unsigned int mask1,mask2;
    mask1=1;
    mask2=1<<(nbits-1);
    coder->pack_temporary<<=nbits; /* Make room for new data. */
    coder->pack_temporary_bits+=nbits;
    while (nbits)
    {
	if (pattern & mask1)
	    coder->pack_temporary|=mask2;
	nbits--;
	mask1<<=1;
	mask2>>=1;
    }
    trajcoder_out8bits(coder,output);
}

/* Write up to 24 bits */
void trajcoder_writebits(struct coder *coder,unsigned int value,int nbits, unsigned char **output_ptr)
{
  /* Make room for the bits. */
  coder->pack_temporary<<=nbits;
  coder->pack_temporary_bits+=nbits;
  coder->pack_temporary|=value;
  trajcoder_out8bits(coder,output_ptr);
#ifdef SHOWIT
  fprintf(stderr,"Write nbits=%d value=%x\n",nbits,value);
#endif
}

/* Write up to 32 bits */
void trajcoder_write32bits(struct coder *coder,unsigned int value,int nbits, unsigned char **output_ptr)
{
  unsigned int mask;
#ifdef SHOWIT
  fprintf(stderr,"Write nbits=%d value=%x\n",nbits,value);
#endif
  if (nbits>=8)
    mask=0xFFU<<(nbits-8);
  else
    mask=0xFFU>>(8-nbits);
  while (nbits>8)
    {
      /* Make room for the bits. */
      coder->pack_temporary<<=8;
      coder->pack_temporary_bits+=8;
      coder->pack_temporary|=(value&mask)>>(nbits-8);
      trajcoder_out8bits(coder,output_ptr);
      nbits-=8;
      mask>>=8;
    }
  if (nbits)
    trajcoder_writebits(coder,value&mask,nbits,output_ptr);
}

/* Write "arbitrary" number of bits */
void trajcoder_writemanybits(struct coder *coder,unsigned char *value,int nbits, unsigned char **output_ptr)
{
  int vptr=0;
  while (nbits>=24)
    {
      unsigned int v=((((unsigned int)value[vptr])<<16)|
		      (((unsigned int)value[vptr+1])<<8)|
		      (((unsigned int)value[vptr+2])));
#ifdef SHOWIT
      fprintf(stderr,"Write value %02x\n",value[vptr]);
      fprintf(stderr,"Write value %02x\n",value[vptr+1]);
      fprintf(stderr,"Write value %02x\n",value[vptr+2]);
#endif
      trajcoder_writebits(coder,v,24,output_ptr);
      vptr+=3;
      nbits-=24;
    }
  while (nbits>=8)
    {
#ifdef SHOWIT
      fprintf(stderr,"Write value %02x\n",value[vptr]);
#endif
      trajcoder_writebits(coder,(unsigned int)value[vptr],8,output_ptr);
      vptr++;
      nbits-=8;
    }
  if (nbits)
    {
#ifdef SHOWIT
      fprintf(stderr,"Write value %02x\n",value[vptr]);
#endif
      trajcoder_writebits(coder,(unsigned int)value[vptr],nbits,output_ptr);
    }
}

static int write_stop_bit_code(struct coder *coder, unsigned int s,unsigned int coding_parameter, unsigned char **output)
{
  do {
    unsigned int extract=~(0xffffffffU<<coding_parameter);
    unsigned int this=(s&extract)<<1;
    s>>=coding_parameter;
    if (s)
      {
	this|=1U;
	coder->stat_overflow++;
      }
    coder->pack_temporary<<=(coding_parameter+1);
    coder->pack_temporary_bits+=coding_parameter+1;
    coder->pack_temporary|=this;
    trajcoder_out8bits(coder,output);
    if (s)
      {
	coding_parameter>>=1;
	if (coding_parameter<1)
	  coding_parameter=1;
      }
  } while (s);
  coder->stat_numval++;
  return 0;
}

static int pack_item(struct coder *coder,int item, unsigned char **output, int coding, int coding_parameter)
{
    /* Find this symbol in table. */
    int s=0;
    if (item>0)
	s=1+(item-1)*2;
    else if (item<0)
	s=2+(-item-1)*2;
#if 0
    printf("Writing item 0x%x: %d\n",s, item);
#endif
    if (coding==0)
      {
	if (s>=MAXSYMBOLS)
	  return 1;
	trajcoder_write_pattern(coder,coder->code[s].pattern,coder->code[s].nbits+2,output); /* 2 extra bits for the zero termination. */
      }
    else if ((coding==1) || (coding==6))
      return write_stop_bit_code(coder,s,coding_parameter,output);
    return 0;
}

static int pack_triplet(struct coder *coder,unsigned int *s, unsigned char **output, int coding, int coding_parameter,
			unsigned int max_base, int maxbits)
{
  /* Determine base for this triplet. */
  unsigned int min_base=1U<<coding_parameter;
  unsigned int this_base=min_base;
  int i;
  unsigned int jbase=0;
  unsigned int bits_per_value;
  for (i=0; i<3; i++)
    while (s[i]>=this_base)
      {
	this_base*=2;
	jbase++;
      }
  bits_per_value=coding_parameter+jbase;
  if (jbase>=3)
    {
      if (this_base>max_base)
	return 1;
      this_base=max_base;
      bits_per_value=maxbits;
      jbase=3;
    }
#if 0
  printf("values %d %d %d give bits: %d and base %d\n",s[0],s[1],s[2],bits_per_value,jbase);
#endif
  /* 2 bits selects the base */
  coder->pack_temporary<<=2;
  coder->pack_temporary_bits+=2;
  coder->pack_temporary|=jbase;
#if 0
  printf("triplet jbase=%d numbits=%d\n",jbase,bits_per_value);
#endif
  trajcoder_out8bits(coder,output);
  for (i=0; i<3; i++)
    trajcoder_write32bits(coder,s[i],bits_per_value,output);
  return 0;
}

void trajcoder_pack_flush(struct coder *coder,unsigned char **output)
{
  /* Zero-fill just enough. */
  if (coder->pack_temporary_bits>0)
    trajcoder_write_pattern(coder,0,8-coder->pack_temporary_bits,output);
}

unsigned char *trajcoder_pack_array(struct coder *coder,int *input, int *length, int coding, int coding_parameter,int natoms, int speed)
{
  if ((coding==8) || (coding==9))
    {
      unsigned char *output=warnmalloc(4+bwlzh_get_buflen(*length));
      int i,j,k,n=*length;
      unsigned int *pval=warnmalloc(n*sizeof *pval);
      int nframes=n/natoms/3;
      int cnt=0;
      int most_negative=2147483647;
      for (i=0; i<n; i++)
	if (input[i]<most_negative)
	  most_negative=input[i];
      most_negative=-most_negative;
      output[0]=((unsigned int)most_negative)&0xFFU;
      output[1]=(((unsigned int)most_negative)>>8)&0xFFU;
      output[2]=(((unsigned int)most_negative)>>16)&0xFFU;
      output[3]=(((unsigned int)most_negative)>>24)&0xFFU;
#if 0
#define SHOWSHOW
#endif
#ifdef SHOWSHOW
      fprintf(stderr,"FP\n");
#endif
      for (i=0; i<natoms; i++)
	for (j=0; j<3; j++)
	  for (k=0; k<nframes; k++)
	    {
	      int item=input[k*3*natoms+i*3+j];
	      pval[cnt++]=(unsigned int)(item+most_negative);
#ifdef SHOWSHOW
	      if ((i==0) && (j==0))
	      {
		float xval=item*0.01;
		unsigned char *x=(unsigned char*)(&xval);
		fprintf(stderr,"%02x",(unsigned int)x[0]);
		fprintf(stderr,"%02x",(unsigned int)x[1]);
		fprintf(stderr,"%02x",(unsigned int)x[2]);
		fprintf(stderr,"%02x",(unsigned int)x[3]);
	      }
#endif

	    }
#ifdef SHOWSHOW
      fprintf(stderr,"\n");
#endif
#if 0
      {
	FILE *f=fopen("bugfile","w");
	for (i=0; i<cnt; i++)
	  fwrite(pval+i,4,1,f);
	fclose(f);
	exit(1);
      }
#endif
      if (speed>=5)
	bwlzh_compress(pval,n,output+4,length);
      else
	bwlzh_compress_no_lz77(pval,n,output+4,length);
      (*length)+=4;
      free(pval);
      return output;
    }
  else if (coding==10)
    return trajcoder_pack_array_xtc3(input,length,natoms,speed);
  else if ((coding==4) || (coding==5))
    return trajcoder_pack_array_magic(coder,input,length);
  else
    {
      unsigned char *output=NULL;
      unsigned char *output_ptr=NULL;
      int i;
      int output_length=0;
      if (!coder->code)
	prepare_code(coder);

      coder->stat_numval=0;
      coder->stat_overflow=0;
      /* Allocate enough memory for output */
      output=warnmalloc(8* *length*sizeof *output);
      output_ptr=output;
      if ((coding==2) || (coding==3) || (coding==7))
	{
	  /* Pack triplets. */
	  int ntriplets=*length/3;
	  /* Determine max base and maxbits */
	  unsigned int max_base=1U<<coding_parameter;
	  unsigned int maxbits=coding_parameter;
	  unsigned int intmax=0;
	  for (i=0; i<*length; i++)
	    {
	      int item=input[i];
	      unsigned int s=0;
	      if (item>0)
		s=1+(item-1)*2;
	      else if (item<0)
		s=2+(-item-1)*2;
	      if (s>intmax)
		intmax=s;
#if 0
#if 0
	      if (s>12000)
#endif
		printf("s=%d item=%d i=%d *length=%d\n",s,item,i,*length);
#endif
	    }
#if 0
	  printf("intmax=%u\n",intmax);
	  fflush(stdout);
#endif
	  /* Store intmax */
	  coder->pack_temporary_bits=32;
	  coder->pack_temporary=intmax;
	  trajcoder_out8bits(coder,&output_ptr);
#if 0
	  printf("intmax=%u\n",intmax);
	  printf("Initial max_base=%u maxbits=%d\n",max_base,maxbits);
#endif  
	  while (intmax>=max_base)
	    {
	      max_base*=2;
	      maxbits++;
#if 0
	      printf("max_base=%u maxbits=%d\n",max_base,maxbits);
#endif  
	    }
	  for (i=0; i<ntriplets; i++)
	    {
	      int j;
	      unsigned int s[3];
	      for (j=0; j<3; j++)
		{
		  int item=input[i*3+j];
		  /* Find this symbol in table. */
		  s[j]=0;
		  if (item>0)
		    s[j]=1+(item-1)*2;
		  else if (item<0)
		    s[j]=2+(-item-1)*2;
		}
#if 0
	      printf("Packing %d\n",i);
#endif
	      if (pack_triplet(coder,s,&output_ptr,coding,coding_parameter,max_base,maxbits))
		{
		  free(output);
		  return NULL;
		}
	    }
	}
      else
	for (i=0; i<*length; i++)
	  if (pack_item(coder,input[i],&output_ptr,coding,coding_parameter))
	    {
	      free(output);
	      return NULL;
	    }
      trajcoder_pack_flush(coder,&output_ptr);
#if 0
      for (i=0; i<100; i++)
	printf("P %d: 0x%x\n",i,output[i]);
#endif
      output_length=(int)(output_ptr-output);

#if 0
      output_length=output_ptr-output+1;
#endif

#if 0
      fprintf(stderr,"output length=%d\n",output_length);
      fflush(stdout);
#endif
#if 0
      if (coder->stat_numval)
	{
	  printf("Stat numval: %d\n",coder->stat_numval);
	  printf("Stat overflow: %d\n",coder->stat_overflow);
	  printf("Stat %%: %g\n",(100.*coder->stat_overflow)/coder->stat_numval);
	}
      printf("Output length: %d\n",output_length);
#endif

      *length=output_length;
      return output;
    }
}


static int unpack_array_fibonacci(struct coder *coder,unsigned char *packed,int *output, int length)
{
    int i;
    unsigned int extract_mask=0x80;
    unsigned char *ptr=packed;
    coder->info_last_largest_pattern=0;
    coder->info_last_largest_output=0;
    if (!coder->inverse_code)
	prepare_inverse_code(coder);
#if 0
    printf("INPUT CODE: 0x%x\n",*ptr);
#endif
    for (i=0; i<length; i++)
    {
	unsigned int pattern=0;
	/* Extract next symbol. */
	int lastwaszero=0;
	unsigned int insert_mask=0x01;
    	while (1)
	{
	    unsigned int bit=*ptr & extract_mask;
#if 0
	    printf("extracting bits...%d\n",(bit)?1:0);
#endif
	    if (bit)
		pattern|=insert_mask;
	    extract_mask>>=1;
	    insert_mask<<=1;
	    if (!extract_mask)
	    {
		extract_mask=0x80;
		ptr++;
#if 0
		printf("INPUT CODE: 0x%x\n",*ptr);
#endif
	    }
	    if ((!bit) && (lastwaszero))
		break;
	    lastwaszero=!bit;
	}
	if (pattern>=coder->inverse_code_len)
	{
	    fprintf(stderr,"TRAJNG: FATAL, this pattern does not match!\n");
	    exit(EXIT_FAILURE);
	}
	output[i]=(int)coder->inverse_code[pattern];
	if (pattern>coder->info_last_largest_pattern)
	    coder->info_last_largest_pattern=pattern;
	if ((unsigned int)abs(output[i])>coder->info_last_largest_output)
	    coder->info_last_largest_output=abs(output[i]);
#if 0
	printf("Extracted(%d) 0x%x : %d\n",i,pattern,output[i]);
#endif
    }
    return 0;
}

static int unpack_array_stop_bits(struct coder *coder,unsigned char *packed,int *output, int length, int coding_parameter)
{
  int i,j;
  unsigned int extract_mask=0x80;
  unsigned char *ptr=packed;
#if 0
  for (i=0; i<100; i++)
    printf("U: %d: 0x%x\n",i,packed[i]);
#endif
  for (i=0; i<length; i++)
    {
      unsigned int pattern=0;
      int numbits=coding_parameter;
      unsigned int bit;
      int s;
      unsigned int insert_mask=1U<<(numbits-1);
      int inserted_bits=numbits;
      do {
	for (j=0; j<numbits; j++)
	  {
	    bit=*ptr & extract_mask;
	    if (bit)
	      pattern|=insert_mask;
	    insert_mask>>=1;
	    extract_mask>>=1;
	    if (!extract_mask)
	      {
		extract_mask=0x80;
		ptr++;
	      }
	  }
	/* Check stop bit */
	bit=*ptr & extract_mask;
	extract_mask>>=1;
	if (!extract_mask)
	  {
	    extract_mask=0x80;
	    ptr++;
	  }
	if (bit)
	  {
	    numbits>>=1;
	    if (numbits<1)
	      numbits=1;
	    inserted_bits+=numbits;
	    insert_mask=1U<<(inserted_bits-1);
	  }
      } while (bit);
      s=(pattern+1)/2;
      if ((pattern%2)==0)
	s=-s;
      output[i]=s;
#if 0
      printf("Extracted(%d) 0x%x : %d\n",i,pattern,output[i]);
#endif
    }  
  return 0;
}

static int unpack_array_triplet(struct coder *coder,unsigned char *packed,int *output, int length, int coding_parameter)
{
  int i,j;
  unsigned int extract_mask=0x80;
  unsigned char *ptr=packed;
  /* Determine max base and maxbits */
  unsigned int max_base=1U<<coding_parameter;
  unsigned int maxbits=coding_parameter;
  unsigned int intmax;
  /* Get intmax */
  intmax=((unsigned int)ptr[0])<<24|
    ((unsigned int)ptr[1])<<16|
    ((unsigned int)ptr[2])<<8|
    ((unsigned int)ptr[3]);
  ptr+=4;
  while (intmax>=max_base)
    {
      max_base*=2;
      maxbits++;
    }
#if 0
  printf("coding parameter is %d\n",coding_parameter);
  printf("max_base=%u maxbits=%d\n",max_base,maxbits);
#endif
  length/=3;
  for (i=0; i<length; i++)
    {
      /* Find base */
      unsigned int jbase=0;
      unsigned int numbits;
      unsigned int bit;
      for (j=0; j<2; j++)
	{
	  bit=*ptr & extract_mask;
	  jbase<<=1;
	  if (bit)
	    jbase|=1U;
	  extract_mask>>=1;
	  if (!extract_mask)
	    {
	      extract_mask=0x80;
	      ptr++;
	    }
	}
      if (jbase==3)
	numbits=maxbits;
      else
	numbits=coding_parameter+jbase;
#if 0
      printf("numbits for %d is %d (pos=%d)\n",i,numbits,(int)(ptr-packed));
      fflush(stdout);
#endif
      for (j=0; j<3; j++)
	{
	  int s;
	  unsigned int jbit;
	  unsigned int pattern=0;
	  for (jbit=0; jbit<numbits; jbit++)
	    {
	      bit=*ptr & extract_mask;
	      pattern<<=1;
	      if (bit)
		pattern|=1U;
	      extract_mask>>=1;
	      if (!extract_mask)
		{
		  extract_mask=0x80;
		  ptr++;
		}
	    }
#if 0
	  printf("Symbol %d\n",pattern);
	  fflush(stdout);
#endif	  
	  s=(pattern+1)/2;
	  if ((pattern%2)==0)
	    s=-s;
	  output[i*3+j]=s;
	}
    }
#if 0
      printf("Extracted(%d) 0x%x : %d\n",i,pattern,output[i]);
#endif
  return 0;
}

static int unpack_array_bwlzh(struct coder *coder,unsigned char *packed,int *output, int length, int natoms)
{
  int i,j,k,n=length;
  unsigned int *pval=warnmalloc(n*sizeof *pval);
  int nframes=n/natoms/3;
  int cnt=0;
  int most_negative=(int)(((unsigned int)packed[0]) |
			  (((unsigned int)packed[1])<<8) |
			  (((unsigned int)packed[2])<<16) |
			  (((unsigned int)packed[3])<<24));
  bwlzh_decompress(packed+4,length,pval);
  for (i=0; i<natoms; i++)
    for (j=0; j<3; j++)
      for (k=0; k<nframes; k++)
	{
	  unsigned int s=pval[cnt++];
	  output[k*3*natoms+i*3+j]=(int)s-most_negative;
	}
  free(pval);
  return 0;
}

int trajcoder_unpack_array(struct coder *coder,unsigned char *packed,int *output, int length, int coding, int coding_parameter, int natoms)
{
  coder->info_last_largest_pattern=0;
  coder->info_last_largest_output=0;
  if (coding==0)
    return unpack_array_fibonacci(coder, packed, output, length);
  else if ((coding==1) || (coding==6))
    return unpack_array_stop_bits(coder, packed, output, length, coding_parameter);
  else if ((coding==2) || (coding==3) || (coding==7))
    return unpack_array_triplet(coder, packed, output, length, coding_parameter);
  else if ((coding==4) || (coding==5))
    return trajcoder_unpack_array_magic(coder, packed, output, length);
  else if ((coding==8) || (coding==9))
    return unpack_array_bwlzh(coder, packed, output, length,natoms);
  else if (coding==10)
    return trajcoder_unpack_array_xtc3(packed, output, length,natoms);
  return 1;
}

void trajcoder_get_unpack_info(struct coder *coder,int *largest_pattern, int *largest_output, int *max_output)
{
    *largest_pattern=coder->info_last_largest_pattern;
    *largest_output=coder->info_last_largest_output;
    *max_output=MAXSYMBOLSHALF;
}
