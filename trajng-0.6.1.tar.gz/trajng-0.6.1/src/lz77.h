/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef LZ77_H
#define LZ77_H

void comp_to_lz77(unsigned int *vals, int nvals,
		  unsigned int *data, int *ndata,
		  unsigned int *len, int *nlens,
		  unsigned int *offsets, int *noffsets);

void comp_from_lz77(unsigned int *data, int ndata,
		    unsigned int *len, int nlens,
		    unsigned int *offsets, int noffsets,
		    unsigned int *vals, int nvals);

#endif
