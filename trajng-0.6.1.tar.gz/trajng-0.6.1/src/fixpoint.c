/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <math.h>
#include "mylargefile.h"
#include "fixpoint.h"

#define MAX32BIT 4294967295UL
#define MAX31BIT 2147483647UL
#define SIGN32BIT 2147483648UL

/* Conversion routines from / to double precision */

/* Positive double to 32 bit fixed point value */
fix_t ud_to_fix_t(double d,double max)
{
  fix_t val;
  if (d<0.)
    d=0.;
  if (d>max)
    d=max;
  val=(fix_t)(MAX32BIT*(d/max));
  if (val>MAX32BIT)
    val=MAX32BIT;
  return val;
}

/* double to signed 32 bit fixed point value */
fix_t d_to_fix_t(double d,double max)
{
  fix_t val;
  int sign=0;
  if (d<0.)
    {
      sign=1;
      d=-d;
    }
  if (d>max)
    d=max;
  val=(fix_t)(MAX31BIT*(d/max));
  if (val>MAX31BIT)
    val=MAX31BIT;
  if (sign)
    val|=SIGN32BIT;
  return val;
}


/* 32 bit fixed point value to positive double */
double fix_t_to_ud(fix_t f, double max)
{
  return (double)f*(max/MAX32BIT);
}

/* signed 32 bit fixed point value to double */
double fix_t_to_d(fix_t f, double max)
{
  int sign=0;
  double d;
  if (f&SIGN32BIT)
    {
      sign=1;
      f&=MAX31BIT;
    }
  d=(double)f*(max/MAX31BIT);
  if (sign)
    d=-d;
  return d;
}

/* File handling routines */

/* Write the lowest num 8 bit byte content of the fix_t value */
static size_t writefix_t(FILE *file,fix_t f,int num)
{
    /* Store in little endian format. */
    size_t s=0;
    unsigned char buf; /* at least 8 bits. */
    buf=(unsigned char)(f & 0xFF);
    while ((num--) && (s+=fwrite(&buf,1,1,file)))
    {
	f >>= 8;
	buf=(unsigned char)(f & 0xFF);
    }
    return s;
}

/* Write 16 bits */
size_t writefix16(FILE *file, fix_t f)
{
    return writefix_t(file,f,2);
}

/* Write 32 bits */
size_t writefix32(FILE *file, fix_t f)
{
  return writefix_t(file,f,4);
}

/* Read the lowest num 8 bit byte content of the fix_t value */
static size_t readfix_t(FILE *file, int num, fix_t *f)
{
    unsigned char buf;
    size_t s=0;
    int shift=0;
    *f=0UL;
    do
    {
	s+=fread(&buf,1,1,file);
	*f |= ((fix_t)buf & 0xFF)<<shift;
	shift+=8;
    } while (--num);
    return s;
}

/* Read 16 bits */
size_t readfix16(FILE *file, fix_t *f)
{
    return readfix_t(file,2,f);
}

/* Read 32 bits */
size_t readfix32(FILE *file, fix_t *f)
{
    return readfix_t(file,4,f);
}

/* Write positive double as 32 bit fixed point value */
size_t write_ud_to_fix32(FILE *file, double d, double max)
{
    return writefix32(file,ud_to_fix_t(d,max));
}

/* Write double as signed 32 bit fixed point value */
size_t write_d_to_fix32(FILE *file, double d, double max)
{
    return writefix32(file,d_to_fix_t(d,max));
}

/* Read positive double as 32 bit fixed point value */
size_t read_fix32_to_ud(FILE *file, double max, double *d)
{
    fix_t f;
    size_t s=readfix32(file,&f);
    if (s)
	*d=fix_t_to_ud(f,max);
    return s;
}

/* Read double as signed 32 bit fixed point value */
size_t read_fix32_to_d(FILE *file, double max, double *d)
{
    fix_t f;
    size_t s=readfix32(file,&f);
    if (s)
	*d=fix_t_to_d(f,max);
    return s;
}

#ifndef TRAJNG_FORCE_COMPATIBLE
/* Write 64 bit unsigned value */
size_t writeuint64(FILE *file, my_uint64_t ui64)
{
  /* Store in little endian format */
  size_t s=0;
  int num=8;
  unsigned char buf; /* at least 8 bits. */
  buf=(unsigned char)(ui64 & 0xFF);
  while ((num--) && (s+=fwrite(&buf,1,1,file)))
    {
      ui64 >>= 8;
      buf=(unsigned char)(ui64 & 0xFF);
    }
  return s;
}

/* Read 64 bit unsigned value */
size_t readuint64(FILE *file, my_uint64_t *ui64)
{
  unsigned char buf;
  my_uint64_t f=0;
  size_t s=0;
  int shift=0;
  int num=8;
  do
    {
      s+=fread(&buf,1,1,file);
      f |= ((my_uint64_t)buf & 0xFF)<<shift;
      shift+=8;
    } while (--num);
  *ui64=f;
  return s;
}
#endif

/* Convert a floating point variable to two 32 bit integers with range
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
void d_to_i32x2(double d, fix_t *hi, fix_t *lo)
{
  int sign=0;
  double frac;
  double ent;
  fix_t val,vallo;
  if (d<0.)
    {
      sign=1;
      d=-d;
    }
  /* First the integer part */
  ent=floor(d);
  /* Then the fractional part */
  frac=d-ent;

  val=(fix_t)ent;
  if (sign)
    val|=SIGN32BIT;

  vallo=ud_to_fix_t(frac,1.);

  *hi=val;
  *lo=vallo;
}

/* Convert two 32 bit integers to a floating point variable
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
double i32x2_to_d(fix_t hi, fix_t lo)
{
  double ent,frac=0.;
  double val=0.;
  int sign=0;
  if (hi&SIGN32BIT)
    {
      sign=1;
      hi&=MAX31BIT;
    }
  ent=(double)hi;
  frac=fix_t_to_ud(lo,1.);
  val=ent+frac;
  if (sign)
    val=-val;
  return val;
}

/* Write a floating point variable as two 32 bit integers with range
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
size_t write_d32x2(FILE *file, double d)
{
  size_t t=0;
  fix_t hi,lo;
  d_to_i32x2(d,&hi,&lo);
  t+=writefix32(file,lo);
  t+=writefix32(file,hi);
  return t;
}

/* Read two 32 bit integers and convert them to a floating point variable
   -2.1e9 to 2.1e9 and precision to somewhere around 1e-9. */
size_t read_d32x2(FILE *file, double *d)
{
  size_t t=0;
  fix_t lo,hi;
  t+=readfix32(file,&lo);
  t+=readfix32(file,&hi);
  *d=i32x2_to_d(hi,lo);
  return t;
}

#ifdef TEST
int main()
{
  FILE *ftest=fopen("test","w");
  int i;
  double v;
  write_d32x2(ftest,897888.99999);
  write_d32x2(ftest,-897888.99999);
  write_d32x2(ftest,897888.0);
  write_d32x2(ftest,-897888.0);
  write_d32x2(ftest,0.0000001);
  write_d32x2(ftest,-0.0000001);
  write_d32x2(ftest,0.0000002);
  write_d32x2(ftest,-0.0000002);
  write_d32x2(ftest,0.5);
  write_d32x2(ftest,-0.5);
  fclose(ftest);
  ftest=fopen("test","r");
  for (i=0; i<10; i++)
    {
      read_d32x2(ftest,&v);
      printf("value is %18.14g\n",v);
    }
  return 0;
}

#endif
