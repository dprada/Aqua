/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "mylargefile.h"
#include "fixpoint.h"
#include "trajng.h"
#include "coder.h"
#include "warnmalloc.h"
#include "textconv.h"
#include "widemuldiv.h"


/* A static varible is used here to protect against overly excessive
   use of memory.  The value can be changed by calling
   TrajngSetMaxMem(int MaxMB) where MaxMB is the approximate maximum
   number of megabytes of memory to use. This should be called before
   any other trajng routines.
*/

static int max_megabytes=1000;

void DECLSPECDLLEXPORT TrajngSetMaxMem(int MaxMB)
{
  max_megabytes=MaxMB;
}

/* "Empirical" value that relates the product of chunky and the number
   of atoms to the memory usage in MB. (this is MB used per atom per
   chunky).
*/

#define MEMFACTOR 6.5e-5

/* How many chunks back to keep track of for the "big" seeks. Changing
   this directly here will break old files! If if should be changed do
   a file version alteration instead! */
#define NUMCHUNKSBIG 100

int DECLSPECDLLEXPORT TrajngComputeChunky(int chunky, int natoms, int writevel)
{
  /* Calculate appropriate chunky depending on the memory use. It
     will only restrict chunky, never increase it. */
  if (writevel)
    writevel=2;
  else
    writevel=1;
  if ((double)chunky*(double)natoms*writevel*MEMFACTOR>(double)max_megabytes)
    {
      double new_size=max_megabytes/(MEMFACTOR*writevel*natoms);
      chunky=(int)new_size;
      if (chunky<1)
	{
	  if (new_size<0.5)
	    {
	      fprintf(stderr,"TRAJNG: ERROR! Protection against overly excessive memory use!\n");
	      fprintf(stderr,"TRAJNG: Call TrajngSetMaxMem to increase the amount of available memory above %d MB / process.\n",max_megabytes);
	      exit(EXIT_FAILURE);
	    }
	  chunky=1;
	}
    }
  /* Largest number of atoms also depends on chunky. This is due to
     overflow of indices that still uses (32 bit) signed ints. */
  if ((double)chunky*(double)natoms*8*3>2000000000)
    {
      chunky=2000000000/natoms/8/3;
      if (chunky<1)
	{
	  fprintf(stderr,"TRAJNG: ERROR! Protection against too many atoms!\n");
	  fprintf(stderr,"TRAJNG: The code needs further development to handle your large number of atoms.\n");
	  exit(EXIT_FAILURE);	    
	}
    }
  return chunky;
}


struct dumper
{
    FILE *dmpfile;
    struct coder *coder;
    int is_writing;
    int dmpatoms;
    int nframe;
    int nchunky;
    int nchunkatoms;
    double chosen_precision;
    double chosen_velprecision;
    int is_file_w_vel;
    int is_file_w_box;
    int firstcoord[3];
    double *save_H;
    double *save_time, *save_lambda;
    int *save_framenumber;
    int *oldcoords;
    int *intcoords;
    int *oldvels;
    int *intcoords_ptr;
    int *temp_symbols;
    int *temp_symbols_ptr;
    int *temp_symbols_vel;
    int *temp_symbols_vel_ptr;
    int *temp_symbols_vel_inter;
    int *temp_symbols_vel_inter_ptr;
    int *temp_intra;
    int *temp_intra_ptr;
    double *temp_frame_parameters;
    int *temp_frame_framenumber;
    double *temp_frame_time_lambda;
    int oldnum;
    int chunk_number_of_dumps;
    int chunk_info_ndumps;
    int chunk_info_frame_number;
    int version;
    int initial_coding;
    int initial_coding_parameter;
    int coding;
    int coding_parameter;
    int vel_coding;
    int vel_coding_parameter;
    int initial_vel_coding;
    int initial_vel_coding_parameter;
    int header_size;
    int has_program_info;
    char *program_info;
    int has_atom_labels;
    char **atom_labels;
    char *atom_label_data;
    void *textconv_handle;
    int compatibility_mode;
    int external_index;
    int speed; /* Controls speed/compression ratio */
    FILE *indexfile;
#ifndef TRAJNG_FORCE_COMPATIBLE
    my_int64_t old_offset_pos;
    my_int64_t old_offset_pos_big[NUMCHUNKSBIG];
    my_int64_t chunk_info_pointer;
    my_int64_t big_chunk_info_pointer;
    my_int64_t chunk_info_size;
    my_int64_t coding_pos;
#endif
  /* Used for compatible mode to store a
     separate index file. */ 
    unsigned int file_block_size;
    unsigned int file_index[2];
    unsigned char *write_buffer; /* The write buffer if used. If not
				    used (a file is used for output)
				    this is NULL. */
    int write_buffer_loc; /* Location in the write buffer. */
};

static unsigned int compute_crc(unsigned char *data, int length)
{
  unsigned int crc=0;
  int alter_shift=0;
  int i;
  for (i=0; i<length; i++)
    {
      crc+=((unsigned int)data[i])<<alter_shift;
      alter_shift+=8;
      if (alter_shift>24)
	alter_shift=0;
    }
#if 0
  printf("CRC: 0x%x\n",crc);
#endif
  return crc;
}


/* Return the smallest possible header size for the different file
   versions. If version is negative return the size of the header of the current version. */
static int get_header_size(int version)
{
  int s=0;
  if ((version==13) || (version<0))
    s=94;
  else if ((version==11) || (version==12))
    s=90;
  else if (version==10)
    s=82;
  return s; 
}

static struct dumper *dumper_init(void)
{
    struct dumper *new=warnmalloc(sizeof *new);
    new->dmpfile=NULL;
    new->is_writing=0;
    new->nframe=0;
    new->oldcoords=NULL;
    new->oldvels=NULL;
    new->intcoords=NULL;
    new->temp_symbols=NULL;
    new->temp_symbols_vel=NULL;
    new->temp_symbols_vel_inter=NULL;
    new->temp_intra=NULL;
    new->temp_frame_parameters=NULL;
    new->temp_frame_framenumber=NULL;
    new->temp_frame_time_lambda=NULL;
    new->oldnum=0;
    new->coder=trajcoder_init();
    new->textconv_handle=textconv_init();
    new->compatibility_mode=0;
    new->external_index=0;
    new->indexfile=NULL;
    new->save_framenumber=NULL;
    new->save_time=NULL;
    new->save_lambda=NULL;
    new->save_H=NULL;
    new->write_buffer=NULL;
    return new;
}

static void dumper_deinit(struct dumper *dumper)
{
    trajcoder_deinit(dumper->coder);
    free(dumper->temp_frame_time_lambda);
    free(dumper->temp_frame_framenumber);
    free(dumper->temp_frame_parameters);
    free(dumper->temp_symbols);
    free(dumper->temp_symbols_vel);
    free(dumper->temp_symbols_vel_inter);
    free(dumper->temp_intra);
    free(dumper->intcoords);
    free(dumper->oldcoords);
    free(dumper->oldvels);
    if (dumper->has_program_info)
      free(dumper->program_info);
    if (dumper->has_atom_labels)
      {
	free(dumper->atom_labels);
	free(dumper->atom_label_data);
      }
    free(dumper->save_framenumber);
    free(dumper->save_time);
    free(dumper->save_lambda);
    free(dumper->save_H);
    free(dumper);
}

char DECLSPECDLLEXPORT *TrajngGetIndexFilename(char *name)
{
  int namelen=strlen(name);
  char *namemod=warnmalloc(namelen+5);
  int last_resort=1;
  memcpy(namemod,name,namelen+1);
  if (name[namelen-1]=='g')
    {
      namemod[namelen-1]='x';
      last_resort=0;
    }
  else
    {
      /* Is there another . in the name? */
      char *rdot=strrchr(namemod,'.');
      if ((rdot) && (rdot>namemod))
	{
	  rdot-=1;
	  while ((rdot>=namemod) && (*rdot!='.'))
	    rdot--;
	  if (rdot<namemod)
	    rdot=NULL;
	  if ((rdot) && ((rdot-namemod)<namelen-5))
	    {
	      if ((rdot[1]=='t') && 
		  (rdot[2]=='n') && 
		  (rdot[3]=='g') && 
		  (rdot[4]=='.'))
		rdot[3]='x';
	      last_resort=0;
	    }
	}
    }
  if (last_resort)
    memcpy(namemod+namelen,".tnx",5);
  return namemod;
}

static void write_to_index(struct dumper *dumper)
{
  largeint_add(dumper->file_block_size,dumper->file_index,2);
  if (!dumper->write_buffer)
    {
      writefix32(dumper->indexfile,dumper->file_block_size);
      writefix32(dumper->indexfile,dumper->file_index[0]);
      writefix32(dumper->indexfile,dumper->file_index[1]);
      fflush(dumper->indexfile);
    }
  dumper->file_block_size=0;
}

void DECLSPECDLLEXPORT TrajngWrite32(FILE *f, unsigned int v)
{
  writefix32(f,v);
}

void DECLSPECDLLEXPORT TrajngIndexAdd(unsigned int blocksize, unsigned int *lo, unsigned int *hi)
{
  unsigned int v[2];
  v[0]=*lo;
  v[1]=*hi;
  largeint_add(blocksize,v,2);
  *lo=v[0];
  *hi=v[1];
}

int DECLSPECDLLEXPORT TrajngGetHeaderSize(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;

  int headersize=get_header_size(dumper->version);
  
  /* Program info and atom labels also take space. */
  headersize+=dumper->has_program_info+dumper->has_atom_labels;

  return headersize;
}


/* Buffer num 8 bit bytes into buffer location buf */
static void bufferfix(unsigned char *buf, fix_t v, int num)
{
  /* Store in little endian format. */
  unsigned char c; /* at least 8 bits. */
  c=(unsigned char)(v & 0xFFU);
  while (num--)
    {
      *buf++=c;
      v >>= 8;
      c=(unsigned char)(v & 0xFFU);
    }
}

/* Wrapper routines that determine whether to write to the buffer or to the file. */
static void bufferwritefix32(struct dumper *dumper,
			     fix_t v)
{
  if (dumper->write_buffer)
    {
      bufferfix(dumper->write_buffer+dumper->write_buffer_loc,v,4);
      dumper->write_buffer_loc+=4;
    }
  else
    writefix32(dumper->dmpfile,v);
}

static void bufferwritefix16(struct dumper *dumper,
			     fix_t v)
{
  if (dumper->write_buffer)
    {
      bufferfix(dumper->write_buffer+dumper->write_buffer_loc,v,2);
      dumper->write_buffer_loc+=2;
    }
  else
    writefix16(dumper->dmpfile,v);
}

static void bufferwrite_d32x2(struct dumper *dumper, double d)
{
  fix_t hi,lo;
  d_to_i32x2(d,&hi,&lo);
  bufferwritefix32(dumper,lo);
  bufferwritefix32(dumper,hi);
}

/* Similar to fwrite but either fwrite or to the buffer */
static void bufferwrite(struct dumper *dumper,
			const void *ptr, size_t size, size_t nmemb)
{
  if (dumper->write_buffer)
    {
      int nel=(int)(size*nmemb);
      memcpy(dumper->write_buffer+dumper->write_buffer_loc,ptr,nel);
      dumper->write_buffer_loc+=nel;
    }
  else
    fwrite(ptr,size,nmemb,dumper->dmpfile);
}

static void *TrajngOpenWriteGeneric(char *name, unsigned char *buffer, 
				    int natoms, int chunky, double precision,
				    int writebox,
				    int writevel, double velprecision,
				    int compatibility_mode,
				    int initial_coding, int initial_coding_parameter,
				    int coding, int coding_parameter,
				    int initial_vel_coding, int initial_vel_coding_parameter,
				    int vel_coding, int vel_coding_parameter,
				    int speed, int compute_chunky)
{
    fix_t prec_hi, prec_lo;
    fix_t velprec_hi, velprec_lo;
    struct dumper *dumper=dumper_init();
    char *modestring="w+b";
    if (name)
      {
	dumper->write_buffer=NULL;
      }
    else if (buffer)
      {
	dumper->write_buffer=buffer;
	dumper->write_buffer_loc=0;
	dumper->dmpfile=NULL;
      }
    else
      {
	dumper_deinit(dumper);
	return NULL;
      }
    dumper->file_block_size=0;
    dumper->file_index[0]=0;
    dumper->file_index[1]=0;
    dumper->is_writing=1;
    dumper->dmpatoms=natoms;
    dumper->chosen_precision=precision;
    dumper->chosen_velprecision=velprecision;
    dumper->oldcoords=warnmalloc(natoms*3*sizeof *dumper->oldcoords);
    dumper->oldvels=warnmalloc(natoms*3*sizeof *dumper->oldvels);
    dumper->compatibility_mode=compatibility_mode;
#if 1
    if (getenv("TRAJNG_INITIAL_CODING"))
      sscanf(getenv("TRAJNG_INITIAL_CODING"),"%d%d",&initial_coding,&initial_coding_parameter);
    if (getenv("TRAJNG_CODING"))
      sscanf(getenv("TRAJNG_CODING"),"%d%d",&coding,&coding_parameter);
    if (getenv("TRAJNG_INITIAL_VEL_CODING"))
      sscanf(getenv("TRAJNG_INITIAL_VEL_CODING"),"%d%d",&initial_vel_coding,&initial_vel_coding_parameter);
    if (getenv("TRAJNG_VEL_CODING"))
      sscanf(getenv("TRAJNG_VEL_CODING"),"%d%d",&vel_coding,&vel_coding_parameter);
    if (getenv("TRAJNG_SPEED"))
      sscanf(getenv("TRAJNG_SPEED"),"%d",&speed);
#endif
    if (compute_chunky)
      chunky=TrajngComputeChunky(chunky, natoms,writevel);

    /* If speed is set to 0, chose the default speed. */
    if (!speed)
      speed=4;

    /* Boundaries of speed. */
    if (speed<1)
      speed=1;
    if (speed>6)
      speed=6;

    dumper->speed=speed;
    dumper->nchunky=chunky;

    dumper->nchunkatoms=5000;
    if (dumper->dmpatoms<dumper->nchunkatoms)
      dumper->nchunkatoms=dumper->dmpatoms;

#ifdef TRAJNG_FORCE_COMPATIBLE
    dumper->compatibility_mode=1;
#else
    if ((!dumper->compatibility_mode) && (my_off_t_is_too_small()))
      {
	fprintf(stderr,"TRAJNG: WARNING! off_t is smaller than 64 bits. You should really recompile! For now I will create compatibility mode files only!\n");
	dumper->compatibility_mode=1;
      }
#endif
    if (dumper->compatibility_mode)
      modestring="wb";
    if (!dumper->write_buffer)
      {
	if (!(dumper->dmpfile=fopen(name,modestring)))
	  {
	    dumper_deinit(dumper);
	    return NULL;
	  }
	if (dumper->compatibility_mode)
	  {
	    char *namemod=TrajngGetIndexFilename(name);
	    if (!(dumper->indexfile=fopen(namemod,modestring)))
	      {
		dumper_deinit(dumper);
		return NULL;
	      }
	    free(namemod);
	  }
      }
    dumper->file_block_size=0;
    if (coding==0)
      {
	/* Fibonacci coding of position support is deprecated */
	dumper_deinit(dumper);
	return NULL;
      }
    dumper->coding=coding;
    dumper->coding_parameter=coding_parameter;
    dumper->initial_coding=initial_coding;
    dumper->initial_coding_parameter=initial_coding_parameter;
    dumper->vel_coding=vel_coding;
    dumper->vel_coding_parameter=vel_coding_parameter;
    dumper->initial_vel_coding=initial_vel_coding;
    dumper->initial_vel_coding_parameter=initial_vel_coding_parameter;
    if (!writevel)
      {
	dumper->vel_coding=0;
	dumper->vel_coding_parameter=0;
	dumper->initial_vel_coding=0;
	dumper->initial_vel_coding_parameter=0;
	dumper->chosen_velprecision=0.;
      }
    dumper->version=13;
    dumper->header_size=get_header_size(dumper->version);
    bufferwrite(dumper,"TRAJNG13",8,1);
    dumper->is_file_w_vel=writevel;
    dumper->is_file_w_box=writebox;
    bufferwritefix16(dumper,dumper->is_file_w_vel);
    bufferwritefix16(dumper,dumper->is_file_w_box);
    bufferwritefix16(dumper,dumper->nchunky);
    bufferwritefix32(dumper,dumper->dmpatoms);
    bufferwritefix32(dumper,dumper->nchunkatoms);
    d_to_i32x2(dumper->chosen_precision,&prec_hi,&prec_lo);
    d_to_i32x2(dumper->chosen_velprecision,&velprec_hi,&velprec_lo);
    /* Ensure same rounding both when writing and when reading */
    dumper->chosen_precision=i32x2_to_d(prec_hi,prec_lo);
    dumper->chosen_velprecision=i32x2_to_d(velprec_hi,velprec_lo);
    bufferwritefix32(dumper,prec_lo);
    bufferwritefix32(dumper,prec_hi);
    bufferwritefix32(dumper,velprec_lo);
    bufferwritefix32(dumper,velprec_hi);
    bufferwritefix32(dumper,dumper->compatibility_mode);
#ifndef TRAJNG_FORCE_COMPATIBLE
    if (!dumper->compatibility_mode)
      {
	dumper->coding_pos=my_ftell(dumper->dmpfile);
	bufferwritefix32(dumper,dumper->initial_coding); 
	bufferwritefix32(dumper,dumper->initial_coding_parameter); 
	bufferwritefix32(dumper,dumper->coding); 
	bufferwritefix32(dumper,dumper->coding_parameter); 
	bufferwritefix32(dumper,dumper->vel_coding); 
	bufferwritefix32(dumper,dumper->vel_coding_parameter);
	bufferwritefix32(dumper,dumper->initial_vel_coding); 
	bufferwritefix32(dumper,dumper->initial_vel_coding_parameter);
      }
    else
      {
#endif
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
	bufferwritefix32(dumper,0);
#ifndef TRAJNG_FORCE_COMPATIBLE
      }
#endif
    /* Program info and atom labels are written before the very first frame */
    dumper->has_program_info=0;
    dumper->has_atom_labels=0;
    dumper->save_framenumber=warnmalloc(chunky*sizeof *dumper->save_framenumber);
    dumper->save_time=warnmalloc(chunky*sizeof *dumper->save_time);
    dumper->save_lambda=warnmalloc(chunky*sizeof *dumper->save_lambda);
    dumper->save_H=warnmalloc(chunky*9*sizeof *dumper->save_H);
    dumper->intcoords=warnmalloc(natoms*3*chunky*sizeof *dumper->intcoords);
    dumper->temp_symbols=warnmalloc(natoms*3*chunky*sizeof *dumper->temp_symbols);
    dumper->temp_symbols_vel=warnmalloc(natoms*3*chunky*sizeof *dumper->temp_symbols_vel);
    dumper->temp_symbols_vel_inter=warnmalloc(natoms*3*chunky*sizeof *dumper->temp_symbols_vel_inter);
    dumper->temp_intra=warnmalloc(natoms*3*chunky*sizeof *dumper->temp_intra);

    /* Firstcoord sets origin. Now zero (altering this will break parallel processing) */
    dumper->firstcoord[0]=0;
    dumper->firstcoord[1]=0;
    dumper->firstcoord[2]=0;

    return (void*)dumper;
}

void DECLSPECDLLEXPORT *TrajngOpenWriteSpecify(char *name, int natoms, int chunky, double precision,
					       int writebox,
					       int writevel, double velprecision,
					       int compatibility_mode,
					       int initial_coding, int initial_coding_parameter,
					       int coding, int coding_parameter,
					       int initial_vel_coding, int initial_vel_coding_parameter,
					       int vel_coding, int vel_coding_parameter,
					       int speed,int compute_chunky)
{
  return TrajngOpenWriteGeneric(name,NULL,natoms,chunky,precision,writebox,writevel,velprecision,compatibility_mode,
				initial_coding,initial_coding_parameter,
				coding,coding_parameter,
				initial_vel_coding,initial_vel_coding_parameter,
				vel_coding,vel_coding_parameter,speed,compute_chunky);
}

void DECLSPECDLLEXPORT *TrajngOpenWriteBuffer(unsigned char *buffer, int natoms, int chunky, double precision,
					      int writebox,
					      int writevel, double velprecision,
					      int compatibility_mode,
					      int initial_coding, int initial_coding_parameter,
					      int coding, int coding_parameter,
					      int initial_vel_coding, int initial_vel_coding_parameter,
					      int vel_coding, int vel_coding_parameter,
					      int speed, int compute_chunky)
{
  return TrajngOpenWriteGeneric(NULL,buffer,natoms,chunky,precision,writebox,writevel,velprecision,compatibility_mode,
				initial_coding,initial_coding_parameter,
				coding,coding_parameter,
				initial_vel_coding,initial_vel_coding_parameter,
				vel_coding,vel_coding_parameter,speed, compute_chunky);
}

int DECLSPECDLLEXPORT TrajngGetBufferLength(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  if (dumper->write_buffer)
    return dumper->write_buffer_loc;
  else
    return -1;
}

void DECLSPECDLLEXPORT TrajngResetBuffer(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  if (dumper->write_buffer)
    dumper->write_buffer_loc=0;
}

void DECLSPECDLLEXPORT *TrajngOpenWrite(char *name, int natoms, int chunky, double precision,
					int writebox,
					int writevel, double velprecision,
					int compatibility_mode,
					int speed)
{
  /* Auto select compression algorithms. */
  return TrajngOpenWriteSpecify(name,natoms,chunky,precision,writebox,writevel,velprecision,compatibility_mode,
				-1,-1,-1,-1,-1,-1,-1,-1,speed,1);
}

int DECLSPECDLLEXPORT TrajngSetProgramInfo(void *handle,
			 char *program_info)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  if (dumper->is_writing)
    {
      if (dumper->nframe)
	return 1; /* If frame data has been written to the file already,
		     it is too late to set program info */
      dumper->has_program_info=strlen(program_info)+1;
      dumper->program_info=warnmalloc(dumper->has_program_info);
      strcpy(dumper->program_info,program_info);
      textconv_native_to_ascii(dumper->textconv_handle,dumper->program_info);
    }
  else
    return 1;

  return 0;
}

int DECLSPECDLLEXPORT TrajngSetAtomLabels(void *handle,
			char **atom_labels)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  if (dumper->is_writing)
    {
      int i;
      if (dumper->nframe)
	return 1; /* If frame data has been written to the file already,
		     it is too late to set program info */
      dumper->has_atom_labels=0;
      dumper->atom_labels=warnmalloc(dumper->dmpatoms*sizeof *dumper->atom_labels);
      for (i=0; i<dumper->dmpatoms; i++)
	{
	  int len=strlen(atom_labels[i])+1;
	  dumper->has_atom_labels+=len;
	}
      dumper->atom_label_data=warnmalloc(dumper->has_atom_labels);
      dumper->atom_labels[0]=dumper->atom_label_data;
      for (i=0; i<dumper->dmpatoms; i++)
	{
	  int len=strlen(atom_labels[i])+1;
	  memcpy(dumper->atom_labels[i],atom_labels[i],len);
	  textconv_native_to_ascii(dumper->textconv_handle,dumper->atom_labels[i]);
	  if (i<dumper->dmpatoms-1)
	    dumper->atom_labels[i+1]=dumper->atom_labels[i]+len;
	}
    }
  else
    return 1;

  return 0;
}

char DECLSPECDLLEXPORT **TrajngGetAtomLabels(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  if (dumper->has_atom_labels)
    return dumper->atom_labels;
  else
    return NULL;
}

static int determine_best_coding_stop_bits(struct coder *coder,int *input, int *length,
					   int *coding_parameter, int natoms)
{
  int bits;
  unsigned char *packed;
  int best_length=0;
  int new_parameter=-1;
  int io_length;
  for (bits=1; bits<20; bits++)
    {
      io_length=*length;
      packed=trajcoder_pack_array(coder,input,&io_length,
				  1,bits,natoms,0);
      if (packed)
	{
	  if ((new_parameter==-1) || (io_length<best_length))
	    {
	      new_parameter=bits;
	      best_length=io_length;
	    }
	  free(packed);
	}
    }
  if (new_parameter==-1)
    return 1;

  *coding_parameter=new_parameter;
  *length=best_length;
  return 0;
}

static int determine_best_coding_triple(struct coder *coder,int *input, int *length,
					int *coding_parameter, int natoms)
{
  int bits;
  unsigned char *packed;
  int best_length=0;
  int new_parameter=-1;
  int io_length;
  for (bits=1; bits<20; bits++)
    {
      io_length=*length;
      packed=trajcoder_pack_array(coder,input,&io_length,
				  2,bits,natoms,0);
      if (packed)
	{
	  if ((new_parameter==-1) || (io_length<best_length))
	    {
	      new_parameter=bits;
	      best_length=io_length;
	    }
	  free(packed);
	}
    }
  if (new_parameter==-1)
    return 1;

  *coding_parameter=new_parameter;
  *length=best_length;
  return 0;
}

static void determine_best_initial_coding(struct dumper *dumper,
					  struct coder *coder, int *input_intra,
					  int *input_intcoords, int *length)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
  my_int64_t this_offset_pos;
#endif
  int new_coding=-1;
  int new_parameter=-1;
  int best_length=0;
  int io_length;
  int coding_parameter;
  if (dumper->initial_coding<0)
    {
      unsigned char *packed;
      io_length=*length;
      if (!determine_best_coding_triple(coder,input_intra,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input_intcoords,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=7;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      packed=trajcoder_pack_array(coder,input_intcoords,&io_length,
				  5,0,dumper->dmpatoms,dumper->speed);
      if (packed)
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=5;
	      new_parameter=0;
	    }
	  free(packed);
	}
      if (dumper->speed>=2)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(coder,input_intcoords,&io_length,
				      10,0,dumper->dmpatoms,dumper->speed);
	  if (packed)
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=10;
		  new_parameter=0;
		}
	    }
	  free(packed);
	}
      if (dumper->speed>=6)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(coder,input_intra,&io_length,
				      9,0,dumper->dmpatoms,dumper->speed);
	  if (packed)
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=9;
		  new_parameter=0;
		}
	    }
	  free(packed);
	}
    }
  else
    {
      if (dumper->initial_coding==3)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input_intra,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      if (dumper->initial_coding==7)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input_intcoords,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=7;
	      new_parameter=coding_parameter;
	    }
	}
    }
  if (new_coding==-1)
    {
      fprintf(stderr,"TRAJNG: Cannot find a proper initial coding for this dumpfile.\n");
      exit(EXIT_FAILURE);
    }
  dumper->initial_coding=new_coding;
  dumper->initial_coding_parameter=new_parameter;
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      this_offset_pos=my_ftell(dumper->dmpfile);
      my_fseek(dumper->dmpfile,dumper->coding_pos,SEEK_SET);
      writefix32(dumper->dmpfile,dumper->initial_coding); 
      writefix32(dumper->dmpfile,dumper->initial_coding_parameter); 
      writefix32(dumper->dmpfile,dumper->coding); 
      writefix32(dumper->dmpfile,dumper->coding_parameter); 
      writefix32(dumper->dmpfile,dumper->vel_coding);
      writefix32(dumper->dmpfile,dumper->vel_coding_parameter);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding_parameter);
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
}

static void determine_best_coding(struct dumper *dumper,
				  struct coder *coder,int *input, int *input_intra, 
				  int *input_intcoords,int *length)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
  my_int64_t this_offset_pos;
#endif
  int new_coding=-1;
  int new_parameter=-1;
  int best_length=0;
  int io_length;
  int coding_parameter;
  if (dumper->coding<0)
    {
      unsigned char *packed;
      io_length=*length;
      if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=2;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input_intcoords,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=7;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input_intra,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      packed=trajcoder_pack_array(coder,input,&io_length,
				  4,0,dumper->dmpatoms,dumper->speed);
      if (packed)
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=4;
	      new_parameter=0;
	    }
	  free(packed);
	}
      io_length=*length;
      packed=trajcoder_pack_array(coder,input_intcoords,&io_length,
				  5,0,dumper->dmpatoms,dumper->speed);
      if (packed)
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=5;
	      new_parameter=0;
	    }
	  free(packed);
	}
      if (dumper->speed>=2)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(coder,input_intcoords,&io_length,
				      10,0,dumper->dmpatoms,dumper->speed);
	  if ((packed) && (io_length<best_length))
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=10;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
      if (dumper->speed>=4)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(coder,input,&io_length,
				      8,0,dumper->dmpatoms,dumper->speed);
	  if ((packed) && (io_length<best_length))
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=8;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
      if (dumper->speed>=6)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(coder,input_intra,&io_length,
				      9,0,dumper->dmpatoms,dumper->speed);
	  if ((packed) && (io_length<best_length))
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=9;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
    }
  else
    {
      new_coding=-1;
      if (dumper->coding==1)
	{
	  io_length=*length;
	  if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->coding==2)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=2;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->coding==3)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input_intra,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->coding==7)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input_intcoords,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=7;
	      new_parameter=coding_parameter;
	    }
	}
    }
  if (new_coding==-1)
    {
      fprintf(stderr,"TRAJNG: Cannot find a proper coding for this dumpfile.\n");
      exit(EXIT_FAILURE);
    }
  dumper->coding=new_coding;
  dumper->coding_parameter=new_parameter;
#if 0
  printf("Determined coding: %d and parameter: %d\n",dumper->coding,dumper->coding_parameter);
#endif  
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      this_offset_pos=my_ftell(dumper->dmpfile);
      my_fseek(dumper->dmpfile,dumper->coding_pos,SEEK_SET);
      writefix32(dumper->dmpfile,dumper->initial_coding); 
      writefix32(dumper->dmpfile,dumper->initial_coding_parameter); 
      writefix32(dumper->dmpfile,dumper->coding); 
      writefix32(dumper->dmpfile,dumper->coding_parameter); 
      writefix32(dumper->dmpfile,dumper->vel_coding);
      writefix32(dumper->dmpfile,dumper->vel_coding_parameter);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding_parameter);
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
}

static void determine_best_vel_coding(struct dumper *dumper,
				      struct coder *coder,int *input, int *input_inter, int *length)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
  my_int64_t this_offset_pos;
#endif
  int new_coding=-1;
  int new_parameter=-1;
  int best_length=0;
  int io_length;
  int coding_parameter;
  if (dumper->vel_coding<0)
    {
      unsigned char *packed;
      io_length=*length;
      packed=trajcoder_pack_array(dumper->coder,input,&io_length,
				  0,0,dumper->dmpatoms,dumper->speed);
      if (packed)
	{
	  best_length=io_length;
	  new_coding=0;
	  new_parameter=0;
	  free(packed);
	}
      io_length=*length;
      if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input_inter,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=2;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_stop_bits(coder,input_inter,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=6;
	      new_parameter=coding_parameter;
	    }
	}
      if (dumper->speed>=4)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(dumper->coder,input,&io_length,
				      9,0,dumper->dmpatoms,dumper->speed);
	  if (packed)
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=9;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
      if (dumper->speed>=4)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(dumper->coder,input_inter,&io_length,
				      8,0,dumper->dmpatoms,dumper->speed);
	  if (packed)
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=8;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
    }
  else
    {
      new_coding=-1;
      if (dumper->vel_coding==0)
	{
	  new_coding=0;
	  new_parameter=0;
	}
      else if (dumper->vel_coding==1)
	{
	  io_length=*length;
	  if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->vel_coding==2)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input_inter,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=2;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->vel_coding==3)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->vel_coding==6)
	{
	  io_length=*length;
	  if (!determine_best_coding_stop_bits(coder,input_inter,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=6;
	      new_parameter=coding_parameter;
	    }
	}
    }
  if (new_coding==-1)
    {
      fprintf(stderr,"TRAJNG: Cannot find a proper velocity coding for this dumpfile.\n");
      exit(EXIT_FAILURE);
    }
  dumper->vel_coding=new_coding;
  dumper->vel_coding_parameter=new_parameter;
#if 0
  printf("Determined velocity coding: %d and parameter: %d\n",dumper->vel_coding,dumper->vel_coding_parameter);
#endif  
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      this_offset_pos=my_ftell(dumper->dmpfile);
      my_fseek(dumper->dmpfile,dumper->coding_pos,SEEK_SET);
      writefix32(dumper->dmpfile,dumper->initial_coding); 
      writefix32(dumper->dmpfile,dumper->initial_coding_parameter); 
      writefix32(dumper->dmpfile,dumper->coding); 
      writefix32(dumper->dmpfile,dumper->coding_parameter); 
      writefix32(dumper->dmpfile,dumper->vel_coding);
      writefix32(dumper->dmpfile,dumper->vel_coding_parameter);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding); 
      writefix32(dumper->dmpfile,dumper->initial_vel_coding_parameter); 
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
}

static void determine_best_initial_vel_coding(struct dumper *dumper,
					      struct coder *coder,int *input, int *length)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
  my_int64_t this_offset_pos;
#endif
  int new_coding=-1;
  int new_parameter=-1;
  int best_length=0;
  int io_length;
  int coding_parameter;
  if (dumper->initial_vel_coding<0)
    {
      unsigned char *packed;
      io_length=*length;
      packed=trajcoder_pack_array(dumper->coder,input,&io_length,
				  0,0,dumper->dmpatoms,dumper->speed);
      if (packed)
	{
	  best_length=io_length;
	  new_coding=0;
	  new_parameter=0;
	  free(packed);
	}
      io_length=*length;
      if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      io_length=*length;
      if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	{
	  if ((new_coding==-1) || (io_length<best_length))
	    {
	      best_length=io_length;
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
      if (dumper->speed>=4)
	{
	  io_length=*length;
	  packed=trajcoder_pack_array(dumper->coder,input,&io_length,
				      9,0,dumper->dmpatoms,dumper->speed);
	  if (packed)
	    {
	      if ((new_coding==-1) || (io_length<best_length))
		{
		  best_length=io_length;
		  new_coding=9;
		  new_parameter=0;
		}
	      free(packed);
	    }
	}
    }
  else
    {
      new_coding=-1;
      if (dumper->initial_vel_coding==0)
	{
	  new_coding=0;
	  new_parameter=0;
	}
      else if (dumper->initial_vel_coding==1)
	{
	  io_length=*length;
	  if (!determine_best_coding_stop_bits(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=1;
	      new_parameter=coding_parameter;
	    }
	}
      else if (dumper->initial_vel_coding==3)
	{
	  io_length=*length;
	  if (!determine_best_coding_triple(coder,input,&io_length,&coding_parameter,dumper->dmpatoms))
	    {
	      new_coding=3;
	      new_parameter=coding_parameter;
	    }
	}
    }
  if (new_coding==-1)
    {
      fprintf(stderr,"TRAJNG: Cannot find a proper initial velocity coding for this dumpfile.\n");
      exit(EXIT_FAILURE);
    }
  dumper->initial_vel_coding=new_coding;
  dumper->initial_vel_coding_parameter=new_parameter;
#if 0
  printf("Determined velocity coding: %d and parameter: %d\n",dumper->initial_vel_coding,dumper->initial_vel_coding_parameter);
#endif  
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      this_offset_pos=my_ftell(dumper->dmpfile);
      my_fseek(dumper->dmpfile,dumper->coding_pos,SEEK_SET);
      writefix32(dumper->dmpfile,dumper->initial_coding); 
      writefix32(dumper->dmpfile,dumper->initial_coding_parameter); 
      writefix32(dumper->dmpfile,dumper->coding); 
      writefix32(dumper->dmpfile,dumper->coding_parameter); 
      writefix32(dumper->dmpfile,dumper->vel_coding);
      writefix32(dumper->dmpfile,dumper->vel_coding_parameter);
      writefix32(dumper->dmpfile,dumper->initial_vel_coding); 
      writefix32(dumper->dmpfile,dumper->initial_vel_coding_parameter); 
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
}

static int verify_coding(int coding, char *name)
{
  int rval=0;
  if (coding<-1)
    rval=1;
  if (coding>10)
    rval=1;
  if (rval)
    fprintf(stderr,"TRAJNG: Unknown coding %d for %s\n",coding,name);
  return rval;
}

static int verify_and_fix_all_coding(struct dumper *dumper)
{
  if (verify_coding(dumper->initial_coding,"Initial coding"))
    return 1;
  if (dumper->nchunky!=1)
    if (verify_coding(dumper->coding,"Position coding"))
      return 1;
  /* In version 1.0 of the trajectory file single frame velocity
     coding with the triple algorithm was stored as coding 2. In
     version 1.1 single frame velocity coding should be stored as
     coding 3 and coding 2 is for inter-frame compression.
  */
  if ((dumper->version==10) && (dumper->vel_coding==2))
    dumper->vel_coding=3;
  if ((dumper->version==10) && (dumper->initial_vel_coding==2))
    dumper->initial_vel_coding=3;
  if (verify_coding(dumper->vel_coding,"Velocity coding"))
    return 1;
  if (verify_coding(dumper->initial_vel_coding,"Initial velocity coding"))
    return 1;
  return 0;
}

static void flush_dumps(struct dumper *dumper, int ndumps_write)
{
  unsigned char *packed;

  int ilength, length;

  int i, idump;

  /* Do the initial frame */
  int firstframe=dumper->nframe-ndumps_write;

  /* Is this the very first frame in the whole file we need to write additional information. */
  if (firstframe==0)
    {
      /* Time to write the very first frame, so write additional info, if there is any! */
      bufferwritefix32(dumper,dumper->has_program_info);
      bufferwritefix32(dumper,dumper->has_atom_labels);
      if (dumper->has_program_info)
	{
	  bufferwrite(dumper,dumper->program_info,1,dumper->has_program_info);
	  dumper->header_size+=dumper->has_program_info;
	}
      if (dumper->has_atom_labels)
	{
	  bufferwrite(dumper,dumper->atom_label_data,1,dumper->has_atom_labels);
	  dumper->header_size+=dumper->has_atom_labels;
	}
      bufferwritefix32(dumper,dumper->firstcoord[0]);
      bufferwritefix32(dumper,dumper->firstcoord[1]);
      bufferwritefix32(dumper,dumper->firstcoord[2]);
      dumper->file_block_size=dumper->header_size;
    }
#ifndef TRAJNG_FORCE_COMPATIBLE
  else if (!dumper->compatibility_mode)
    {
      /* We have been here before, so store the offsets. */
      my_int64_t this_offset_pos=my_ftell(dumper->dmpfile);
      my_uint64_t diff=(my_uint64_t)(this_offset_pos-dumper->old_offset_pos);
      my_fseek(dumper->dmpfile,dumper->old_offset_pos,SEEK_SET);
      my_fseek(dumper->dmpfile,4,SEEK_CUR); /* Skip "DUMP" string. */
      writeuint64(dumper->dmpfile,diff);
      my_fseek(dumper->dmpfile,8,SEEK_CUR); /* Skip future offset number. */
      my_fseek(dumper->dmpfile,4,SEEK_CUR); /* Skip frame number. */
      bufferwritefix32(dumper,dumper->nchunky); /* Here this must be true. */
      /* Go back. */
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      dumper->old_offset_pos=my_ftell(dumper->dmpfile);
      if (dumper->oldnum==NUMCHUNKSBIG)
	{
	  /* Go back very far and write the offset diff */
	  my_int64_t this_offset_pos=my_ftell(dumper->dmpfile);
	  my_uint64_t diff=(my_uint64_t)(this_offset_pos-dumper->old_offset_pos_big[0]);
	  my_fseek(dumper->dmpfile,dumper->old_offset_pos_big[0],SEEK_SET);
	  my_fseek(dumper->dmpfile,4,SEEK_CUR); /* Skip "DUMP" string. */
	  my_fseek(dumper->dmpfile,8,SEEK_CUR); /* Skip short offset number. */
	  writeuint64(dumper->dmpfile,diff); /* Write large difference */
	  /* Go back. */
	  my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
	  /* Iterate buffer. */
	  for (i=0; i<NUMCHUNKSBIG-1; i++)
	    dumper->old_offset_pos_big[i]=dumper->old_offset_pos_big[i+1];
	  dumper->oldnum--;
	}
      dumper->old_offset_pos_big[dumper->oldnum]=dumper->old_offset_pos;
      dumper->oldnum++;
    }
#endif
  if (dumper->compatibility_mode)
    write_to_index(dumper);
  bufferwrite(dumper,"DUMP",4,1);
  /* 64-bit offset from start of this chunk to start of next chunk. */
  /* 64-bit offset from start of this chunk to start of next NN chunk. */
  /* Write as 4 32 bit zeros. */
  bufferwritefix32(dumper,0);
  bufferwritefix32(dumper,0);
  bufferwritefix32(dumper,0);
  bufferwritefix32(dumper,0);

  bufferwritefix32(dumper,firstframe); /* Frame number. */
  bufferwritefix32(dumper,0); /* Number of dumps stored in this chunk. */
  dumper->file_block_size=4+4*4+4*2;

  /* Do the meta data for the first frame. */

  if (dumper->is_file_w_box)
    {
      for (i=0; i<9; i++)
	bufferwrite_d32x2(dumper,dumper->save_H[i]);
      dumper->file_block_size+=9*8;
    }
  bufferwritefix32(dumper,dumper->save_framenumber[0]);
  bufferwrite_d32x2(dumper,dumper->save_time[0]);
  bufferwrite_d32x2(dumper,dumper->save_lambda[0]);
  dumper->file_block_size+=4+2*8;

  /* Compute all the required differences */
  dumper->temp_intra_ptr=dumper->temp_intra;
  dumper->temp_symbols_ptr=dumper->temp_symbols;
  dumper->temp_symbols_vel_ptr=dumper->temp_symbols_vel;
  dumper->temp_symbols_vel_inter_ptr=dumper->temp_symbols_vel_inter;
  for (idump=0; idump<ndumps_write; idump++)
    {
      int j;
      int intra_v[3]={0,0,0};
      /* Intra frame difference */
      /* Coordinates */
      for (i=0; i<dumper->dmpatoms; i++)
	for (j=0; j<3; j++)
	  {
	    int thisc=dumper->intcoords[idump*dumper->dmpatoms*3+i*3+j];
	    *dumper->temp_intra_ptr++=thisc-intra_v[j];
	    intra_v[j]=thisc;
	  }
      /* Inter frame difference? */
      if (idump>0)
	{
	  /* Coordinates */
	  for (i=0; i<dumper->dmpatoms; i++)
	    for (j=0; j<3; j++)
	      *dumper->temp_symbols_ptr++=dumper->intcoords[idump*dumper->dmpatoms*3+i*3+j]-dumper->intcoords[(idump-1)*dumper->dmpatoms*3+i*3+j];
	  /* Velocities */
	  if (dumper->is_file_w_vel)
	    for (i=0; i<dumper->dmpatoms; i++)
	      for (j=0; j<3; j++)
		*dumper->temp_symbols_vel_inter_ptr++=dumper->temp_symbols_vel[idump*dumper->dmpatoms*3+i*3+j]-dumper->temp_symbols_vel[(idump-1)*dumper->dmpatoms*3+i*3+j];
	}
    }

  length=dumper->dmpatoms*3;

  /* Do the first frame. */
  if ((dumper->initial_coding<0) || (dumper->initial_coding_parameter<0))
    determine_best_initial_coding(dumper,dumper->coder,dumper->temp_intra,dumper->intcoords,&length);

  if ((dumper->initial_coding==5) || (dumper->initial_coding==7) || (dumper->initial_coding==10))
    packed=trajcoder_pack_array(dumper->coder,dumper->intcoords,&length,
				dumper->initial_coding,dumper->initial_coding_parameter,dumper->dmpatoms,dumper->speed);
  else
    packed=trajcoder_pack_array(dumper->coder,dumper->temp_intra,&length,
				dumper->initial_coding,dumper->initial_coding_parameter,dumper->dmpatoms,dumper->speed);
	
  if (!packed)
    {
      fprintf(stderr,"TRAJNG: Failed to pack initial frames.\n");
      exit(EXIT_FAILURE);
    }
  bufferwritefix16(dumper,dumper->initial_coding);
  bufferwritefix16(dumper,dumper->initial_coding_parameter);
  bufferwritefix32(dumper,length);
  bufferwrite(dumper,packed,length,1);
  bufferwritefix32(dumper,compute_crc(packed,length));
  free(packed);
  dumper->file_block_size+=2*2+4+length+4;

  if (dumper->is_file_w_vel)
    {
      length=dumper->dmpatoms*3;
      
      if ((dumper->initial_vel_coding<0) || (dumper->initial_vel_coding_parameter<0))
	determine_best_initial_vel_coding(dumper,dumper->coder,dumper->temp_symbols_vel,&length);
	    
      packed=trajcoder_pack_array(dumper->coder,dumper->temp_symbols_vel,&length,
				  dumper->initial_vel_coding,dumper->initial_vel_coding_parameter,dumper->dmpatoms,dumper->speed);
	    
      if (!packed)
	{
	  fprintf(stderr,"TRAJNG: Failed to pack initial frame velocities.\n");
	  exit(EXIT_FAILURE);
	}
      bufferwritefix16(dumper,dumper->initial_vel_coding);
      bufferwritefix16(dumper,dumper->initial_vel_coding_parameter);
      bufferwritefix32(dumper,length);
      bufferwrite(dumper,packed,length,1);
      bufferwritefix32(dumper,compute_crc(packed,length));
      free(packed);
      dumper->file_block_size+=2*2+4+length+4;
    }
	
  /* Do the meta data for the next frames */
  for (idump=1; idump<ndumps_write; idump++)
    {
      fix_t more_data=(fix_t)1;
      bufferwritefix16(dumper,more_data); /* Signal that more data appears. */
      dumper->file_block_size+=2;
      
      if (dumper->is_file_w_box)
	{
	  for (i=0; i<9; i++)
	    bufferwrite_d32x2(dumper,dumper->save_H[idump*9+i]);
	  dumper->file_block_size+=9*8;
	}
      bufferwritefix32(dumper,dumper->save_framenumber[idump]);
      bufferwrite_d32x2(dumper,dumper->save_time[idump]);
      bufferwrite_d32x2(dumper,dumper->save_lambda[idump]);
      dumper->file_block_size+=4+2*8;
    }
  /* If there is fewer than dumper->nchunky frames in this chunky
     we signal this here. by writing a zero */
  if (ndumps_write<dumper->nchunky)
    {
      fix_t more_data=(fix_t)0;
      bufferwritefix16(dumper,more_data); /* Signal that no more data appears. */
      dumper->file_block_size+=2;
    }

  if (ndumps_write>1)
    {
      /* Do the next frames */
      ilength=dumper->dmpatoms*3*(ndumps_write-1);
      length=ilength;

      if ((dumper->coding<0) || (dumper->coding_parameter<0))
	determine_best_coding(dumper,dumper->coder,dumper->temp_symbols,
			      dumper->temp_intra+dumper->dmpatoms*3,
			      dumper->intcoords+dumper->dmpatoms*3,&length);

      if (dumper->is_file_w_vel)
	{
	  if ((dumper->vel_coding<0) || (dumper->vel_coding_parameter<0))
	    determine_best_vel_coding(dumper,dumper->coder,dumper->temp_symbols_vel+dumper->dmpatoms*3,
				      dumper->temp_symbols_vel_inter,&length);
	}


      /* Inter-dump ? */
      if ((dumper->coding==0) || (dumper->coding==1) || (dumper->coding==2) || (dumper->coding==4) || (dumper->coding==8))
	packed=trajcoder_pack_array(dumper->coder,dumper->temp_symbols,&length,
				    dumper->coding,dumper->coding_parameter,dumper->dmpatoms,dumper->speed);
      else /* Intra dump! */
	if ((dumper->coding==5) || (dumper->coding==7) || (dumper->coding==10))
	  {
	    packed=trajcoder_pack_array(dumper->coder,dumper->intcoords+dumper->dmpatoms*3,&length,
					dumper->coding,dumper->coding_parameter,dumper->dmpatoms,dumper->speed);
	  }
	else /* Coding 3,6,9 goes here. */
	  {
	    packed=trajcoder_pack_array(dumper->coder,dumper->temp_intra+dumper->dmpatoms*3,&length,
					dumper->coding,dumper->coding_parameter,dumper->dmpatoms,dumper->speed);
	  }
      if (!packed)
	{
	  fprintf(stderr,"TRAJNG: Failed to pack frames.\n");
	  exit(EXIT_FAILURE);
	}
      bufferwritefix16(dumper,dumper->coding);
      bufferwritefix16(dumper,dumper->coding_parameter);
      bufferwritefix32(dumper,length);
      bufferwrite(dumper,packed,length,1);
      bufferwritefix32(dumper,compute_crc(packed,length));
      free(packed);
      bufferwritefix32(dumper,ndumps_write); /* Keep track of number of dumps in the previous block. */
      dumper->file_block_size+=2*2+4*2+length+4;

      /* Separate pack of velocities here? */
      if (dumper->is_file_w_vel)
	{
	  int length=ilength;
	  if ((dumper->vel_coding==2) || (dumper->vel_coding==6) || (dumper->vel_coding==8)) /* inter-frame */
	    packed=trajcoder_pack_array(dumper->coder,dumper->temp_symbols_vel_inter,&length,
					dumper->vel_coding,dumper->vel_coding_parameter,dumper->dmpatoms,dumper->speed);
	  else
	    packed=trajcoder_pack_array(dumper->coder,dumper->temp_symbols_vel+dumper->dmpatoms*3,&length,
					dumper->vel_coding,dumper->vel_coding_parameter,dumper->dmpatoms,dumper->speed);
	
	  if (!packed)
	    {
	      fprintf(stderr,"TRAJNG: Failed to pack velocity frames.\n");
	      exit(EXIT_FAILURE);
	    }

	  bufferwritefix16(dumper,dumper->vel_coding);
	  bufferwritefix16(dumper,dumper->vel_coding_parameter);
	  bufferwritefix32(dumper,length);
	  bufferwrite(dumper,packed,length,1);
	  bufferwritefix32(dumper,compute_crc(packed,length));
	  free(packed);
	  dumper->file_block_size+=2*2+4+length+4;
	}
    }
  dumper->temp_symbols_ptr=dumper->temp_symbols;
  dumper->intcoords_ptr=dumper->intcoords;
  dumper->temp_symbols_vel_ptr=dumper->temp_symbols_vel;
  dumper->temp_symbols_vel_inter_ptr=dumper->temp_symbols_vel_inter;
  dumper->temp_intra_ptr=dumper->temp_intra;
}

int DECLSPECDLLEXPORT TrajngWrite(void *handle,
		double *H,
		double *coords,double *vels,
		int stride,
		int framenumber,
		double time,
		double lambda)
{
    struct dumper *dumper=(struct dumper *)handle;
    double maxvalue=2147483647.;
    int i, j;
    /* Basic range checking. */
    for (i=0; i<dumper->dmpatoms*3; i++)
      if (fabs(coords[i]>maxvalue))
	{
	  fprintf(stderr,"TRJNG: Max value exceeded in coordinates: |%14g|>%10g\n",coords[i],maxvalue);
	  exit(EXIT_FAILURE);
	}
    if ((dumper->is_file_w_box) && (H))
      for (i=0; i<9; i++)
	if (fabs(H[i]>maxvalue))
	  {
	    fprintf(stderr,"TRAJNG: Max value exceeded in H-matrix: |%14g|>%10g\n",H[i],maxvalue);
	    exit(EXIT_FAILURE);
	  }
    if ((dumper->is_file_w_vel) && (vels))
      for (i=0; i<dumper->dmpatoms*3; i++)
	if (fabs(vels[i]>maxvalue))
	  {
	    fprintf(stderr,"TRAJNG: Max value exceeded in velocities: |%14g|>%10g\n",vels[i],maxvalue);
	    exit(EXIT_FAILURE);
	  }
    /* Store all values required.
       All writing is done by "flush_dumps" */    
    if (dumper->is_file_w_box)
      for (i=0; i<9; i++)
	dumper->save_H[(dumper->nframe%dumper->nchunky)*9+i]=H[i];
    dumper->save_framenumber[dumper->nframe%dumper->nchunky]=framenumber;
    dumper->save_time[dumper->nframe%dumper->nchunky]=time;
    dumper->save_lambda[dumper->nframe%dumper->nchunky]=lambda;
    if ((dumper->nframe%dumper->nchunky)==0)
      {
	dumper->intcoords_ptr=dumper->intcoords;
	dumper->temp_symbols_vel_ptr=dumper->temp_symbols_vel;	
      }
    /* Now round the coordinates */
    for (i=0; i<dumper->dmpatoms; i++)
      {
	int v[3];
	for (j=0; j<3; j++)
	  v[j]=((int)floor(coords[i*stride+j]/dumper->chosen_precision+0.5))-dumper->firstcoord[j];
	/* Store this to memory */
	for (j=0; j<3; j++)
	  *dumper->intcoords_ptr++=v[j];
      }
    /* Now round the velocities */
    if ((dumper->is_file_w_vel) && (vels))
      {
	for (i=0; i<dumper->dmpatoms; i++)
	  for (j=0; j<3; j++)
	    {
	      int ivel;
	      double divel;
	      divel=vels[i*stride+j]/dumper->chosen_velprecision;
	      ivel=(int)floor(divel+0.5); /* Round. */
	      *dumper->temp_symbols_vel_ptr++=ivel;
	    }
      }
    dumper->nframe++;
    if (((dumper->nframe)%dumper->nchunky)==0)
      flush_dumps(dumper,dumper->nchunky);
    return 0;
}

int DECLSPECDLLEXPORT TrajngWritef(void *handle,
		 float *H,
		 float *coords,float *vels,
		 int stride,
		 int framenumber,
		 float time,
		 float lambda)
{
  double dH[9];
  int i,j;
  int natoms=TrajngNatoms(handle);
  double *dcoords=warnmalloc(3*natoms*sizeof *dcoords);
  double *dvels=NULL;
  int rval;
  /* Convert internally to double precision */
  for (i=0; i<natoms; i++)
    for (j=0; j<3; j++)
      dcoords[i*3+j]=coords[i*stride+j];
  if (vels)
    {
      dvels=warnmalloc(3*natoms*sizeof *dvels);
      for (i=0; i<natoms; i++)
	for (j=0; j<3; j++)
	  dvels[i*3+j]=vels[i*stride+j];
    }
  if (H)
    for (i=0; i<9; i++)
      dH[i]=H[i];

  rval=TrajngWrite(handle,dH,dcoords,dvels,3,framenumber,time,lambda);

  free(dcoords);
  free(dvels);
  return rval;
}

/* This is a support routine for TrajngMPI which writes different frames on different ranks. */
void DECLSPECDLLEXPORT TrajngSetFrame(void *handle,int nframe)
{
  struct dumper *dumper=(struct dumper *)handle;
  
  dumper->nframe=nframe;
}

void DECLSPECDLLEXPORT TrajngFlush(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

    if (dumper->is_writing)
    {
#ifndef TRAJNG_FORCE_COMPATIBLE
	my_int64_t this_offset_pos;
#endif
	int number_of_dumps_left=dumper->nframe%dumper->nchunky;
	if (number_of_dumps_left)
	  flush_dumps(dumper,number_of_dumps_left);
	if (dumper->compatibility_mode)
	  write_to_index(dumper);
#ifndef TRAJNG_FORCE_COMPATIBLE
	if (!dumper->compatibility_mode)
	  {
	    /* Store number of frames... */
	    this_offset_pos=my_ftell(dumper->dmpfile);
	    my_fseek(dumper->dmpfile,dumper->old_offset_pos,SEEK_SET);
	    my_fseek(dumper->dmpfile,4,SEEK_CUR); /* Skip "DUMP" string. */
	    my_fseek(dumper->dmpfile,8,SEEK_CUR); /* Skip offset number (zero termination). */
	    my_fseek(dumper->dmpfile,8,SEEK_CUR); /* Skip future offset number (zero termination). */
	    my_fseek(dumper->dmpfile,4,SEEK_CUR); /* Skip frame number. */
	    if (number_of_dumps_left==0)
	      writefix32(dumper->dmpfile,dumper->nchunky);
	    else
	      writefix32(dumper->dmpfile,number_of_dumps_left);
	    /* Go back. */
	    my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
	  }
#endif
    }
    if ((dumper->is_writing) && (!dumper->write_buffer))
      fclose(dumper->dmpfile);
    if (((dumper->is_writing) && (dumper->compatibility_mode))
	|| ((!dumper->is_writing) && (dumper->external_index)))
      if ((dumper->is_writing) && (!dumper->write_buffer))
	fclose(dumper->indexfile);
}

void DECLSPECDLLEXPORT TrajngClose(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;
  TrajngFlush(handle);
  dumper_deinit(dumper);
}

void DECLSPECDLLEXPORT TrajngDeinit(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;
  dumper_deinit(dumper);
}

static struct dumper *open_read_repair(char *name, int repair, int compatibility_mode)
{
  struct dumper *dumper=dumper_init();
  char *modestring="rb";
  char buf[8];
  fix_t f;
  int i;
  if (repair)
    modestring="r+b";
  if (!(dumper->dmpfile=fopen(name,modestring)))
    { dumper_deinit(dumper); return NULL; }
  if (fread(buf,8,1,dumper->dmpfile)<1)
    { dumper_deinit(dumper); return NULL; }
  if (!strncmp(buf,"TRAJNG10",8))
    {
      dumper->version=10;
      dumper->header_size=get_header_size(dumper->version);
      fprintf(stderr,"TRAJNG: OLD VERSION CANNOT CURRENTLY BE READ.\n");
      dumper_deinit(dumper); return NULL;
    }
  else if (!strncmp(buf,"TRAJNG11",8))
    {
      dumper->version=11;
      dumper->header_size=get_header_size(dumper->version);
      fprintf(stderr,"TRAJNG: OLD VERSION CANNOT CURRENTLY BE READ.\n");
      dumper_deinit(dumper); return NULL;
    }
  else if (!strncmp(buf,"TRAJNG12",8))
    {
      dumper->version=12;
      dumper->header_size=get_header_size(dumper->version);
    }
  else if (!strncmp(buf,"TRAJNG13",8))
    {
      dumper->version=13;
      dumper->header_size=get_header_size(dumper->version);
    }
  else
    { dumper_deinit(dumper); return NULL; }
  if (readfix16(dumper->dmpfile,&f)<2)
    { dumper_deinit(dumper); return NULL; }
  dumper->is_file_w_vel=(int)f;
  if (readfix16(dumper->dmpfile,&f)<2)
    { dumper_deinit(dumper); return NULL; }
  dumper->is_file_w_box=(int)f;
  if (readfix16(dumper->dmpfile,&f)<2)
    { dumper_deinit(dumper); return NULL; }
  dumper->nchunky=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->dmpatoms=(int)f;
  if (dumper->version>=13)
    {
      if (readfix32(dumper->dmpfile,&f)<4)
	{ dumper_deinit(dumper); return NULL; }
      dumper->nchunkatoms=(int)f;
    }
  else
    dumper->nchunkatoms=dumper->dmpatoms;
  if (read_d32x2(dumper->dmpfile,&dumper->chosen_precision)<8)
    { dumper_deinit(dumper); return NULL; }
  if (read_d32x2(dumper->dmpfile,&dumper->chosen_velprecision)<8)
    { dumper_deinit(dumper); return NULL; }
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->compatibility_mode=(int)f;
  if (compatibility_mode>=0)
    dumper->compatibility_mode=compatibility_mode;
#ifdef TRAJNG_FORCE_COMPATIBLE
  dumper->compatibility_mode=1;
  dumper->external_index=0;
#else
  if ((!dumper->compatibility_mode) && (my_off_t_is_too_small()))
    {
      fprintf(stderr,"TRAJNG: WARNING! off_t is smaller than 64 bits. You should really recompile! For now I will read files in compatibility mode only!\n");
      dumper->compatibility_mode=1;
      dumper->external_index=0;
    }
  else if (dumper->compatibility_mode)
    {
      /* Check if we can open an external index file. */
      char *ifn=TrajngGetIndexFilename(name);
      dumper->indexfile=fopen(ifn,"rb");
      if (dumper->indexfile)
	dumper->external_index=1;
      else
	dumper->external_index=0;
      free(ifn);
    }
#endif
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->initial_coding=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->initial_coding_parameter=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->coding=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->coding_parameter=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->vel_coding=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->vel_coding_parameter=(int)f;
  if (dumper->version>10)
    {
      if (readfix32(dumper->dmpfile,&f)<4)
	{ dumper_deinit(dumper); return NULL; }
      dumper->initial_vel_coding=(int)f;
      if (readfix32(dumper->dmpfile,&f)<4)
	{ dumper_deinit(dumper); return NULL; }
      dumper->initial_vel_coding_parameter=(int)f;
    }
  else
    {
      /* Version 1.0 did not have initial velocity coding. All velocities were encoded the same way. */
      dumper->initial_vel_coding=dumper->vel_coding;
      dumper->initial_vel_coding_parameter=dumper->vel_coding_parameter;
    }
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->has_program_info=(int)f;
  if (readfix32(dumper->dmpfile,&f)<4)
    { dumper_deinit(dumper); return NULL; }
  dumper->has_atom_labels=(int)f;
  
  /* Verify that I understand the coding parameters. */
  if (verify_and_fix_all_coding(dumper))
    { dumper_deinit(dumper); return NULL; }
  
  if (dumper->has_program_info)
    {
      /* Read the program info: A zero-terminated text string (8 bit byte characters) with the length has_program_info */
      dumper->program_info=warnmalloc(dumper->has_program_info);
      if (fread(dumper->program_info,1,dumper->has_program_info,dumper->dmpfile)<(size_t)dumper->has_program_info)
	{ dumper_deinit(dumper); return NULL; }
      textconv_ascii_to_native(dumper->textconv_handle,dumper->program_info);
      /* The header size increases with this information! */
      dumper->header_size+=dumper->has_program_info;
    }
  if (dumper->has_atom_labels)
    {
      dumper->atom_labels=warnmalloc(dumper->dmpatoms*sizeof *dumper->atom_labels);
      dumper->atom_label_data=warnmalloc(dumper->has_atom_labels);
      if (fread(dumper->atom_label_data,1,dumper->has_atom_labels,dumper->dmpfile)<(size_t)dumper->has_atom_labels)
	{ dumper_deinit(dumper); return NULL; }
      dumper->atom_labels[0]=dumper->atom_label_data;
      for (i=1; i<dumper->dmpatoms; i++)
	{
	  dumper->atom_labels[i]=dumper->atom_labels[i-1]+strlen(dumper->atom_labels[i-1])+1;
	  textconv_ascii_to_native(dumper->textconv_handle,dumper->atom_labels[i]);
	}
      /* The header size increases with this information! */
      dumper->header_size+=dumper->has_atom_labels;
    }
  /* Read origin */
  for(i=0; i<3; i++)
    {
      if (readfix32(dumper->dmpfile,&f)<4)
	{ dumper_deinit(dumper); return NULL; }
      dumper->firstcoord[i]=(int)f;
    }
  dumper->oldcoords=warnmalloc(dumper->dmpatoms*3*sizeof *dumper->oldcoords);
  dumper->oldvels=warnmalloc(dumper->dmpatoms*3*sizeof *dumper->oldvels);
  dumper->intcoords=warnmalloc(dumper->dmpatoms*3*dumper->nchunky*sizeof *dumper->intcoords);
  dumper->temp_symbols=warnmalloc(dumper->dmpatoms*3*dumper->nchunky*sizeof *dumper->temp_symbols);
  dumper->temp_symbols_vel=warnmalloc(dumper->dmpatoms*3*dumper->nchunky*sizeof *dumper->temp_symbols_vel);
  dumper->temp_symbols_vel_inter=warnmalloc(dumper->dmpatoms*3*dumper->nchunky*sizeof *dumper->temp_symbols_vel_inter);
  dumper->temp_intra=warnmalloc(dumper->dmpatoms*3*dumper->nchunky*sizeof *dumper->temp_intra);
  dumper->temp_frame_parameters=warnmalloc(dumper->nchunky*9*sizeof *dumper->temp_frame_parameters);
  dumper->temp_frame_framenumber=warnmalloc(dumper->nchunky*sizeof *dumper->temp_frame_framenumber);
  dumper->temp_frame_time_lambda=warnmalloc(dumper->nchunky*2*sizeof *dumper->temp_frame_time_lambda);
#ifndef TRAJNG_FORCE_COMPATIBLE
  dumper->old_offset_pos=1; /* Used as a flag to know when to terminate. */
#endif
  return dumper;
}


void DECLSPECDLLEXPORT *TrajngOpenReadSpecify(char *name, int compatibility_mode)
{
  return (void*)open_read_repair(name,0,compatibility_mode);
}

void DECLSPECDLLEXPORT *TrajngOpenRead(char *name)
{
  return (void*)open_read_repair(name,0,-1); /* Use compatibility mode setting from the file. */
}

int DECLSPECDLLEXPORT TrajngHasVel(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

    return dumper->is_file_w_vel;
}

int DECLSPECDLLEXPORT TrajngHasBox(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

    return dumper->is_file_w_box;
}

void DECLSPECDLLEXPORT *TrajngOpenRepair(char *name)
{
  return (void*)open_read_repair(name,1,-1);
}

int DECLSPECDLLEXPORT TrajngNatoms(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;

  return dumper->dmpatoms;
}

/* Query a open trajectory file for program info. If none is available NULL is returned. */
char DECLSPECDLLEXPORT *TrajngGetProgramInfo(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;

  if (dumper->has_program_info)
    return dumper->program_info;
  else
    return NULL;
}

int DECLSPECDLLEXPORT TrajngGetCompatibilityMode(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;

  return dumper->compatibility_mode;
}

int DECLSPECDLLEXPORT TrajngGetExternalIndex(void *handle)
{
  struct dumper *dumper=(struct dumper *)handle;

  return dumper->external_index;
}

void DECLSPECDLLEXPORT TrajngInfo(void *handle,int *chunky, int *natoms, int *version,
		int *initial_coding, int *initial_coding_parameter,
		int *coding, int *coding_parameter,
		int *vel_coding, int *vel_coding_parameter,
		int *initial_vel_coding, int *initial_vel_coding_parameter,
		double *chosen_precision,
		double *chosen_velprecision)
{
    struct dumper *dumper=(struct dumper *)handle;

    *chunky=dumper->nchunky;
    *natoms=dumper->dmpatoms;
    *initial_coding=dumper->initial_coding;
    *initial_coding_parameter=dumper->initial_coding_parameter;
    *coding=dumper->coding;
    *coding_parameter=dumper->coding_parameter;
    *initial_vel_coding=dumper->initial_vel_coding;
    *initial_vel_coding_parameter=dumper->initial_vel_coding_parameter;
    *vel_coding=dumper->vel_coding;
    *vel_coding_parameter=dumper->vel_coding_parameter;
    *version=dumper->version;
    *chosen_precision=dumper->chosen_precision;
    *chosen_velprecision=dumper->chosen_velprecision;
}

/* This function only returns 1 for "friendly" termination (EOF). */
int DECLSPECDLLEXPORT TrajngReadTry(void *handle)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
    struct dumper *dumper=(struct dumper *)handle;

    if (!dumper->compatibility_mode)
      {
	if ((dumper->nframe%dumper->nchunky)==0)
	  {
	    if (dumper->old_offset_pos==0)
	      return 1; /* File is ended and I need to read a new chunk. */
	    /* One more chunk will be read. */
	  }
	else
	  {
	    /* We are in the middle of one dump,
	       so make sure there are enough frames here. */
	    if ((dumper->nframe%dumper->nchunky)>=dumper->chunk_number_of_dumps)
	      return 1;
	    /* There are frames left in memory. */
	  }
      }
#endif
    return 0;
}

static int TrajngReadGeneric(void *handle,double *H,
			     double *coords, double *vels,
			     int stride,
			     int *framenumber,
			     double *time,
			     double *lambda,
			     int nodecomp)
{
    struct dumper *dumper=(struct dumper *)handle;

    int k;
    char buf[4];
    int frame_check;
    fix_t tmp_fix;
#ifndef TRAJNG_FORCE_COMPATIBLE
    my_uint64_t offset64;
#endif
    int deliver;
#if 0
    fprintf(stderr,"TrajngRead called. nframe=%d\n",dumper->nframe);
#endif
    if ((dumper->nframe%dumper->nchunky)==0)
    {
	int i,j;
	unsigned char *packed;
	int more_data=0;
	int some_more_data=0;
	int length;
#ifndef TRAJNG_FORCE_COMPATIBLE
	if (dumper->old_offset_pos==0)
	{
	  if (!dumper->compatibility_mode)
	    {
	      fprintf(stderr,"TRAJNG: Refused read from terminated file.\n");
	      return 1;
	    }
	}
#endif
	/* Read it all. */
	dumper->chunk_number_of_dumps=dumper->nchunky; /* Default to full set, may be changed later. */
	for (i=0; i<dumper->chunk_number_of_dumps; i++)
	{
	    if (i==0)
	    {
	      if (fread(buf,4,1,dumper->dmpfile)<1)
		    return 1;
		if (strncmp(buf,"DUMP",4))
		{
		    fprintf(stderr,"TRAJNG: FATAL: Expected DUMP\n");
		    fprintf(stderr,"TRAJNG: Got <%c%c%c%c> (%d,%d,%d,%d)\n",buf[0],buf[1],buf[2],buf[3],buf[0],buf[1],buf[2],buf[3]);
		    return 4;
		}
#ifndef TRAJNG_FORCE_COMPATIBLE
		if (readuint64(dumper->dmpfile,&offset64)<8)
		    return 1;
		dumper->old_offset_pos=offset64;  /* 64-bit offset. Is zero for the last chunk. */
		if (readuint64(dumper->dmpfile,&offset64)<8) /* Future offset. */
		  return 1;
#else /* TRAJNG_FORCE_COMPATIBLE */
		if (readfix32(dumper->dmpfile,&tmp_fix)<4)
		    return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4)
		    return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4)
		    return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4)
		    return 1;		
#endif /* TRAJNG_FORCE_COMPATIBLE */
		if (readfix32(dumper->dmpfile,&tmp_fix)<4)
		    return 1;
		frame_check=(int)tmp_fix;
#if 0
		fprintf(stderr,"frame_check=%d dumper->nframe=%d. Should be the same.\n",frame_check,dumper->nframe);
#endif
		if (frame_check!=dumper->nframe)
		  {
		    fprintf(stderr,"TRAJNG: Frame out of sync error: %d!=%d\n",frame_check,dumper->nframe);
		    return 3;
		  }
		
 		if (readfix32(dumper->dmpfile,&tmp_fix)<4) /* Number of dumps stored in this chunk. */
		    return 1;
		/* This value should not be used. In compat. mode it
		 is zero. In normal mode continued reading is required
		 to pick up the last zero from the more_data flag. It
		 is still needed for the seek code reading the
		 chunks. */
#if 0
		if (!dumper->compatibility_mode)
		  dumper->chunk_number_of_dumps=(int)tmp_fix;
#endif
	    }
	    if (i>=1)
	      {
		/* We must determine whether more data appears. */
#if 0
		fprintf(stderr,"POS is now %lu\n",ftell(dumper->dmpfile));
#endif
		if (readfix16(dumper->dmpfile,&tmp_fix)<2) /* More data? */
		  return 1;
		more_data=(int)tmp_fix;
#if 0
		fprintf(stderr,"More data is %d\n",more_data);
#endif
		if (more_data)
		  some_more_data=1;
		else
		  dumper->chunk_number_of_dumps=i;
	      }
	    if ((i==0) || (more_data))
	      {
		if (dumper->is_file_w_box)
		  for (j=0; j<9; j++)
		    if (read_d32x2(dumper->dmpfile,dumper->temp_frame_parameters+i*9+j)<8) return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
		dumper->temp_frame_framenumber[i]=(int)tmp_fix;
		if (read_d32x2(dumper->dmpfile,dumper->temp_frame_time_lambda+i*2)<8) return 1;
		if (read_d32x2(dumper->dmpfile,dumper->temp_frame_time_lambda+i*2+1)<8) return 1;
	      }
	    if (i==0)
	    {
	      int length;
	      unsigned char *packed;
	      unsigned int crc,crc_check;
	      int j,k;
	      int intra_v[3];
	      if ((dumper->is_file_w_box) && (H))
		for (j=0; j<9; j++)
		  H[j]=dumper->temp_frame_parameters[j];
	      *framenumber=dumper->temp_frame_framenumber[i];
	      *time=dumper->temp_frame_time_lambda[i*2];
	      *lambda=dumper->temp_frame_time_lambda[i*2+1];
	      /* Read the packed data. */
	      if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
	      dumper->initial_coding=(int)tmp_fix;
	      if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
	      dumper->initial_coding_parameter=(int)tmp_fix;
	      if (verify_and_fix_all_coding(dumper)) return 1;
	      if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
	      length=(int)tmp_fix;
#if 0
	      fprintf(stderr,"Found initial coding %d and parameter %d and length %d\n",dumper->initial_coding,dumper->initial_coding_parameter,length);
#endif
	      packed=warnmalloc(length*sizeof *packed);
	      if (fread(packed,1,length,dumper->dmpfile)<(size_t)length) return 1;
	      crc_check=compute_crc(packed,length);
	      if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
	      crc=(unsigned int)tmp_fix;
	      if (crc!=crc_check)
		return 2;
	      if (!nodecomp)
		if (trajcoder_unpack_array(dumper->coder,packed,dumper->temp_symbols,dumper->dmpatoms*3,dumper->initial_coding,dumper->initial_coding_parameter,dumper->dmpatoms))
		  {
		    fprintf(stderr,"TRAJNG: Failed to unpack frames (initial positions).\n");
		    exit(EXIT_FAILURE);
		  }
	      free(packed);
	      if (dumper->is_file_w_vel)
	      {
		/* Velocities come in a separate block */
		/* Read the packed data. */
		if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
		dumper->initial_vel_coding=(int)tmp_fix;
		if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
		dumper->initial_vel_coding_parameter=(int)tmp_fix;
		if (verify_and_fix_all_coding(dumper)) return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
		length=(int)tmp_fix;
		packed=warnmalloc(length*sizeof *packed);
		if (fread(packed,1,length,dumper->dmpfile)<(size_t)length) return 1;
		crc_check=compute_crc(packed,length);
		if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
		crc=(unsigned int)tmp_fix;
		if (crc!=crc_check)
		  return 2;
		if (!nodecomp)
		  if (trajcoder_unpack_array(dumper->coder,packed,dumper->temp_symbols_vel,dumper->dmpatoms*3,dumper->initial_vel_coding,dumper->initial_vel_coding_parameter,dumper->dmpatoms))
		    {
		      fprintf(stderr,"TRAJNG: Failed to unpack frames (initial velocities).\n");
		      exit(EXIT_FAILURE);
		    }
		free(packed);
	      }
	      for (j=0; j<3; j++)
		intra_v[j]=0;
	      if (!nodecomp)
		for (j=0; j<dumper->dmpatoms; j++)
		  {
		    double v[3];
		    if ((dumper->initial_coding==5) || (dumper->initial_coding==7) || (dumper->initial_coding==10))
		      {
			for (k=0; k<3; k++)
			  {
			    intra_v[k]=dumper->temp_symbols[j*3+k];
			    v[k]=(double)(intra_v[k]+dumper->firstcoord[k])*dumper->chosen_precision;
			  }
		      }
		    else
		      {
			for (k=0; k<3; k++)
			  {
			    intra_v[k]+=dumper->temp_symbols[j*3+k];
			    v[k]=(double)(intra_v[k]+dumper->firstcoord[k])*dumper->chosen_precision;
			  }
		      }
		    /* Also update the oldcoords for future inter-frame compression */
		    for (k=0; k<3; k++)
		      dumper->oldcoords[j*3+k]=intra_v[k];
		    if (coords)
		      for (k=0; k<3; k++)
			coords[j*stride+k]=v[k];
		  }
	      if (dumper->is_file_w_vel)
		{
		  if ((!nodecomp) && (vels))
		    {
		      for (j=0; j<dumper->dmpatoms; j++)
			for (k=0; k<3; k++)
			  {
			    int ivel=dumper->temp_symbols_vel[j*3+k];
			    double vel=(double)(ivel*dumper->chosen_velprecision);
			    vels[j*stride+k]=vel;
			    /* Update oldvels for future inter-frame compression */
			    dumper->oldvels[j*3+k]=ivel;
			  }
		    }
		}
	    }
	}
	if (some_more_data)
	  {
	    unsigned int crc, crc_check;
	    /* Read the packed data. */
	    if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
	    dumper->coding=(int)tmp_fix;
	    if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
	    dumper->coding_parameter=(int)tmp_fix;
	    if (verify_and_fix_all_coding(dumper)) return 1;
	    if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
	    length=(int)tmp_fix;
#if 0
	    fprintf(stderr,"Found coding %d and parameter %d and length %d\n",dumper->coding,dumper->coding_parameter,length);
#endif
	    packed=warnmalloc(length*sizeof *packed);
	    if (fread(packed,1,length,dumper->dmpfile)<(size_t)length) return 1;
	    crc_check=compute_crc(packed,length);
	    if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
	    crc=(unsigned int)tmp_fix;
	    if (crc!=crc_check)
	      return 2;
	    if (readfix32(dumper->dmpfile,&tmp_fix)<4) /* Number of dumps stored in this chunk. */
	      return 1;
	    if (dumper->chunk_number_of_dumps!=(int)tmp_fix)
	      {
#if 0
		if (!dumper->compatibility_mode)
#endif
		  {
		    fprintf(stderr,"TRAJNG: Number of dumps out of sync: %d!=%d\n",dumper->chunk_number_of_dumps,(int)tmp_fix);
		    exit(EXIT_FAILURE);
		  }
	      }
	    dumper->chunk_number_of_dumps=(int)tmp_fix; /* Necessary for compatibility mode */
	    if (!nodecomp)
	      if (trajcoder_unpack_array(dumper->coder,packed,dumper->temp_symbols,(dumper->chunk_number_of_dumps-1)*dumper->dmpatoms*3,dumper->coding,dumper->coding_parameter,dumper->dmpatoms))
		{
		  fprintf(stderr,"TRAJNG: Failed to unpack frames. (positions)\n");
		  exit(EXIT_FAILURE);
		}
	    free(packed);
	    if (dumper->is_file_w_vel)
	      {
		/* Velocities come in a separate block */
		/* Read the packed data. */
		if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
		dumper->vel_coding=(int)tmp_fix;
		if (readfix16(dumper->dmpfile,&tmp_fix)<2) return 1;
		dumper->vel_coding_parameter=(int)tmp_fix;
		if (verify_and_fix_all_coding(dumper)) return 1;
		if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
		length=(int)tmp_fix;
		packed=warnmalloc(length*sizeof *packed);
		if (fread(packed,1,length,dumper->dmpfile)<(size_t)length) return 1;
		crc_check=compute_crc(packed,length);
		if (readfix32(dumper->dmpfile,&tmp_fix)<4) return 1;
		crc=(unsigned int)tmp_fix;
		if (crc!=crc_check)
		  return 2;
		if (!nodecomp)
		  if (trajcoder_unpack_array(dumper->coder,packed,dumper->temp_symbols_vel,(dumper->chunk_number_of_dumps-1)*dumper->dmpatoms*3,dumper->vel_coding,dumper->vel_coding_parameter,dumper->dmpatoms))
		    {
		      fprintf(stderr,"TRAJNG: Failed to unpack frames. (velocities)\n");
		      exit(EXIT_FAILURE);
		    }
		free(packed);
	      }
	  }
    }
    deliver=dumper->nframe%dumper->nchunky;
    if (deliver>=dumper->chunk_number_of_dumps)
    {
      if (!dumper->compatibility_mode)
	fprintf(stderr,"TRAJNG: Frame does not exist.\n");
      return 1;
    }
    if ((dumper->is_file_w_box) && (H))
      for (k=0; k<9; k++)
	H[k]=dumper->temp_frame_parameters[deliver*9+k];
    *framenumber=dumper->temp_frame_framenumber[deliver];
    *time=dumper->temp_frame_time_lambda[deliver*2];
    *lambda=dumper->temp_frame_time_lambda[deliver*2+1];
    if ((!nodecomp) && (deliver!=0))
    {
	/* We must update our coordinates. */
	int i,j;
	int *base;
	int *velbase;
	base=dumper->temp_symbols+(deliver-1)*dumper->dmpatoms*3;
	velbase=dumper->temp_symbols_vel+(deliver-1)*dumper->dmpatoms*3;
	/* Inter-dump ? */
	if ((dumper->coding==0) || (dumper->coding==1) || (dumper->coding==2) || (dumper->coding==4) || (dumper->coding==8))
	  {
	    for (i=0; i<dumper->dmpatoms; i++)
	      {
		int v[3];
#if 0
		fprintf(stderr,"%d: %d %d %d\n",i,base[i*3],base[i*3+1],base[i*3+2]);
#endif
		for (j=0; j<3; j++)
		  {
		    v[j]=dumper->oldcoords[i*3+j];
		    v[j]+=base[i*3+j];
		  }
		for (j=0; j<3; j++)
		  dumper->oldcoords[i*3+j]=v[j];
		if (coords)
		  for (j=0; j<3; j++)
		    coords[i*stride+j]=(double)(v[j]+dumper->firstcoord[j])*dumper->chosen_precision;
	      }
	  }
	else  /* Intra dump! */
	  {
	    int intra_v[3]={0,0,0};
	    for (i=0; i<dumper->dmpatoms; i++)
	      {
		if ((dumper->coding==5) || (dumper->coding==7) || (dumper->coding==10))
		  {
		    for (j=0; j<3; j++)
		      intra_v[j]=base[i*3+j];
		  }
		else
		  {
		    for (j=0; j<3; j++)
		      intra_v[j]+=base[i*3+j];
		  }

		if (coords)
		  for (j=0; j<3; j++)
		    {
		      coords[i*stride+j]=(double)(intra_v[j]+dumper->firstcoord[j])*dumper->chosen_precision;
		    }
#if 0
		if ((i>1516) && (i<1520))
		  fprintf(stderr,"COORD CHECK %d: %g %g %g   %d %d %d\n",i,coords[i*stride],coords[i*stride+1],coords[i*stride+2],intra_v[0],intra_v[1],intra_v[2]);
#endif
	      }	    
	  }
	if (dumper->is_file_w_vel)
	{
	    if (vels)
	    {
	      if ((dumper->vel_coding==2) || (dumper->vel_coding==6) || (dumper->vel_coding==8)) /* Inter-frame */
		{
		  for (i=0; i<dumper->dmpatoms; i++)
		    for (j=0; j<3; j++)
		      {
			int ivel=velbase[i*3+j]+dumper->oldvels[i*3+j];
			double vel=(double)(ivel*dumper->chosen_velprecision);
			vels[i*stride+j]=vel;
			/* Keep track of old velocity for inter-frame compression */
			dumper->oldvels[i*3+j]=ivel;
		      }
		}
	      else
		{
		  for (i=0; i<dumper->dmpatoms; i++)
		    for (j=0; j<3; j++)
		      {
			int ivel=velbase[i*3+j];
			double vel=(double)(ivel*dumper->chosen_velprecision);
			vels[i*stride+j]=vel;
		      }
		}
	    }
	}

    }
    dumper->nframe++;
    return 0;
}

/* return 0 : ok
   return 1 : general read error
   return 2 : crc failure
   return 3 : frame out of sync error
   return 4 : other fatal error
*/
int DECLSPECDLLEXPORT TrajngRead(void *handle,double *H,
	       double *coords, double *vels,
	       int stride,
	       int *framenumber,
	       double *time,
	       double *lambda)
{
  return TrajngReadGeneric(handle,H,coords,vels,stride,framenumber,time,lambda,0);
}

int DECLSPECDLLEXPORT TrajngReadNoDecompress(void *handle,double *H,
					     double *coords, double *vels,
					     int stride,
					     int *framenumber,
					     double *time,
					     double *lambda)
{
  return TrajngReadGeneric(handle,H,coords,vels,stride,framenumber,time,lambda,1);
}

int DECLSPECDLLEXPORT TrajngReadf(void *handle,float *H,
		float *coords, float *vels,
		int stride,
		int *framenumber,
		float *time,
		float *lambda)
{
  double dH[9];
  int i,j;
  int natoms=TrajngNatoms(handle);
  double *dcoords=warnmalloc(3*natoms*sizeof *dcoords);
  double *dvels=NULL;
  double dtime,dlambda;
  int rval;
  if (vels)
    dvels=warnmalloc(3*natoms*sizeof *dvels);
  
  rval=TrajngRead(handle,dH,dcoords,dvels,3,framenumber,&dtime,&dlambda);

  /* Convert internally from double precision */
  for (i=0; i<natoms; i++)
    for (j=0; j<3; j++)
      coords[i*stride+j]=(float)dcoords[i*3+j];
  if (vels)
    for (i=0; i<natoms; i++)
      for (j=0; j<3; j++)
	vels[i*stride+j]=(float)dvels[i*3+j];
  if (H)
    for (i=0; i<9; i++)
      H[i]=(float)dH[i];
  *time=(float)dtime;
  *lambda=(float)dlambda;

  free(dcoords);
  free(dvels);
  return rval;
}


static int extract_chunk_info(struct dumper *dumper)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      char buf[4];
      fix_t tmp_fix;
      /* Remember where we are. */
      my_int64_t this_offset_pos=my_ftell(dumper->dmpfile);
      my_uint64_t offset64;
      if (fread(buf,4,1,dumper->dmpfile)<1)
	return 1;
      if (strncmp(buf,"DUMP",4))
	{
	  fprintf(stderr,"TRAJNG: FATAL: Expected DUMP\n");
	  fprintf(stderr,"TRAJNG: Got <%c%c%c%c> (%d,%d,%d,%d)\n",buf[0],buf[1],buf[2],buf[3],buf[0],buf[1],buf[2],buf[3]);
	  return 4;
	}
      if (readuint64(dumper->dmpfile,&offset64)<8)
	return 1;
      dumper->chunk_info_pointer=offset64;
      dumper->chunk_info_size=dumper->chunk_info_pointer;
      if (readuint64(dumper->dmpfile,&offset64)<8)
	return 1;
      dumper->big_chunk_info_pointer=offset64;
      if (readfix32(dumper->dmpfile,&tmp_fix)<4)
	return 1;
      dumper->chunk_info_frame_number=(int)tmp_fix;
#if 0
      printf("At chunk %llx %llx %d\n",dumper->chunk_info_pointer,dumper->big_chunk_info_pointer,dumper->chunk_info_frame_number);
#endif
      if (readfix32(dumper->dmpfile,&tmp_fix)<4)
	return 1;
      dumper->chunk_info_ndumps=(int)tmp_fix;
      if (!dumper->chunk_info_pointer)
	{
	  my_fseek(dumper->dmpfile,0,SEEK_END);
	  dumper->chunk_info_size=my_ftell(dumper->dmpfile)-this_offset_pos;
	}
      /* Go back. */
      my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET);
    }
#endif
    return 0;
}

int DECLSPECDLLEXPORT TrajngGotoFirstChunk(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

#ifndef TRAJNG_FORCE_COMPATIBLE
    if (!dumper->compatibility_mode)
      {
#if 0
	fprintf(stderr,"first chunk\n");
#endif
	/* Header size. */
	my_fseek(dumper->dmpfile,dumper->header_size,SEEK_SET);
	dumper->old_offset_pos=1; /* Flag. This is zero for the last chunk. */
	dumper->nframe=0;
      }
#endif
    return extract_chunk_info(dumper);
}

int DECLSPECDLLEXPORT TrajngGotoNextChunk(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

#ifndef TRAJNG_FORCE_COMPATIBLE
    if (!dumper->compatibility_mode)
      {
#if 0
	fprintf(stderr,"next chunk\n");
#endif
	dumper->old_offset_pos=dumper->chunk_info_pointer;
	dumper->nframe+=dumper->chunk_info_ndumps;
	if (dumper->old_offset_pos==0)
	  {
	    fprintf(stderr,"TRAJNG: Cannot seek beyond end of file.\n");
	    return 1;
	  }
	my_fseek(dumper->dmpfile,dumper->chunk_info_pointer,SEEK_CUR);
      }
#endif
    return extract_chunk_info(dumper);
}

int DECLSPECDLLEXPORT TrajngGotoNextLargeChunk(void *handle)
{
    struct dumper *dumper=(struct dumper *)handle;

#ifndef TRAJNG_FORCE_COMPATIBLE
    if (!dumper->compatibility_mode)
      {
#if 0
	fprintf(stderr,"next big chunk\n");
#endif
	dumper->old_offset_pos=dumper->big_chunk_info_pointer;
	dumper->nframe+=dumper->chunk_info_ndumps*NUMCHUNKSBIG;
	if (dumper->old_offset_pos==0)
	  {
	    fprintf(stderr,"TRAJNG: Cannot seek beyond end of file (in next large chunk).\n");
	    return 1;
	  }
	my_fseek(dumper->dmpfile,dumper->big_chunk_info_pointer,SEEK_CUR);
      }
#endif
    return extract_chunk_info(dumper);
}

int DECLSPECDLLEXPORT TrajngGetLargeChunk(void *handle)
{
  return NUMCHUNKSBIG; /* Might depend on the actual dumpfile in a future version. */
}

void DECLSPECDLLEXPORT TrajngGetChunkInfo(void *handle,int *at_end,
			unsigned long *sizebig, unsigned long *sizesmall,
			int *ndumps, int *frame_number)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
    struct dumper *dumper=(struct dumper *)handle;

    if (!dumper->compatibility_mode)
      {
	*at_end=!dumper->chunk_info_pointer;
	*sizebig=(unsigned long)(((my_uint64_t)dumper->chunk_info_size)>>32);
	*sizesmall=(unsigned long)(((my_uint64_t)dumper->chunk_info_size)&0xFFFFFFFFUL);
	*ndumps=dumper->chunk_info_ndumps;
	*frame_number=dumper->chunk_info_frame_number;
      }
    else
      {
#endif
	*at_end=0;
	*sizebig=0;
	*sizesmall=0;
	*ndumps=0;
	*frame_number=0;
#ifndef TRAJNG_FORCE_COMPATIBLE
      }
#endif
}

int DECLSPECDLLEXPORT TrajngSeek(void *handle,int frame)
{
  struct dumper *dumper=(struct dumper *)handle;
    
  int remain;

#ifndef TRAJNG_FORCE_COMPATIBLE
  if (!dumper->compatibility_mode)
    {
      int nfch;
#if 0
      fprintf(stderr,"Seeking to: %d\n",frame);
#endif
      nfch=frame/dumper->nchunky;
      remain=frame%dumper->nchunky;

#if 0
      printf("nfch=%d, remain=%d\n",nfch,remain);
#endif

      if (TrajngGotoFirstChunk(handle))
	return 2;
      while (nfch>NUMCHUNKSBIG)
	{
	  if (TrajngGotoNextLargeChunk(handle))
	    return 3;
	  nfch-=NUMCHUNKSBIG;
	}

      if (nfch)
	{
	  while ((nfch--) && (!TrajngGotoNextChunk(handle)));
	  if (nfch!=-1)
	    {
#if 0
	      printf("%d frames left!\n",nfch+1);
	      fflush(stdout);
#endif
	      return 3;
	    }
	}
    }
  else if (dumper->external_index)
    {
      int nfch;
      fix_t fbs; /* file block size */
      my_uint64_t pos;
      nfch=frame/dumper->nchunky;
      remain=frame%dumper->nchunky;
      dumper->nframe=nfch*dumper->nchunky;
      /* Use the index file to move quickly to the correct frame. */
      rewind(dumper->indexfile);
      do
	{
	  if (readfix32(dumper->indexfile,&fbs)<4)
	    return 3;
	  if (readuint64(dumper->indexfile,&pos)<8)
	    return 3;
	} while (nfch--);
#if 0
      fprintf(stderr,"Goto index %lu\n",(unsigned long) pos);
#endif
      if (my_fseek(dumper->dmpfile,pos,SEEK_SET)<0)
	return 3;
    }
  else
    {
#endif
      /* Compatibility mode. So just read frames until we are at the correct position. */
      remain=frame;
#ifndef TRAJNG_FORCE_COMPATIBLE
    }
#endif
  /* Read remaining frames. */
  while (remain)
    {
      double H[9];
      int framenumber;
      double time,lambda;
      if (TrajngRead(handle,H,NULL,NULL,3,&framenumber,&time,&lambda))
	return 4;
      remain--;
    }
#if 0
  fprintf(stderr,"Stopped seeking to: %d\n",frame);
#endif
  dumper->nframe=frame;
#if 0
  fprintf(stderr,"dumper->nframe set to %d\n",dumper->nframe);
#endif
  return 0;
}

int DECLSPECDLLEXPORT TrajngTruncate(void *handle)
{
#ifndef TRAJNG_FORCE_COMPATIBLE
    struct dumper *dumper=(struct dumper *)handle;

    if (!dumper->compatibility_mode)
      {
	my_int64_t this_offset_pos=my_ftell(dumper->dmpfile);
	if (my_fseek(dumper->dmpfile,4,SEEK_CUR)) /* DUMP */
	  return 1;
	if (writeuint64(dumper->dmpfile,0)<8) /* Mark this dump as the terminating one. */
	  return 1;
	if (writeuint64(dumper->dmpfile,0)<8) /* Mark this dump as the terminating one. */
	  return 1;
	if (my_fseek(dumper->dmpfile,this_offset_pos,SEEK_SET)) /* Go back to beginning. */
	  return 1;
	if (my_fseek(dumper->dmpfile,dumper->chunk_info_pointer,SEEK_CUR)) /* Goes to beginning of next frame (the bad one) */
	  return 1;

	this_offset_pos=my_ftell(dumper->dmpfile);
	return my_ftruncate(dumper->dmpfile,this_offset_pos);
      }
    else
#endif
      return 1;
}

void DECLSPECDLLEXPORT TrajngGetUnpackInfo(void *handle,int *largest_pattern, int *largest_output, int *max_output)
{
    struct dumper *dumper=(struct dumper *)handle;

    trajcoder_get_unpack_info(dumper->coder,largest_pattern,largest_output,max_output);
}
