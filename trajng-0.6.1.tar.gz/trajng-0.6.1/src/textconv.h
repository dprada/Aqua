/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#ifndef TEXTCONV_H
#define TEXTCONV_H

/* Returns a handle to textconv routines. */
void *textconv_init();
void textconv_native_to_ascii(void *textconv_handle,char *s);
void textconv_ascii_to_native(void *textconv_handle,char *s);

#endif
