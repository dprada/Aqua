/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "warnmalloc.h"
#include "trajng.h"
#include "bwlzh.h"

static void compress(unsigned char *bytes, 
	      int n,
	      int valsize,
	      unsigned int *ints,
	      int verbose,
	      unsigned int *datatot)
{
  unsigned char v;
  unsigned char *compbuf;
  int i;
  int complen;
  if ((n%4) && (valsize==2))
    valsize--;
  if (n%2)
    valsize=0;
  v=valsize;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)n))&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)n)>>8)&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)n)>>16)&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)n)>>24)&0xFFU;
  fwrite(&v,1,1,stdout);
  (*datatot)+=5;
  if (verbose)
    {
      fprintf(stderr,"Block of size %d bytes is written as ",n);
      if (valsize==2)
	fprintf(stderr,"32 bits\n");
      else if (valsize==1)
	fprintf(stderr,"16 bits\n");
      else
	fprintf(stderr,"8 bits\n");
    }
  if (valsize==2)
    {
      for (i=0; i<n/4; i++)
	ints[i]=(((unsigned int)bytes[i*4])|
		 (((unsigned int)bytes[i*4+1])<<8)|
		 (((unsigned int)bytes[i*4+2])<<16)|
		 (((unsigned int)bytes[i*4+3])<<24));
      n/=4;
    }
  else if (valsize==1)
    {
      for (i=0; i<n/2; i++)
	ints[i]=(((unsigned int)bytes[i*2])|
		 (((unsigned int)bytes[i*2+1])<<8));
      n/=2;
    }
  else
    {
      for (i=0; i<n; i++)
	ints[i]=bytes[i];
    }
  compbuf=warnmalloc(bwlzh_get_buflen(n));
  if (verbose)
    bwlzh_compress_verbose(ints,n,compbuf,&complen);
  else
    bwlzh_compress(ints,n,compbuf,&complen);
  v=(((unsigned int)complen))&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)complen)>>8)&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)complen)>>16)&0xFFU;
  fwrite(&v,1,1,stdout);
  v=(((unsigned int)complen)>>24)&0xFFU;
  fwrite(&v,1,1,stdout);
  (*datatot)+=4;
  fwrite(compbuf,1,complen,stdout);
  free(compbuf);
  (*datatot)+=complen;
}

static int decompress(int verbose, unsigned int *dataread, unsigned int *datawrite)
{
  int rval=1;
  int valsize,i,n;
  int complen;
  unsigned char v;
  unsigned char *bytes=NULL;
  unsigned int *ints=NULL;
  unsigned char *compbuf=NULL;
  if (fread(&v,1,1,stdin)<1) { rval=0; goto free_and_exit; }
  valsize=v;
  n=0;
  for (i=0; i<4; i++)
    {
      if (fread(&v,1,1,stdin)<1) { rval=0; goto free_and_exit; }
      n=((unsigned int)n)|(((unsigned int)v)<<(8*i));
    }
  (*dataread)+=5;
  bytes=warnmalloc(n);
  ints=warnmalloc(n*sizeof *ints);
  complen=0;
  for (i=0; i<4; i++)
    {
      if (fread(&v,1,1,stdin)<1) { rval=0; goto free_and_exit; }
      complen=((unsigned int)complen)|(((unsigned int)v)<<(8*i));
    }
  (*dataread)+=4;
  compbuf=warnmalloc(complen);
  if (fread(compbuf,1,complen,stdin)<complen) { rval=0; goto free_and_exit; }
  (*dataread)+=complen;
  if (valsize==2)
    n/=4;
  else if (valsize==1)
    n/=2;
  if (verbose)
    bwlzh_decompress_verbose(compbuf,n,ints);
  else
    bwlzh_decompress(compbuf,n,ints);
  if (valsize==2)
    {
      for (i=0; i<n; i++)
	{
	  bytes[i*4]=(unsigned char)(ints[i]&0xFFU);
	  bytes[i*4+1]=(unsigned char)((ints[i]>>8)&0xFFU);
	  bytes[i*4+2]=(unsigned char)((ints[i]>>16)&0xFFU);
	  bytes[i*4+3]=(unsigned char)((ints[i]>>24)&0xFFU);
	}
      n*=4;
    }
  else if (valsize==1)
    {
      for (i=0; i<n; i++)
	{
	  bytes[i*2]=(unsigned char)(ints[i]&0xFFU);
	  bytes[i*2+1]=(unsigned char)((ints[i]>>8)&0xFFU);
	}
      n*=2;
    }
  else
    {
      for (i=0; i<n; i++)
	bytes[i]=ints[i];
    }
  fwrite(bytes,1,n,stdout);
  (*datawrite)+=n;
 free_and_exit:
  free(compbuf);
  free(ints);
  free(bytes);
  return rval;
}


int main(int argc, char **argv)
{
  int decomp=0;
  int verbose=0;
  int valsize=1;
  int blocksize=4000000;
  int n;
  unsigned char *bytes=NULL;
  unsigned int *ints=NULL;
  char *ident="BWLZH001";
  unsigned int dataread=0;
  unsigned int datawrite=0;
  if (argc>1)
    {
      int args;
      for (args=1; args<argc; args++)
	{
	  if (argv[args][0]=='-')
	    {
	      switch(argv[args][1])
		{
		case 'h':
		  fprintf(stderr,
			  "bwlzh\n"
			  "-h : help\n"
			  "-v : verbose\n"
			  "-d : decompress\n"
			  "-b : only byte compression\n"
			  "-l : 32 bit compression\n"
			  );
		  exit(0);
		  break;
		case 'b':
		  valsize=0;
		  break;
		case 'd':
		  decomp=1;
		  break;
		case 'l':
		  valsize=2;
		  break;
		case 'v':
		  verbose=1;
		  break;
		}
	    }
	}
    }
  if (decomp)
    {
      char buf[8];
      fread(buf,1,8,stdin);
      dataread+=8;
      if (strncmp(buf,ident,8))
	{
	  fprintf(stderr,"Input does not look like a bwlzh archive\n");
	  exit(1);
	}
      n=0;
      while(decompress(verbose,&dataread,&datawrite));
      if ((verbose) && (datawrite))
	{
	  fprintf(stderr,"Data read: %d bytes\n",dataread);
	  fprintf(stderr,"Data written: %d bytes\n",datawrite);
	  fprintf(stderr,"(De)compression ratio: %.3f %%\n",100.*dataread/datawrite);
	}
    }
  else
    {
      ints=warnmalloc(blocksize*sizeof*ints);
      bytes=warnmalloc(blocksize);
      n=0;
      fwrite(ident,1,8,stdout);
      datawrite+=8;
      while (fread(bytes+n,1,1,stdin))
	{
	  n++;
	  dataread++;
	  if (n==blocksize)
	    {
	      compress(bytes,n,valsize,ints,verbose,&datawrite);
	      n=0;
	    }
	}
      if (n)
	{
	  compress(bytes,n,valsize,ints,verbose,&datawrite);
	}
      free(bytes);
      free(ints);
      if ((verbose) && (dataread))
	{
	  fprintf(stderr,"Data read: %d bytes\n",dataread);
	  fprintf(stderr,"Data written: %d bytes\n",datawrite);
	  fprintf(stderr,"Compression ratio: %.3f %%\n",100.*datawrite/dataread);
	}
    }
  return 0;
}
