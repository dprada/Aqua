/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdio.h>
#include <stdlib.h>
#include "trajng.h"
#include "warnmalloc.h"

void DECLSPECDLLEXPORT *Trajng_warnmalloc_x(size_t size, char *file, int line)
{
  void *mem=malloc(size);
  if (!mem)
    {
      fprintf(stderr,"TRAJNG ERROR: Could not allocate memory of size %lu at %s:%d\n",(unsigned long) size,file,line);
      exit(EXIT_FAILURE);
    }
  return mem;
}

void DECLSPECDLLEXPORT *Trajng_warnrealloc_x(void *old, size_t size, char *file, int line)
{
  void *mem=realloc(old,size);
  if (!mem)
    {
      fprintf(stderr,"TRAJNG ERROR: Could not allocate memory of size %lu at %s:%d\n",(unsigned long) size,file,line);
      exit(EXIT_FAILURE);
    }
  return mem;
}
