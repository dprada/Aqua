/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/
#ifndef MYLARGEFILE_H
#define MYLARGEFILE_H

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include "my64bit.h"

#ifndef TRAJNG_FORCE_COMPATIBLE
#ifndef HAVE64BIT
#error A 64 BIT INTEGER TYPE IS REQUIRED TO BE ABLE TO HANDLE SEEKS. PLEASE SEE my64bit.h. IF YOU PREFER TO RUN WITHOUT SEEKS AND 64 BIT INTEGERS DEFINE TRAJNG_FORCE_COMPATIBLE
#endif /* HAVE64BIT */
#endif /* TRAJNG_FORCE_COMPATIBLE */

#ifndef TRAJNG_FORCE_COMPATIBLE
int my_ftruncate(FILE *file,my_int64_t length);

int my_fseek(FILE *file, my_int64_t offset, int whence);

my_int64_t my_ftell(FILE *file);

int my_off_t_is_too_small();
#endif /* TRAJNG_FORCE_COMPATIBLE */

#endif
