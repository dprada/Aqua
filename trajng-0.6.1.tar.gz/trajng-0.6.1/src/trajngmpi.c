/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <trajng.h>
#include "trajngmpi.h"

#ifdef USE_MPI

/* A structure containing data local to this "instance" of
   trajngmpi. A pointer to this structure is returned from the
   initialization routines, and the pointer must be passed to all
   other routines. */
struct trajngmpi
{
  MPI_Comm comm; /* Communicator for processes taking part of the
		    compression and storage of the trajectory */
  
  int rank;  /* Rank number of this process */
  int size;  /* Total number of processes */

  int global_frame_counter; /* Total number of frames ever written. */
  int nframes; /* Number of frames currently stored (on all ranks) */
  int maxframes; /* Maximum number of frames that can be stored on all
		    ranks */

  int chunky; /* Chunky value: Number of frames in one block. */

  int total_natoms; /* Total number of atoms in each frame */
  
  int local_frames; /* Number of frames stored on this rank */
  
  int glocal_id; /* Global id of first frame stored locally on this rank. */

  double *coords; /* Buffer of atom coordinates. */
  double *vels; /* Buffer of atom velocities. */
  double *H; /* Buffer of boxes. */

  int *framenumber; /* Storage of framenumber. */
  double *time, *lambda; /* Storage of time and lambda. */

  void *recvtmp; /* Temporary buffer for receiving coordinates and
		    velocities. The map is used to understand which
		    atom is which. */

  int *map; /* Map of all atoms. This is received from the other
	       ranks. */

  int *natoms; /* Receive buffer of number of atoms from the other
		  ranks. */

  int *recvcounts; /* Receive counts needed for gather. */
  int *displs; /* Displacements needed for gather. */

  unsigned char *buffer; /* Buffer for output. */

  void *trajng_handle; /* Handle for trajng */

  int local_io; /* If this is set to 0 all IO is done on rank==0, otherwise
		   IO is done with MPI-IO (not yet implemented). */
  FILE *dmpfile;
  FILE *indexfile;
#ifdef TRAJNG_USE_MPI_IO
  MPI_File mpidmpfile;
  unsigned int *buffer_lengths;
  unsigned int *offsets;
#ifdef TRAJNG_USE_MPI_IO_PANFS
  MPI_Info info;
#endif
#endif
  unsigned int index_hi, index_lo; /* Index positions. The index is
				      created on rank==0 only. */
  int first_write; /* Track if this is the first time we write to the file. */
};

static void deinit(struct trajngmpi *trajngmpi)
{
  /* Free communicator that was duplicated */
  MPI_Comm_free(&trajngmpi->comm);
#ifdef TRAJNG_USE_MPI_IO
  free(trajngmpi->buffer_lengths);
  free(trajngmpi->offsets);
#endif  
  free(trajngmpi->lambda);
  free(trajngmpi->time);
  free(trajngmpi->framenumber);
  free(trajngmpi->buffer);
  free(trajngmpi->recvcounts);
  free(trajngmpi->displs);
  free(trajngmpi->map);
  free(trajngmpi->recvtmp);
  free(trajngmpi->natoms);
  free(trajngmpi->H);
  free(trajngmpi->vels);
  free(trajngmpi->coords);
  free(trajngmpi);
}

/* Currently only produces compatibility mode files. */

void *TrajngMPIOpenWriteSpecify(char *name, int total_natoms, int chunky,
				double precision, int writebox, int writevel,
				double velprecision, 
				int initial_coding, int initial_coding_parameter,
				int coding, int coding_parameter,
				int initial_vel_coding, int initial_vel_coding_parameter,
				int vel_coding, int vel_coding_parameter,
				int speed, int compute_chunky, MPI_Comm comm)
{
  struct trajngmpi *trajngmpi=malloc(sizeof *trajngmpi);

  /* Duplicate communicator */
  MPI_Comm_dup(comm,&trajngmpi->comm);
  
  /* Size and rank of communicator */
  MPI_Comm_size(trajngmpi->comm,&trajngmpi->size);
  MPI_Comm_rank(trajngmpi->comm,&trajngmpi->rank);

  /* The number of atoms in each frame */
  trajngmpi->total_natoms=total_natoms;

  /* Let trajng do its chunky calcs. */
  if (compute_chunky)
    chunky=TrajngComputeChunky(chunky,total_natoms,writevel);

  /* The number of frames stored in each block (chunk) */
  trajngmpi->chunky=chunky;

  /* Total number of frames stored anywhere. */
  trajngmpi->global_frame_counter=0;

  /* When we start we have not stored any frames. */
  trajngmpi->nframes=0;

  /* Each rank will not necessarily have the same number of frames. */
  trajngmpi->local_frames=0;

  /* The maximum number of frames to store before we do the
     compression and write */
  trajngmpi->maxframes=chunky*trajngmpi->size;
  
  /* Indices */
  trajngmpi->index_lo=0U;
  trajngmpi->index_hi=0U;

  /* First write flag */
  trajngmpi->first_write=1;

  /* Allocate the required memory for storing chunky*total_natoms*3 on each
     node. */
  trajngmpi->coords=malloc(chunky*total_natoms*3*sizeof *trajngmpi->coords);
  /* ... and velocities ... */
  if (writevel)
    trajngmpi->vels=malloc(chunky*total_natoms*3*sizeof *trajngmpi->vels);
  else
    trajngmpi->vels=NULL;
  /* ... and the box ... */
  if (writebox)
    trajngmpi->H=malloc(chunky*9*sizeof *trajngmpi->H);
  else
    trajngmpi->H=NULL;
  
  /* Framenumber, time, and lambda. */
  trajngmpi->framenumber=malloc(chunky*sizeof *trajngmpi->framenumber);
  trajngmpi->time=malloc(chunky*sizeof *trajngmpi->time);
  trajngmpi->lambda=malloc(chunky*sizeof *trajngmpi->lambda);

  /* Number of atoms received from the other ranks */
  trajngmpi->natoms=malloc(trajngmpi->size*sizeof *trajngmpi->natoms);

  /* Receive counts for the gatherv. */
  trajngmpi->recvcounts=malloc(trajngmpi->size*sizeof *trajngmpi->recvcounts);

  /* Displacements where to store the data in the gatherv. */
  trajngmpi->displs=malloc(trajngmpi->size*sizeof *trajngmpi->displs);

  /* Temporary receive buffer. Should be able to take
     total_natoms*3*sizeof(double) (or float, but double is bigger
     than float) and total_natoms*3*chunky*8. chunky is always 1 so if
     sizeof(double)==8 it should be safe, but take the max of that. */
  trajngmpi->recvtmp=malloc(total_natoms*
			    ( (3*sizeof(double)>chunky*8*3) ? (3*sizeof(double)) : (3*chunky*8) ));
  
  /* Map of atoms. */
  trajngmpi->map=malloc(total_natoms*sizeof *trajngmpi->map);

  /* Buffer needed mainly for compressing data but also for other
     outputs */
  trajngmpi->buffer=malloc(total_natoms*chunky*3*8);

  /* Default is to gather all data onto rank==0 which does all the writes. */
  trajngmpi->local_io=0;

#ifdef TRAJNG_USE_MPI_IO
  /* If we have MPI-IO enabled io can be done in parallel. */
  trajngmpi->local_io=1;
#endif

  /* Open trajngbuffer for writing in compatiblity mode with auto selection of compression algorithms. */
  trajngmpi->trajng_handle=TrajngOpenWriteBuffer(trajngmpi->buffer,
						 total_natoms,chunky,precision,writebox,
						 writevel,velprecision,1,
						 initial_coding, initial_coding_parameter,
						 coding, coding_parameter,
						 initial_vel_coding, initial_vel_coding_parameter,
						 vel_coding,vel_coding_parameter,
						 speed,0);
  if (!trajngmpi->local_io)
    {
      /* If this is rank 0 we must also open a file for output... */
      if (trajngmpi->rank==0)
	{
	  char *indexfilename;
	  if (!(trajngmpi->dmpfile=fopen(name,"wb")))
	    {
	      deinit(trajngmpi);
	      return NULL;
	    }
	  /* ...and an index file, since this is a compatibility mode file. */
	  indexfilename=TrajngGetIndexFilename(name);
	  trajngmpi->indexfile=fopen(indexfilename,"wb");
	  free(indexfilename);
	  if (!trajngmpi->indexfile)
	    {
	      deinit(trajngmpi);
	      return NULL;
	    }
	}
    }
  else
    {
      char *indexfilename;
      trajngmpi->dmpfile=NULL;
      trajngmpi->indexfile=NULL;
#ifdef TRAJNG_USE_MPI_IO
#ifdef TRAJNG_USE_MPI_IO_PANFS
  MPI_Info_create(&trajngmpi->info);
  MPI_Info_set(trajngmpi->info,"panfs_concurrent_write", "1");
  MPI_Info_set(trajngmpi->info,"panfs_layout_type", "2"); /* RAID-0 */
  MPI_Info_set(trajngmpi->info,"panfs_layout_stripe_unit", "131072");
  MPI_Info_set(trajngmpi->info,"panfs_layout_total_num_comps", "16");
  MPI_Info_set(trajngmpi->info,"panfs_layout_visit_policy", "2");
#endif
      /* USE MPI-IO */
      MPI_File_open(trajngmpi->comm,name,MPI_MODE_CREATE|MPI_MODE_WRONLY,
#ifdef TRAJNG_USE_MPI_IO_PANFS
		    trajngmpi->info,
#else
		    MPI_INFO_NULL,
#endif
		    &trajngmpi->mpidmpfile);

      /* We still have to serialize around the index file (since this
	 is a compatibility mode file), so if this is rank 0 we must
	 open it. */
      if (trajngmpi->rank==0)
	{
	  indexfilename=TrajngGetIndexFilename(name);
	  trajngmpi->indexfile=fopen(indexfilename,"wb");
	  free(indexfilename);
	  if (!trajngmpi->indexfile)
	    {
	      deinit(trajngmpi);
	      return NULL;
	    }
	  trajngmpi->buffer_lengths=malloc(trajngmpi->size*sizeof *trajngmpi->offsets);
	  trajngmpi->offsets=malloc(2*trajngmpi->size*sizeof *trajngmpi->offsets);
	}
      else
	{
	  /* Only rank 0 needs to allocate the buffer lengths or offsets. */
	  trajngmpi->buffer_lengths=NULL;
	  trajngmpi->offsets=NULL;
	}
#endif
    }

  /* The buffers on all ranks but the first should now be emptied. 
     The file header should only be written from the very first rank. */
  if (trajngmpi->rank!=0)
    TrajngResetBuffer(trajngmpi->trajng_handle);

  return (void*) trajngmpi;
}

void *TrajngMPIOpenWrite(char *name, int total_natoms, int chunky,
			 double precision, int writebox, int writevel,
			 double velprecision, int speed,MPI_Comm comm)
{
  return TrajngMPIOpenWriteSpecify(name,total_natoms,chunky,precision,writebox,
				   writevel,velprecision,-1,-1,-1,-1,-1,-1,-1,-1,
				   speed,1,comm);
}

/* This only have to be called from rank==0, if called at all, but
   does no harm if called elsewhere */
int TrajngMPISetProgramInfo(void *handle,
			    char *program_info)
{
  struct trajngmpi *trajngmpi=(struct trajngmpi *)handle;

  if (trajngmpi->rank==0)
    return TrajngSetProgramInfo(trajngmpi->trajng_handle,program_info);
  else
    return 0;
}

/* This only have to be called from rank==0, if called at all, but
   does no harm if called elsewhere */
int TrajngMPISetAtomLabels(void *handle,
			   char **atom_labels)
{
  struct trajngmpi *trajngmpi=(struct trajngmpi *)handle;

  if (trajngmpi->rank==0)
    return TrajngSetAtomLabels(trajngmpi->trajng_handle,atom_labels);
  else
    return 0;
}

/* Main routine that does the work. If close_buffer is 0 all buffers
   are kept open. If it is set to 1 buffers are closed as well. */
static int compress_and_flush(struct trajngmpi *trajngmpi, int close_buffer)
{
  int rval=0;
  int i;
#if 0
  fprintf(stderr,"compress_and_flush called with close_buffer=%d local_frames=%d\n",close_buffer,trajngmpi->local_frames);
#endif
  if (trajngmpi->local_frames)
    {
      /* This set of local frames start from the global id stored in glocal_id */
      TrajngSetFrame(trajngmpi->trajng_handle,trajngmpi->glocal_id);
      for (i=0; i<trajngmpi->local_frames; i++)
	{
	  double *H=trajngmpi->H;
	  double *vels=trajngmpi->vels;
	  if (H)
	    H+=9*i;
	  if (vels)
	    vels += trajngmpi->total_natoms*3*i;
	  if (TrajngWrite(trajngmpi->trajng_handle,
			  H,
			  trajngmpi->coords + trajngmpi->total_natoms*3*i,
			  vels,
			  3,
			  trajngmpi->framenumber[i],
			  trajngmpi->time[i],
			  trajngmpi->lambda[i]))
	    rval=1;
	}
    }
  
  /* If we should close the buffers we do it now after all data has
     been written to the buffers and before the buffer contents should
     be transferred to rank 0 or written to disk. */
  if (close_buffer)
    TrajngFlush(trajngmpi->trajng_handle);

  if (!trajngmpi->local_io)
    {
      unsigned int buffer_length=(unsigned int)TrajngGetBufferLength(trajngmpi->trajng_handle);
      int other_ranks;
      MPI_Status status;
#if 0
      fprintf(stderr,"buffer len is %u\n",buffer_length);
#endif
      /* If this is rank 0 we must write the content to the files. */
      if (trajngmpi->rank==0)
	{
	  /* Write the index. */
	  /* If this is the first frame we should add the header size to the index. */
	  if (trajngmpi->first_write)
	    {
	      unsigned int header_size=(unsigned int)TrajngGetHeaderSize(trajngmpi->trajng_handle);
#if 0
	      printf("header size is %u\n",header_size);
#endif	      
	      TrajngIndexAdd(header_size,
			     &trajngmpi->index_lo,&trajngmpi->index_hi);
	      /* The header size should be subtracted from the very first buffer length. */
	      buffer_length-=header_size;
	      trajngmpi->first_write=0;
	    }
	  /* Write file locations to index file. */
	  TrajngWrite32(trajngmpi->indexfile,buffer_length);
	  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_lo);
	  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_hi);
#if 0
	  printf("lo is %x hi is %x len is %x.\n",trajngmpi->index_lo, trajngmpi->index_hi,(unsigned int)TrajngGetBufferLength(trajngmpi->trajng_handle));
#endif	  
	  /* Add buffer size to index */
	  TrajngIndexAdd(buffer_length,
			 &trajngmpi->index_lo,&trajngmpi->index_hi);
	  /* Write the current contents of the buffer (only on rank 0!). */
	  if (fwrite(trajngmpi->buffer,1,TrajngGetBufferLength(trajngmpi->trajng_handle),trajngmpi->dmpfile)<
	      TrajngGetBufferLength(trajngmpi->trajng_handle))
	    rval=1;
	  /* Now the compressed data from all the other ranks must be
	     received. Some of the ranks may have no data or not all
	     frames. */
	  for (other_ranks=1; other_ranks<trajngmpi->size; other_ranks++)
	    {
	      /* The number of frames stored on that other rank. */
	      int other_frames=trajngmpi->nframes-other_ranks*trajngmpi->chunky;
	      if (other_frames>0) /* There is data on that other rank */
		{
		  MPI_Status status;
		  int datalen;
		  MPI_Recv(trajngmpi->recvtmp,trajngmpi->total_natoms*3*8*trajngmpi->chunky,MPI_BYTE,other_ranks,
			   1,trajngmpi->comm,&status);
		  MPI_Get_count(&status,MPI_BYTE,&datalen);
#if 0
		  printf("Received %c%c%c%c from %d\n",
			 *((char*)trajngmpi->recvtmp),
			 *((char*)trajngmpi->recvtmp+1),
			 *((char*)trajngmpi->recvtmp+2),
			 *((char*)trajngmpi->recvtmp+3),
			 other_ranks);
#endif		  
		  /* Write file locations to index file. */
		  TrajngWrite32(trajngmpi->indexfile,(unsigned int)datalen);
		  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_lo);
		  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_hi);
#if 0
		  printf("lo is %x hi is %x len is %x.\n",trajngmpi->index_lo, trajngmpi->index_hi,(unsigned int)datalen);
#endif	  
		  /* Add buffer size to index */
		  TrajngIndexAdd((unsigned int)datalen,
				 &trajngmpi->index_lo,&trajngmpi->index_hi);
		  /* Write the data to the file. */
		  if (fwrite(trajngmpi->recvtmp,1,datalen,trajngmpi->dmpfile)<datalen)
		    rval=1;
		}
	    }
	}      
      else
	{
	  /* We (other ranks) should send our local data to rank 0. If we have any. */
	  if (trajngmpi->local_frames)
	    {
	      MPI_Send(trajngmpi->buffer,buffer_length,MPI_BYTE,0,1,trajngmpi->comm);
	    }
	}
      if (trajngmpi->rank==0)
	{
	  /* Ensure the data is written out. */
	  fflush(trajngmpi->dmpfile);
	}
    }
  else
    {
#ifdef TRAJNG_USE_MPI_IO
      /* How much data do I want to write? */
      unsigned int buffer_length;
      unsigned int offset[2];
      MPI_Offset mpioffset;
      MPI_Status status;
      int firstrankblock=0; /* If this is the very first block of data to write the file, a special
			       offset at zero must be given. */
      if (trajngmpi->local_frames)
	{
	  buffer_length=(unsigned int)TrajngGetBufferLength(trajngmpi->trajng_handle);
	  if (trajngmpi->rank==0)
	    {
	      /* If this is the first frame we should add the header size to the index. */
	      if (trajngmpi->first_write)
		{
		  unsigned int header_size=(unsigned int)TrajngGetHeaderSize(trajngmpi->trajng_handle);
#if 0
		  printf("header size is %u\n",header_size);
#endif	      
		  TrajngIndexAdd(header_size,
				 &trajngmpi->index_lo,&trajngmpi->index_hi);
		  /* The header size should be subtracted from the very first buffer length. */
		  buffer_length-=header_size;
		  trajngmpi->first_write=0;
		  firstrankblock=1;
		}
	    }
	}
      else
	buffer_length=0U;

      /* We must figure out the proper offset to write to. For rank
	 rank this depends on every rank with smaller rank
	 number. Ouch. Rank 0 keeps track of the current global
	 offsets. It has to since it must write the index file. So we
	 first gather all the buffer lengths onto rank 0 which sums
	 them up and scatters the resulting offsets. The input sizes
	 are 32 bit but the resulting offsets are 64 bits. */
      
      MPI_Gather(&buffer_length,1,MPI_INT,trajngmpi->buffer_lengths,1,MPI_INT,0,trajngmpi->comm);
      
      if (trajngmpi->rank==0)
	{
	  for (i=0; i<trajngmpi->size; i++)
	    {
	      /* Only write if there is actual data at the position in the file. */
	      if (trajngmpi->buffer_lengths[i])
		{
		  /* Write file locations to index file. */
		  TrajngWrite32(trajngmpi->indexfile,(unsigned int)trajngmpi->buffer_lengths[i]);
		  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_lo);
		  TrajngWrite32(trajngmpi->indexfile,trajngmpi->index_hi);
		  trajngmpi->offsets[i*2]=trajngmpi->index_lo;
		  trajngmpi->offsets[i*2+1]=trajngmpi->index_hi;
		  /* Add buffer size to index */
		  TrajngIndexAdd(trajngmpi->buffer_lengths[i],
				 &trajngmpi->index_lo,&trajngmpi->index_hi);
		}
	    }
	}
      
      /* Send the proper offsets to each cpu. */
      MPI_Scatter(trajngmpi->offsets,2,MPI_INT,offset,2,MPI_INT,0,trajngmpi->comm);
      
      /* Synthesize a MPI_Offset from the two unsigned ints (which are
	 at least 32 bit). We do not know what the type of MPI_Offset
	 is (unsigned or not) and shifts are in general not safe on
	 signed types. Also, it *could* be so that large file support
	 is not working, although we are using MPI-IO, so we want to
	 degrade nicely for files <2GB. Use implicit type conversion
	 rules to deal with this mess. */
      mpioffset=(MPI_Offset)offset[0]+( (((MPI_Offset)offset[1])*65536)*65536 );

      if (firstrankblock)
	{
	  /* Fix up special case for the very first block on the first
	   rank: It should be written at the very beginning of the
	   file. The header is written first. */
	  mpioffset=(MPI_Offset)0;
	}

#if 0
      fprintf(stderr,"Buffer that starts at %x:%x starts %c%c%c%c for rank %d\n",
	      offset[1],offset[0],
	      *((char*)trajngmpi->buffer),
	      *((char*)trajngmpi->buffer+1),
	      *((char*)trajngmpi->buffer+2),
	      *((char*)trajngmpi->buffer+3),
	      trajngmpi->rank);
      fflush(stderr);
#endif		  
      /* Do the parallel write. */
      if (MPI_File_write_at_all(trajngmpi->mpidmpfile,mpioffset,trajngmpi->buffer,
				TrajngGetBufferLength(trajngmpi->trajng_handle),
				MPI_BYTE, &status))
	rval=1;

#endif
    }
  /* The buffers should now be emptied. (on all ranks!) */
  TrajngResetBuffer(trajngmpi->trajng_handle);
  if (trajngmpi->rank==0)
    {
      /* Ensure the index file data is written out. */
      fflush(trajngmpi->indexfile);
    }

  trajngmpi->local_frames=0;
  trajngmpi->nframes=0;

  if (close_buffer)
    TrajngDeinit(trajngmpi->trajng_handle);
  
  return rval;
}


/* NOTE: The number of local atoms should be sent in the natoms
   argument and a map array of length natoms should contain the global
   number of each atom. */

/* Two versions of it, to make sure float is handled reasonable
   efficiently for communication. */
#define TRAJNGMPIWRITE TrajngMPIWrite
#define REAL double
#define MY_COMM_TYPE MPI_DOUBLE
#include "trajngmpiwrite.c"
#undef MY_COMM_TYPE
#undef REAL
#undef TRAJNGMPIWRITE

#define TRAJNGMPIWRITE TrajngMPIWritef
#define REAL float
#define MY_COMM_TYPE MPI_FLOAT
#include "trajngmpiwrite.c"
#undef MY_COMM_TYPE
#undef REAL
#undef TRAJNGMPIWRITE

void TrajngMPIClose(void *handle)
{
  struct trajngmpi *trajngmpi=(struct trajngmpi *)handle;

  /* Compress, flush, and close. */
  compress_and_flush(trajngmpi,1); 

  /* Close file(s)? */
  if (!trajngmpi->local_io)
    {
      /* If this is rank 0 we must also close the output files. */
      if (trajngmpi->rank==0)
	{
	  fclose(trajngmpi->indexfile);
	  fclose(trajngmpi->dmpfile);
	}
    }  
  else
    {
#ifdef TRAJNG_USE_MPI_IO
      MPI_File_close(&trajngmpi->mpidmpfile);
#ifdef TRAJNG_USE_MPI_IO_PANFS
      MPI_Info_free(&trajngmpi->info);
#endif
      /* If this is rank 0 we must also close the index file. */
      if (trajngmpi->rank==0)
	fclose(trajngmpi->indexfile);
#endif
    }
  deinit(trajngmpi);
}

void TrajngMPIInfo(void *handle,
		   int *chunky, int *natoms, int *version,
		   int *initial_coding, int *initial_coding_parameter,
		   int *coding, int *coding_parameter,
		   int *vel_coding, int *vel_coding_parameter,
		   int *initial_vel_coding, int *initial_vel_coding_parameter,
		   double *chosen_precision,
		   double *chosen_velprecision)
{
  struct trajngmpi *trajngmpi=(struct trajngmpi *)handle;
  
  TrajngInfo(trajngmpi->trajng_handle,
	     chunky,natoms,version,initial_coding, initial_coding_parameter,
	     coding, coding_parameter,
	     vel_coding, vel_coding_parameter, initial_vel_coding, initial_vel_coding_parameter,
	     chosen_precision, chosen_velprecision);
}


#endif /* USE_MPI */
