/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#include <stdio.h>
#include <stdlib.h>
#include "trajng.h"

int main()
{
  int i,j;
  double H[9];

  /* Open the dump file */
  void *dump=TrajngOpenRead("test.tng");

  /* Query number of atoms in each dump in the file */
  int natoms=TrajngNatoms(dump);

  /* Allocate enough memory for the coordinates. */
  double *coords=malloc(3*natoms*sizeof *coords);
  
  double time, lambda;
  
  int framenumber;

  /* Go to frame 51 (starting from 0) */
  TrajngSeek(dump,51);

  /* Read 100 frames. */
  for (i=0; i<100; i++)
    {
      TrajngRead(dump,H,coords,NULL,3,&framenumber,&time,&lambda); /* Read the coordinates and box.
								      No velocities so set to NULL. */
      printf("Frame %d. H:",i);
      for (j=0; j<9; j++)
	printf(" %g",H[j]);
      printf(" fn: %d time: %g lambda: %g\n",framenumber,time,lambda);
      for (j=0; j<natoms; j++)
	printf("%g %g %g\n",coords[j*3],coords[j*3+1],coords[j*3+2]);
    }
  TrajngClose(dump);

  return 0;
}
