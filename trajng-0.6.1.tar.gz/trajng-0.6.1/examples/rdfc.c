/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* This program computes the RDF from the MD simulation of atoms
   using Lennard-Jones potentials. This program demonstrates reading
   of trajectories generated using the trajng library.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "trajng.h"

#define NP 5
#define NATS (NP*NP*NP)

int main()
{
  int i, j, iframe;
  int nbins=100;
  int nframes=10000;
  double pi=3.14159265354;
  double boxl=5.5; /* Boxlen. */
  double rmax=boxl/2.; /* Max half boxlen due to minimum image */
  void *trajfile;
  FILE *gofrfile;
  /* array to hold one frame of positions */
  double *pos=malloc(3*NATS*sizeof *pos);
  /* array to hold the histograms */
  int *ihist=malloc(nbins*sizeof *ihist);
  
  double dr,rho; /* For computing RDF. */
  
  /* clear histogram */
  for (i=0; i<nbins; i++)
    ihist[i]=0;
      
  /* open trajectory file for reading */
  trajfile=TrajngOpenRead("argonc.tng");
  if (!trajfile)
    {
      fprintf(stderr,"Cannot open trajectory file. Please run argonc first!\n");
      return 1;
    }

  /* loop over frames */
  for (iframe=0; iframe<nframes; iframe++)
    {        
      int ifn;
      double time, lambda;
      if ((iframe%100)==0)
	printf("Frame %d of %d\n",iframe,nframes);
      /* read this frame (without box or velocities, only coordinates) */
      TrajngRead(trajfile,NULL,pos,NULL,3,&ifn,&time,&lambda);

      
      /* compute histogram */
      for (i=0; i<NATS-1; i++)
	for (j=i+1; j<NATS; j++)
	  {
            double rx=pos[i*3]-pos[j*3];
            double ry=pos[i*3+1]-pos[j*3+1];
            double rz=pos[i*3+2]-pos[j*3+2];
	    double dist;
	    int idist;
	    
	    /* This is called "The minimum image convention" */
            if (rx>boxl/2.) rx-=boxl;
            else if (rx<-boxl/2.) rx+=boxl;
            if (ry>boxl/2.) ry-=boxl;
            else if (ry<-boxl/2.) ry+=boxl;
            if (rz>boxl/2.) rz-=boxl;
            else if (rz<-boxl/2.) rz+=boxl;
	
	    /* Compute distance */
            dist=sqrt(rx*rx+ry*ry+rz*rz);
            
	    /* Put into histogram */
            
            idist=(int)(nbins*dist/rmax);
            if (idist<nbins)
	      ihist[idist]++;
          }
    }
      
  /* close trajectory file */
  TrajngClose(trajfile);

  /* open output file for g(r) */
  gofrfile=fopen("gofr.out","w");
      
  /* Compute g(r) from histogram */
  dr=rmax/nbins;
  rho=NATS/(boxl*boxl*boxl);
  for (i=0; i<nbins; i++)
    {
      double r=(i+0.5)*rmax/nbins;
      double dV=4*pi*r*r*dr;
      double g=ihist[i]/(dV*rho*NATS*nframes);
      fprintf(gofrfile,"%g %g\n",r,g);
    }

  /* close file for g(r) */
  fclose(gofrfile);

  /* we are finished. over and out. */
  return 0;
}
