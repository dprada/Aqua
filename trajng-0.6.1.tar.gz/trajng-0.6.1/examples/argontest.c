/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* This program runs a MD simulation of atoms using Lennard-Jones
   potentials and demonstrates parallel dumping using the trajngmpi
   library.

   This code is not using domain decomposition, it is using
   force-decomposition, but in the writing of the trajectory code it
   pretends to be domain decomposition.
   
   This test is coded for size==8 (2x2x2) only.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>
#include "trajngmpi.h"

#define NP 10
#define NATS (NP*NP*NP)

int main(int argc, char **argv)
{

  double boxlen=1.1*NP;
  double deske=100.;
  double cutoff=3.5; /* Cut-off in sigma */
  double *positions=malloc(NATS*3*sizeof *positions);
  double *velocities=malloc(NATS*3*sizeof *velocities);
  double *accelerations=malloc((NATS*3+1)*sizeof *accelerations);
  double *localaccelerations=malloc((NATS*3+1)*sizeof *localaccelerations);
  /* Local positions for the fake domain decomposition routines. */
  double *localpositions=malloc(NATS*3*sizeof *localpositions); 
  /* Local velocities for the fake domain decomposition routines. */
  double *localvelocities=malloc(NATS*3*sizeof *localvelocities); 
  /* Map of global atom numbers for the fake domain decomposition routines. */
  int *map=malloc(NATS*3*sizeof *map);
  double H[9];
  double potential_energy;
  double kinetic_energy;
  double dt=1e-3;
  double cutoff2=cutoff*cutoff;
  int i,j,k,ts,maxts=11000;
  int its=10;
  int scalestep=1000;
  void *trajfile;
  int rank, size;
  for (i=0; i<9; i++)
    H[i]=0.;
  H[0]=boxlen;
  H[4]=boxlen;
  H[8]=boxlen;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  MPI_Comm_size(MPI_COMM_WORLD,&size);
  if (size!=8)
    {
      fprintf(stderr,"This test has been coded for size==8 only.\n");
      MPI_Finalize();
      exit(EXIT_FAILURE);
    }

  for (i=0; i<NP; i++)
    for (j=0; j<NP; j++)
      for (k=0; k<NP; k++)
      {
	int idx=i*NP*NP+j*NP+k;
	positions[idx*3]=boxlen*(double)i/NP;
	positions[idx*3+1]=boxlen*(double)j/NP;
	positions[idx*3+2]=boxlen*(double)k/NP;
	velocities[idx*3]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	velocities[idx*3+1]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	velocities[idx*3+2]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	accelerations[idx*3]=0.;
	accelerations[idx*3+1]=0.;
	accelerations[idx*3+2]=0.;
	localaccelerations[idx*3]=0.;
	localaccelerations[idx*3+1]=0.;
	localaccelerations[idx*3+2]=0.;
      }

  /* Open trajectory file for writing. We write coordinates, velocities, and the box. */
  trajfile=TrajngMPIOpenWrite("argonpar.tng",NATS,100,0.01,1,1,0.1,0,MPI_COMM_WORLD);

  /* Write program specific info (not required). */
  TrajngMPISetProgramInfo(trajfile,"TrajngMPI fake domain decomposition C argon simulation");

  for (ts=0; ts<maxts; ts++)
    {
      double dt2half=dt*dt*0.5;
      double dthalf=dt*0.5;
      double iboxlen=1./boxlen;
      /* Verlet step 1 */
      for (i=0; i<NATS*3; i++)
	{
	  positions[i]+=velocities[i]*dt+accelerations[i]*dt2half;
	  velocities[i]+=accelerations[i]*dthalf;
	}
      /* Move particles into central box. */
      for (i=0; i<NATS*3; i++)
	if (positions[i]>boxlen) 
	  positions[i]-=boxlen;
	else if (positions[i]<0.)
	  positions[i]+=boxlen;

      /* Compute forces */
      potential_energy=0.;
      for (i=0; i<NATS*3; i++)
	localaccelerations[i]=0.;
      
      for (i=rank; i<NATS; i+=size)
	for (j=i+1; j<NATS; j++)
	  {
	    double d2;
	    double dxf=positions[i*3]-positions[j*3];
	    double dyf=positions[i*3+1]-positions[j*3+1];
	    double dzf=positions[i*3+2]-positions[j*3+2];
	    dxf-=boxlen*floor(dxf*iboxlen+0.5);
	    dyf-=boxlen*floor(dyf*iboxlen+0.5);
	    dzf-=boxlen*floor(dzf*iboxlen+0.5);
	    d2=dxf*dxf+dyf*dyf+dzf*dzf;
	    if (d2<cutoff2)
	      {
		double di2=1./d2;
		double di4=di2*di2;
		double di6=di4*di2;
		double di12=di6*di6;
		double f=24.*di2*(2.*di12-di6);
		potential_energy+=4.*(di12-di6);
		localaccelerations[i*3]+=f*dxf;
		localaccelerations[i*3+1]+=f*dyf;
		localaccelerations[i*3+2]+=f*dzf;
		localaccelerations[j*3]-=f*dxf;
		localaccelerations[j*3+1]-=f*dyf;
		localaccelerations[j*3+2]-=f*dzf;
	      }
	  }
      
      /* Do communication to get the full accelerations. Also add the potential energy at the same time. */
      localaccelerations[NATS*3]=potential_energy;
      MPI_Allreduce(localaccelerations, accelerations,NATS*3+1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
      potential_energy=accelerations[NATS*3];

      /* Verlet step 2 */
      for (i=0; i<NATS*3; i++)
	  velocities[i]+=accelerations[i]*dthalf;
	
      kinetic_energy=0.;
      for (i=0; i<NATS*3; i++)
	  kinetic_energy+=velocities[i]*velocities[i];
      kinetic_energy*=0.5;
	
      if ((rank==0) && ((ts%100)==0))
	printf("%d %e %e %e\n",
	       ts,
	       potential_energy,
	       kinetic_energy,
	       (potential_energy+kinetic_energy));

      /* If we are doing equilibration scale the velocities. */
      if ((ts<scalestep) && ((ts%its)==0))
	{
	  for (i=0; i<NATS*3; i++)
	    velocities[i]*=sqrt(deske/kinetic_energy);
	}
      /* If we are not doing equilibration, write each frame to the
	 trajectory file. */
      if (ts>=scalestep)
	{
	  /* Fake domain decomp. by sorting all particles into 2x2x2 boxes. */
	  int local_natoms=0;
	  /* Location in space of this rank */
	  int box_coord_x=rank%2;
	  int box_coord_y=(rank/2)%2;
	  int box_coord_z=(rank/4)%2;
	  for (i=0; i<NATS; i++)
	    {
	      /* Location in space of this atom */
	      int ix=(int)floor(2*positions[i*3]/boxlen);
	      int iy=(int)floor(2*positions[i*3+1]/boxlen);
	      int iz=(int)floor(2*positions[i*3+2]/boxlen);
	      /* Is this atom inside the space of this rank? */
	      if ((ix==box_coord_x) &&
		  (iy==box_coord_y) &&
		  (iz==box_coord_z))
		{
		  /* Yes. So put it in the local position buffer. */
		  localpositions[local_natoms*3]=positions[i*3];
		  localpositions[local_natoms*3+1]=positions[i*3+1];
		  localpositions[local_natoms*3+2]=positions[i*3+2];
		  /* .... and in the local velocities buffer. */
		  localvelocities[local_natoms*3]=velocities[i*3];
		  localvelocities[local_natoms*3+1]=velocities[i*3+1];
		  localvelocities[local_natoms*3+2]=velocities[i*3+2];
		  /* The map translates local atom id to global atom id */
		  map[local_natoms]=i;
		  local_natoms++;
		}
	    }
	  TrajngMPIWrite(trajfile,H,localpositions,localvelocities,3,ts,ts*dt,0.,local_natoms,map);
	}
    }
  /* Close the trajectory file */
  TrajngMPIClose(trajfile);
  MPI_Finalize();
  return 0;
}
