/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

#include <stdlib.h>
#include <math.h>
#include "trajng.h"

/* Number of "atoms" */
#define N 100

/* Number of steps */
#define NSTEPS 1000

int main()
{
  void *dump=TrajngOpenWrite("test.tng", /* Filename */
			     N, /* Number of atoms */
			     100, /* How many dumps in each chunk */
			     0.001, /* Precision in storage of coordinates */
			     1, /* Write box? 1==write 0==nowrite */
			     0, /* Write velocities? 1==write 0==nowrite */
			     0.1, /* Velocity precision */
			     0, /* Compatibility mode 0 */
			     0); /* Disable BWLZH? No. */
  float *coords=malloc(N*3*sizeof *coords); /* Coordinates. Can be
					       either double or single
					       precision. TrajngWrite
					       takes input in double
					       precision, while
					       TrajngWritef takes
					       input in single
					       precision. */
  float H[9]; /* H-matrix */
  int i,j;
  TrajngSetProgramInfo(dump,"Dump example program");
  

  /* Set up a cubic box with sides 20*20*20 */
  for (i=0; i<9; i++)
    H[i]=0.;
  for (i=0; i<3; i++)
    H[i*3+i]=20.; 
  for (i=0; i<NSTEPS; i++)
    {
      float time=i*0.001;
      for (j=0; j<N; j++)
	{
	  coords[j*3]=10.*sin(3.*6.28/N*j+time); /* x-coordinate */
	  coords[j*3+1]=10.*cos(5.*6.28/N*j+time); /* y-coordinate */
	  coords[j*3+2]=10.*cos(7.*6.28/N*j+time); /* z-coordinate */
	}
      TrajngWritef(dump,H,coords,NULL,3,i,time,0.); /* Write coordinates.
						      No velocities to be stored
						      so give that as NULL.
						      Stride is 3 (we store x,y,z,x,y,z...
						      with no space in between */
    }
  TrajngClose(dump);
  return 0;
}
