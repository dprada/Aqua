/* trajng (Trajectory next generation) a library for (de)compression
   of molecular dynamics trajectories. 
   Copyright (c) Daniel Spangberg 2010
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License
   as published by the Free Software Foundation; either version 3
   of the License, or (at your option) any later version.
*/

/* This program runs a MD simulation of atoms using Lennard-Jones 
   potentials and demonstrates dumping using the trajng library.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "trajng.h"

#define NP 5
#define NATS (NP*NP*NP)

int main()
{

  double boxlen=1.1*NP;
  double deske=100.;
  double cutoff=3.5; /* Cut-off in sigma */
  double *positions=malloc(NATS*3*sizeof *positions);
  double *velocities=malloc(NATS*3*sizeof *velocities);
  double *accelerations=malloc(NATS*3*sizeof *accelerations);
  double potential_energy;
  double kinetic_energy;
  double dt=1e-3;
  double cutoff2=cutoff*cutoff;
  int i,j,k,ts,maxts=11000;
  int its=10;
  int scalestep=1000;
  void *trajfile;

  for (i=0; i<NP; i++)
    for (j=0; j<NP; j++)
      for (k=0; k<NP; k++)
      {
	int idx=i*NP*NP+j*NP+k;
	positions[idx*3]=boxlen*(double)i/NP;
	positions[idx*3+1]=boxlen*(double)j/NP;
	positions[idx*3+2]=boxlen*(double)k/NP;
	velocities[idx*3]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	velocities[idx*3+1]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	velocities[idx*3+2]=(-0.5+(rand()/(RAND_MAX+1.0)))*10.;
	accelerations[idx*3]=0.;
	accelerations[idx*3+1]=0.;
	accelerations[idx*3+2]=0.;
      }

  /* Open trajectory file for writing. We write only coordinates. */
  trajfile=TrajngOpenWrite("argonc.tng",NATS,100,0.01,0,0,0.,0,0);

  /* Write program specific info (not required). */
  TrajngSetProgramInfo(trajfile,"Trajng C argon simulation");
  
  for (ts=0; ts<maxts; ts++)
    {
      double dt2half=dt*dt*0.5;
      double dthalf=dt*0.5;
      double iboxlen=1./boxlen;
      /* Verlet step 1 */
      for (i=0; i<NATS*3; i++)
	{
	  positions[i]+=velocities[i]*dt+accelerations[i]*dt2half;
	  velocities[i]+=accelerations[i]*dthalf;
	}
      /* Move particles into central box. */
      for (i=0; i<NATS*3; i++)
	if (positions[i]>boxlen) 
	  positions[i]-=boxlen;
	else if (positions[i]<0.)
	  positions[i]+=boxlen;

      /* Compute forces */
      potential_energy=0.;
      for (i=0; i<NATS*3; i++)
	accelerations[i]=0.;
      
      for (i=0; i<NATS; i++)
	for (j=i+1; j<NATS; j++)
	  {
	    double d2;
	    double dxf=positions[i*3]-positions[j*3];
	    double dyf=positions[i*3+1]-positions[j*3+1];
	    double dzf=positions[i*3+2]-positions[j*3+2];
	    dxf-=boxlen*floor(dxf*iboxlen+0.5);
	    dyf-=boxlen*floor(dyf*iboxlen+0.5);
	    dzf-=boxlen*floor(dzf*iboxlen+0.5);
	    d2=dxf*dxf+dyf*dyf+dzf*dzf;
	    if (d2<cutoff2)
	      {
		double di2=1./d2;
		double di4=di2*di2;
		double di6=di4*di2;
		double di12=di6*di6;
		double f=24.*di2*(2.*di12-di6);
		potential_energy+=4.*(di12-di6);
		accelerations[i*3]+=f*dxf;
		accelerations[i*3+1]+=f*dyf;
		accelerations[i*3+2]+=f*dzf;
		accelerations[j*3]-=f*dxf;
		accelerations[j*3+1]-=f*dyf;
		accelerations[j*3+2]-=f*dzf;
	      }
	  }

      /* Verlet step 2 */
      for (i=0; i<NATS*3; i++)
	  velocities[i]+=accelerations[i]*dthalf;
	
      kinetic_energy=0.;
      for (i=0; i<NATS*3; i++)
	  kinetic_energy+=velocities[i]*velocities[i];
      kinetic_energy*=0.5;
	
      printf("%d %e %e %e\n",
	     ts,
	     potential_energy,
	     kinetic_energy,
	     (potential_energy+kinetic_energy));

      /* If we are doing equilibration scale the velocities. */
      if ((ts<scalestep) && ((ts%its)==0))
	{
	  for (i=0; i<NATS*3; i++)
	    velocities[i]*=sqrt(deske/kinetic_energy);
	}
      /* If we are not doing equilibration, write each frame to the
	 trajectory file. We do not write the box or the velocities,
	 so leave those as NULL. */
      if (ts>=scalestep)
	TrajngWrite(trajfile,NULL,positions,NULL,3,ts,ts*dt,0.);
    }
  /* Close the trajectory file */
  TrajngClose(trajfile);
  return 0;
}
